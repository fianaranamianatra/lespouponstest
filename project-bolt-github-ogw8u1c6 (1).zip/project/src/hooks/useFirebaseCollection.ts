import { useState, useEffect } from 'react';
import { FirebaseService } from '../lib/firebase/firebaseService';

export interface FirebaseState<T> {
  data: T[];
  loading: boolean;
  error: string | null;
  creating: boolean;
  updating: boolean;
  deleting: boolean;
}

export const useFirebaseCollection = <T>(
  service: FirebaseService<T>,
  realtime: boolean = true
) => {
  const [state, setState] = useState<FirebaseState<T>>({
    data: [],
    loading: true,
    error: null,
    creating: false,
    updating: false,
    deleting: false
  });

  useEffect(() => {
    if (realtime) {
      // Synchronisation temps réel
      const unsubscribe = service.onSnapshot(
        (data) => {
          setState(prev => ({
            ...prev,
            data,
            loading: false,
            error: null
          }));
        },
        (error) => {
          setState(prev => ({
            ...prev,
            loading: false,
            error: error.message
          }));
        }
      );

      return () => unsubscribe();
    } else {
      // Chargement unique
      const loadData = async () => {
        try {
          const data = await service.getAll();
          setState(prev => ({
            ...prev,
            data,
            loading: false,
            error: null
          }));
        } catch (error: any) {
          setState(prev => ({
            ...prev,
            loading: false,
            error: error.message
          }));
        }
      };

      loadData();
    }
  }, [service, realtime]);

  const create = async (data: any) => {
    setState(prev => ({ ...prev, creating: true, error: null }));
    try {
      const id = await service.create(data);
      setState(prev => ({ ...prev, creating: false }));
      return id;
    } catch (error: any) {
      setState(prev => ({ 
        ...prev, 
        creating: false, 
        error: error.message 
      }));
      throw error;
    }
  };

  const update = async (id: string, data: any) => {
    setState(prev => ({ ...prev, updating: true, error: null }));
    try {
      await service.update(id, data);
      setState(prev => ({ ...prev, updating: false }));
    } catch (error: any) {
      setState(prev => ({ 
        ...prev, 
        updating: false, 
        error: error.message 
      }));
      throw error;
    }
  };

  const remove = async (id: string) => {
    setState(prev => ({ ...prev, deleting: true, error: null }));
    try {
      await service.delete(id);
      setState(prev => ({ ...prev, deleting: false }));
    } catch (error: any) {
      setState(prev => ({ 
        ...prev, 
        deleting: false, 
        error: error.message 
      }));
      throw error;
    }
  };

  return {
    ...state,
    create,
    update,
    remove
  };
};