import { useState, useEffect } from 'react';
import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  onSnapshot, 
  query, 
  where, 
  orderBy,
  serverTimestamp,
  writeBatch
} from 'firebase/firestore';
import { db } from '../lib/firebase';

export interface FirebaseDataState<T> {
  data: T[];
  loading: boolean;
  error: string | null;
  creating: boolean;
  updating: boolean;
  deleting: boolean;
}

export const useFirebaseData = <T extends { id?: string }>(
  collectionName: string,
  realtime: boolean = true,
  queryConstraints: any[] = []
) => {
  const [state, setState] = useState<FirebaseDataState<T>>({
    data: [],
    loading: true,
    error: null,
    creating: false,
    updating: false,
    deleting: false
  });

  useEffect(() => {
    const collectionRef = collection(db, collectionName);
    const q = queryConstraints.length > 0 
      ? query(collectionRef, ...queryConstraints)
      : collectionRef;

    if (realtime) {
      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const data = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data(),
            createdAt: doc.data().createdAt?.toDate(),
            updatedAt: doc.data().updatedAt?.toDate()
          })) as T[];

          setState(prev => ({
            ...prev,
            data,
            loading: false,
            error: null
          }));
        },
        (error) => {
          console.error(`Erreur Firestore pour ${collectionName}:`, error);
          
          // Gestion spécifique des erreurs de permissions
          if (error.code === 'permission-denied') {
            setState(prev => ({
              ...prev,
              loading: false,
              error: 'Permissions insuffisantes. Veuillez vous connecter ou vérifier la configuration Firebase.'
            }));
          } else {
            setState(prev => ({
              ...prev,
              loading: false,
              error: 'Erreur de synchronisation des données'
            }));
          }
        }
      );

      return () => unsubscribe();
    } else {
      const loadData = async () => {
        try {
          const snapshot = await getDocs(q);
          const data = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data(),
            createdAt: doc.data().createdAt?.toDate(),
            updatedAt: doc.data().updatedAt?.toDate()
          })) as T[];

          setState(prev => ({
            ...prev,
            data,
            loading: false,
            error: null
          }));
        } catch (error) {
          console.error(`Erreur lors du chargement de ${collectionName}:`, error);
          
          // Gestion spécifique des erreurs de permissions
          if (error.code === 'permission-denied') {
            setState(prev => ({
              ...prev,
              loading: false,
              error: 'Permissions insuffisantes. Veuillez vous connecter ou vérifier la configuration Firebase.'
            }));
          } else {
            setState(prev => ({
              ...prev,
              loading: false,
              error: 'Erreur lors du chargement des données'
            }));
          }
        }
      };

      loadData();
    }
  }, [collectionName, realtime]);

  const create = async (data: Omit<T, 'id' | 'createdAt' | 'updatedAt'>) => {
    setState(prev => ({ ...prev, creating: true, error: null }));
    
    try {
      const docData = {
        ...data,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      const docRef = await addDoc(collection(db, collectionName), docData);
      
      setState(prev => ({ ...prev, creating: false }));
      return docRef.id;
    } catch (error) {
      console.error(`Erreur lors de la création dans ${collectionName}:`, error);
      
      // Gestion spécifique des erreurs
      let errorMessage = 'Erreur lors de la création';
      if (error.code === 'permission-denied') {
        errorMessage = 'Permissions insuffisantes. Veuillez vous connecter.';
      } else if (error.code === 'invalid-argument') {
        errorMessage = 'Données invalides. Vérifiez les champs requis.';
      }
      
      setState(prev => ({ 
        ...prev, 
        creating: false, 
        error: errorMessage
      }));
      throw error;
    }
  };

  const update = async (id: string, data: Partial<T>) => {
    setState(prev => ({ ...prev, updating: true, error: null }));
    
    try {
      const docRef = doc(db, collectionName, id);
      await updateDoc(docRef, {
        ...data,
        updatedAt: serverTimestamp()
      });
      
      setState(prev => ({ ...prev, updating: false }));
    } catch (error) {
      console.error(`Erreur lors de la mise à jour dans ${collectionName}:`, error);
      
      let errorMessage = 'Erreur lors de la mise à jour';
      if (error.code === 'permission-denied') {
        errorMessage = 'Permissions insuffisantes. Veuillez vous connecter.';
      }
      
      setState(prev => ({ 
        ...prev, 
        updating: false, 
        error: errorMessage
      }));
      throw error;
    }
  };

  const remove = async (id: string) => {
    setState(prev => ({ ...prev, deleting: true, error: null }));
    
    try {
      const docRef = doc(db, collectionName, id);
      await deleteDoc(docRef);
      
      setState(prev => ({ ...prev, deleting: false }));
    } catch (error) {
      console.error(`Erreur lors de la suppression dans ${collectionName}:`, error);
      
      let errorMessage = 'Erreur lors de la suppression';
      if (error.code === 'permission-denied') {
        errorMessage = 'Permissions insuffisantes. Veuillez vous connecter.';
      }
      
      setState(prev => ({ 
        ...prev, 
        deleting: false, 
        error: errorMessage
      }));
      throw error;
    }
  };

  const batchCreate = async (items: Omit<T, 'id' | 'createdAt' | 'updatedAt'>[]) => {
    setState(prev => ({ ...prev, creating: true, error: null }));
    
    try {
      const batch = writeBatch(db);
      
      items.forEach(item => {
        const docRef = doc(collection(db, collectionName));
        batch.set(docRef, {
          ...item,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
      });
      
      await batch.commit();
      setState(prev => ({ ...prev, creating: false }));
    } catch (error) {
      console.error(`Erreur lors de la création en lot dans ${collectionName}:`, error);
      
      let errorMessage = 'Erreur lors de la création en lot';
      if (error.code === 'permission-denied') {
        errorMessage = 'Permissions insuffisantes. Veuillez vous connecter.';
      }
      
      setState(prev => ({ 
        ...prev, 
        creating: false, 
        error: errorMessage
      }));
      throw error;
    }
  };

  return {
    ...state,
    create,
    update,
    remove,
    batchCreate
  };
};