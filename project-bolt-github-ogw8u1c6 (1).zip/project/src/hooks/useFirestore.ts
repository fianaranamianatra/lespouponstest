import { useState, useEffect } from 'react';
import { FirestoreService } from '../lib/firestore';

export interface FirestoreState<T> {
  data: T[];
  loading: boolean;
  error: string | null;
}

export const useFirestore = <T>(service: FirestoreService<T>, realtime: boolean = false) => {
  const [state, setState] = useState<FirestoreState<T>>({
    data: [],
    loading: true,
    error: null
  });

  useEffect(() => {
    if (realtime) {
      // Écoute en temps réel
      const unsubscribe = service.onSnapshot((data) => {
        setState({
          data,
          loading: false,
          error: null
        });
      });

      return () => unsubscribe();
    } else {
      // Chargement unique
      const loadData = async () => {
        try {
          const data = await service.getAll();
          setState({
            data,
            loading: false,
            error: null
          });
        } catch (error) {
          setState({
            data: [],
            loading: false,
            error: 'Erreur lors du chargement des données'
          });
        }
      };

      loadData();
    }
  }, [service, realtime]);

  const create = async (data: any) => {
    try {
      const id = await service.create(data);
      return id;
    } catch (error) {
      setState(prev => ({
        ...prev,
        error: 'Erreur lors de la création'
      }));
      throw error;
    }
  };

  const update = async (id: string, data: any) => {
    try {
      await service.update(id, data);
    } catch (error) {
      setState(prev => ({
        ...prev,
        error: 'Erreur lors de la mise à jour'
      }));
      throw error;
    }
  };

  const remove = async (id: string) => {
    try {
      await service.delete(id);
    } catch (error) {
      setState(prev => ({
        ...prev,
        error: 'Erreur lors de la suppression'
      }));
      throw error;
    }
  };

  return {
    ...state,
    create,
    update,
    remove
  };
};