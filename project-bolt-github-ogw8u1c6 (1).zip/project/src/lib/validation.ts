// Schémas de validation pour les données
export interface ValidationRule {
  required?: boolean;
  minLength?: number;
  maxLength?: number;
  pattern?: RegExp;
  min?: number;
  max?: number;
  custom?: (value: any) => string | null;
}

export interface ValidationSchema {
  [key: string]: ValidationRule;
}

export interface ValidationResult {
  isValid: boolean;
  errors: { [key: string]: string };
}

// Fonction de validation générique
export const validateData = (data: any, schema: ValidationSchema): ValidationResult => {
  const errors: { [key: string]: string } = {};

  Object.keys(schema).forEach(field => {
    const rule = schema[field];
    const value = data[field];

    // Vérification required
    if (rule.required && (value === undefined || value === null || value === '')) {
      errors[field] = `Le champ ${field} est requis`;
      return;
    }

    // Si la valeur est vide et non requise, on passe
    if (!value && !rule.required) return;

    // Vérification minLength
    if (rule.minLength && typeof value === 'string' && value.length < rule.minLength) {
      errors[field] = `${field} doit contenir au moins ${rule.minLength} caractères`;
    }

    // Vérification maxLength
    if (rule.maxLength && typeof value === 'string' && value.length > rule.maxLength) {
      errors[field] = `${field} ne peut pas dépasser ${rule.maxLength} caractères`;
    }

    // Vérification pattern
    if (rule.pattern && typeof value === 'string' && !rule.pattern.test(value)) {
      errors[field] = `Format invalide pour ${field}`;
    }

    // Vérification min (pour les nombres)
    if (rule.min !== undefined && typeof value === 'number' && value < rule.min) {
      errors[field] = `${field} doit être supérieur ou égal à ${rule.min}`;
    }

    // Vérification max (pour les nombres)
    if (rule.max !== undefined && typeof value === 'number' && value > rule.max) {
      errors[field] = `${field} doit être inférieur ou égal à ${rule.max}`;
    }

    // Validation personnalisée
    if (rule.custom) {
      const customError = rule.custom(value);
      if (customError) {
        errors[field] = customError;
      }
    }
  });

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

// Schémas de validation pour chaque entité
export const studentValidationSchema: ValidationSchema = {
  firstName: {
    required: false,
    minLength: 2,
    maxLength: 50,
    pattern: /^[a-zA-ZÀ-ÿ\s-']+$/
  },
  lastName: {
    required: true,
    minLength: 2,
    maxLength: 50,
    pattern: /^[a-zA-ZÀ-ÿ\s-']+$/
  },
  dateOfBirth: {
    required: false,
    custom: (value) => {
      if (!value) return null; // Permettre les valeurs vides
      const date = new Date(value);
      const now = new Date();
      const age = now.getFullYear() - date.getFullYear();
      if (age < 1 || age > 18) {
        return 'L\'âge doit être entre 1 et 18 ans';
      }
      return null;
    }
  },
  class: {
    required: false,
    minLength: 1
  },
  address: {
    required: false,
    minLength: 10,
    maxLength: 200
  },
  phone: {
    required: false,
    pattern: /^(\+261|0)[0-9]{9}$/
  },
  parentName: {
    required: false,
    minLength: 2,
    maxLength: 100
  },
  parentEmail: {
    required: false,
    pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  }
};

export const teacherValidationSchema: ValidationSchema = {
  firstName: {
    required: true,
    minLength: 2,
    maxLength: 50,
    pattern: /^[a-zA-ZÀ-ÿ\s-']+$/
  },
  lastName: {
    required: true,
    minLength: 2,
    maxLength: 50,
    pattern: /^[a-zA-ZÀ-ÿ\s-']+$/
  },
  dateOfBirth: {
    required: true,
    custom: (value) => {
      const date = new Date(value);
      const now = new Date();
      const age = now.getFullYear() - date.getFullYear();
      if (age < 18 || age > 70) {
        return 'L\'âge doit être entre 18 et 70 ans';
      }
      return null;
    }
  },
  email: {
    required: false,
    pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  },
  phone: {
    required: false,
    pattern: /^(\+261|0)[0-9]{9}$|^[0-9\s\-\+\(\)]+$/
  },
  subject: {
    required: true,
    minLength: 2
  },
  experience: {
    required: true,
    min: 0,
    max: 50
  }
};

export const classValidationSchema: ValidationSchema = {
  name: {
    required: true,
    minLength: 1,
    maxLength: 20
  },
  level: {
    required: true,
    minLength: 2
  },
  teacher: {
    required: true,
    minLength: 2
  },
  maxCapacity: {
    required: true,
    min: 5,
    max: 35
  },
  room: {
    required: true,
    minLength: 2,
    maxLength: 50
  }
};

export const gradeValidationSchema: ValidationSchema = {
  studentName: {
    required: true,
    minLength: 2
  },
  subject: {
    required: true,
    minLength: 2
  },
  assignment: {
    required: true,
    minLength: 2,
    maxLength: 100
  },
  grade: {
    required: true,
    min: 0
  },
  maxGrade: {
    required: true,
    min: 1,
    max: 100
  },
  teacher: {
    required: true,
    minLength: 2
  },
  date: {
    required: true
  }
};

export const paymentValidationSchema: ValidationSchema = {
  studentName: {
    required: true,
    minLength: 2
  },
  class: {
    required: true,
    minLength: 1
  },
  amount: {
    required: true,
    min: 1000,
    max: 10000000
  },
  paymentMethod: {
    required: true
  },
  paymentDate: {
    required: true
  },
  period: {
    required: true
  },
  reference: {
    required: true,
    minLength: 3,
    maxLength: 50
  }
};

export const scheduleValidationSchema: ValidationSchema = {
  class: {
    required: true,
    minLength: 1
  },
  subject: {
    required: true,
    minLength: 2
  },
  teacher: {
    required: true,
    minLength: 2
  },
  day: {
    required: true
  },
  startTime: {
    required: true,
    pattern: /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/
  },
  endTime: {
    required: true,
    pattern: /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/,
    custom: (value, data) => {
      if (data?.startTime && value <= data.startTime) {
        return 'L\'heure de fin doit être après l\'heure de début';
      }
      return null;
    }
  }
};

export const subjectValidationSchema: ValidationSchema = {
  name: {
    required: true,
    minLength: 2,
    maxLength: 50
  },
  code: {
    required: true,
    minLength: 2,
    maxLength: 10,
    pattern: /^[A-Z0-9]+$/
  },
  hoursPerWeek: {
    required: true,
    min: 1,
    max: 10
  }
};

export const messageValidationSchema: ValidationSchema = {
  recipient: {
    required: true,
    minLength: 2
  },
  subject: {
    required: true,
    minLength: 5,
    maxLength: 100
  },
  content: {
    required: true,
    minLength: 10,
    maxLength: 2000
  }
};