import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  getDoc,
  query, 
  where, 
  orderBy,
  serverTimestamp,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../firebase';
import { validateData, studentValidationSchema } from '../validation';

export interface Student {
  id?: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  class: string;
  address: string;
  phone: string;
  parentName: string;
  parentEmail?: string;
  status: 'active' | 'inactive';
  createdAt?: Date;
  updatedAt?: Date;
}

const COLLECTION_NAME = 'students';

export class StudentsService {
  // Créer un élève
  static async create(studentData: Omit<Student, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    // Validation côté serveur
    const validation = validateData(studentData, studentValidationSchema);
    if (!validation.isValid) {
      throw new Error(`Données invalides: ${Object.values(validation.errors).join(', ')}`);
    }

    try {
      const docData = {
        ...studentData,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      const docRef = await addDoc(collection(db, COLLECTION_NAME), docData);
      return docRef.id;
    } catch (error) {
      console.error('Erreur lors de la création de l\'élève:', error);
      throw new Error('Impossible de créer l\'élève');
    }
  }

  // Mettre à jour un élève
  static async update(id: string, updates: Partial<Student>): Promise<void> {
    // Validation des données modifiées
    const validation = validateData(updates, studentValidationSchema);
    if (!validation.isValid) {
      throw new Error(`Données invalides: ${Object.values(validation.errors).join(', ')}`);
    }

    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await updateDoc(docRef, {
        ...updates,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Erreur lors de la mise à jour de l\'élève:', error);
      throw new Error('Impossible de mettre à jour l\'élève');
    }
  }

  // Supprimer un élève
  static async delete(id: string): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await deleteDoc(docRef);
    } catch (error) {
      console.error('Erreur lors de la suppression de l\'élève:', error);
      throw new Error('Impossible de supprimer l\'élève');
    }
  }

  // Récupérer un élève par ID
  static async getById(id: string): Promise<Student | null> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Student;
      }
      
      return null;
    } catch (error) {
      console.error('Erreur lors de la récupération de l\'élève:', error);
      throw new Error('Impossible de récupérer l\'élève');
    }
  }

  // Récupérer tous les élèves
  static async getAll(): Promise<Student[]> {
    try {
      const q = query(collection(db, COLLECTION_NAME), orderBy('createdAt', 'desc'));
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Student;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des élèves:', error);
      throw new Error('Impossible de récupérer les élèves');
    }
  }

  // Récupérer les élèves par classe
  static async getByClass(className: string): Promise<Student[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('class', '==', className),
        orderBy('lastName', 'asc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Student;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des élèves par classe:', error);
      throw new Error('Impossible de récupérer les élèves de cette classe');
    }
  }

  // Récupérer les élèves actifs
  static async getActive(): Promise<Student[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('status', '==', 'active'),
        orderBy('lastName', 'asc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Student;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des élèves actifs:', error);
      throw new Error('Impossible de récupérer les élèves actifs');
    }
  }

  // Écouter les changements en temps réel
  static onSnapshot(callback: (students: Student[]) => void) {
    const q = query(collection(db, COLLECTION_NAME), orderBy('createdAt', 'desc'));
    
    return onSnapshot(q, (snapshot) => {
      const students = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Student;
      });
      callback(students);
    });
  }

  // Rechercher des élèves
  static async search(searchTerm: string): Promise<Student[]> {
    try {
      // Note: Firestore ne supporte pas la recherche full-text native
      // Cette implémentation récupère tous les élèves et filtre côté client
      const students = await this.getAll();
      
      return students.filter(student => 
        student.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.class.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.parentName.toLowerCase().includes(searchTerm.toLowerCase())
      );
    } catch (error) {
      console.error('Erreur lors de la recherche d\'élèves:', error);
      throw new Error('Impossible de rechercher les élèves');
    }
  }

  // Obtenir les statistiques des élèves
  static async getStats() {
    try {
      const students = await this.getAll();
      
      const stats = {
        total: students.length,
        active: students.filter(s => s.status === 'active').length,
        inactive: students.filter(s => s.status === 'inactive').length,
        byClass: {} as { [key: string]: number }
      };

      // Compter par classe
      students.forEach(student => {
        stats.byClass[student.class] = (stats.byClass[student.class] || 0) + 1;
      });

      return stats;
    } catch (error) {
      console.error('Erreur lors du calcul des statistiques:', error);
      throw new Error('Impossible de calculer les statistiques');
    }
  }
}