import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  query, 
  where, 
  orderBy,
  serverTimestamp,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../firebase';
import { validateData, messageValidationSchema } from '../validation';

export interface Communication {
  id?: string;
  sender: string;
  recipient: string;
  subject: string;
  content: string;
  type: 'parent' | 'teacher' | 'admin';
  status: 'sent' | 'read' | 'replied';
  priority: 'low' | 'medium' | 'high';
  date: string;
  createdAt?: Date;
  updatedAt?: Date;
}

const COLLECTION_NAME = 'communications';

export class CommunicationsService {
  static async create(messageData: Omit<Communication, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    const validation = validateData(messageData, messageValidationSchema);
    if (!validation.isValid) {
      throw new Error(`Données invalides: ${Object.values(validation.errors).join(', ')}`);
    }

    try {
      const docData = {
        ...messageData,
        status: messageData.status || 'sent',
        date: messageData.date || new Date().toISOString().split('T')[0],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      const docRef = await addDoc(collection(db, COLLECTION_NAME), docData);
      return docRef.id;
    } catch (error) {
      console.error('Erreur lors de la création du message:', error);
      throw new Error('Impossible de créer le message');
    }
  }

  static async update(id: string, updates: Partial<Communication>): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await updateDoc(docRef, {
        ...updates,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Erreur lors de la mise à jour du message:', error);
      throw new Error('Impossible de mettre à jour le message');
    }
  }

  static async delete(id: string): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await deleteDoc(docRef);
    } catch (error) {
      console.error('Erreur lors de la suppression du message:', error);
      throw new Error('Impossible de supprimer le message');
    }
  }

  static async getAll(): Promise<Communication[]> {
    try {
      const q = query(collection(db, COLLECTION_NAME), orderBy('date', 'desc'));
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Communication;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des messages:', error);
      throw new Error('Impossible de récupérer les messages');
    }
  }

  static async getByRecipient(recipient: string): Promise<Communication[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('recipient', '==', recipient),
        orderBy('date', 'desc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Communication;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des messages par destinataire:', error);
      throw new Error('Impossible de récupérer les messages pour ce destinataire');
    }
  }

  static async getBySender(sender: string): Promise<Communication[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('sender', '==', sender),
        orderBy('date', 'desc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Communication;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des messages par expéditeur:', error);
      throw new Error('Impossible de récupérer les messages pour cet expéditeur');
    }
  }

  static async getByStatus(status: 'sent' | 'read' | 'replied'): Promise<Communication[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('status', '==', status),
        orderBy('date', 'desc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Communication;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des messages par statut:', error);
      throw new Error('Impossible de récupérer les messages avec ce statut');
    }
  }

  static onSnapshot(callback: (messages: Communication[]) => void) {
    const q = query(collection(db, COLLECTION_NAME), orderBy('date', 'desc'));
    
    return onSnapshot(q, (snapshot) => {
      const messages = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Communication;
      });
      callback(messages);
    });
  }

  // Marquer un message comme lu
  static async markAsRead(id: string): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await updateDoc(docRef, {
        status: 'read',
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Erreur lors du marquage du message comme lu:', error);
      throw new Error('Impossible de marquer le message comme lu');
    }
  }

  // Marquer un message comme répondu
  static async markAsReplied(id: string): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await updateDoc(docRef, {
        status: 'replied',
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Erreur lors du marquage du message comme répondu:', error);
      throw new Error('Impossible de marquer le message comme répondu');
    }
  }
}