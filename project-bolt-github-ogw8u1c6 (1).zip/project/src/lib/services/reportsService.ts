import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  query, 
  where, 
  orderBy,
  serverTimestamp,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../firebase';

export interface Report {
  id?: string;
  title: string;
  description: string;
  type: 'academic' | 'attendance' | 'financial' | 'behavioral';
  generated: string;
  size: string;
  format: 'PDF' | 'Excel' | 'Word';
  createdBy: string;
  createdAt?: Date;
  updatedAt?: Date;
}

const COLLECTION_NAME = 'reports';

export class ReportsService {
  static async create(reportData: Omit<Report, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    // Validation basique
    if (!reportData.title || !reportData.type || !reportData.format) {
      throw new Error('Données du rapport incomplètes');
    }

    try {
      const docData = {
        ...reportData,
        generated: reportData.generated || new Date().toISOString().split('T')[0],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      const docRef = await addDoc(collection(db, COLLECTION_NAME), docData);
      return docRef.id;
    } catch (error) {
      console.error('Erreur lors de la création du rapport:', error);
      throw new Error('Impossible de créer le rapport');
    }
  }

  static async update(id: string, updates: Partial<Report>): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await updateDoc(docRef, {
        ...updates,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Erreur lors de la mise à jour du rapport:', error);
      throw new Error('Impossible de mettre à jour le rapport');
    }
  }

  static async delete(id: string): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await deleteDoc(docRef);
    } catch (error) {
      console.error('Erreur lors de la suppression du rapport:', error);
      throw new Error('Impossible de supprimer le rapport');
    }
  }

  static async getAll(): Promise<Report[]> {
    try {
      const q = query(collection(db, COLLECTION_NAME), orderBy('generated', 'desc'));
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Report;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des rapports:', error);
      throw new Error('Impossible de récupérer les rapports');
    }
  }

  static async getByType(type: 'academic' | 'attendance' | 'financial' | 'behavioral'): Promise<Report[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('type', '==', type),
        orderBy('generated', 'desc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Report;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des rapports par type:', error);
      throw new Error('Impossible de récupérer les rapports de ce type');
    }
  }

  static async getByCreator(creatorName: string): Promise<Report[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('createdBy', '==', creatorName),
        orderBy('generated', 'desc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Report;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des rapports par créateur:', error);
      throw new Error('Impossible de récupérer les rapports de ce créateur');
    }
  }

  static onSnapshot(callback: (reports: Report[]) => void) {
    const q = query(collection(db, COLLECTION_NAME), orderBy('generated', 'desc'));
    
    return onSnapshot(q, (snapshot) => {
      const reports = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Report;
      });
      callback(reports);
    });
  }

  // Générer un rapport de bulletin de notes
  static async generateGradesReport(className: string, period: string, createdBy: string): Promise<string> {
    try {
      // Simuler la génération d'un rapport
      const reportData = {
        title: `Bulletin de Notes - ${className} - ${period}`,
        description: `Rapport complet des notes et évaluations pour la classe ${className} pendant ${period}`,
        type: 'academic' as const,
        generated: new Date().toISOString().split('T')[0],
        size: '2.3 MB',
        format: 'PDF' as const,
        createdBy
      };
      
      return await this.create(reportData);
    } catch (error) {
      console.error('Erreur lors de la génération du rapport de notes:', error);
      throw new Error('Impossible de générer le rapport de notes');
    }
  }

  // Générer un rapport financier
  static async generateFinancialReport(period: string, createdBy: string): Promise<string> {
    try {
      // Simuler la génération d'un rapport
      const reportData = {
        title: `Rapport Financier - ${period}`,
        description: `Analyse financière complète pour la période ${period}`,
        type: 'financial' as const,
        generated: new Date().toISOString().split('T')[0],
        size: '1.8 MB',
        format: 'Excel' as const,
        createdBy
      };
      
      return await this.create(reportData);
    } catch (error) {
      console.error('Erreur lors de la génération du rapport financier:', error);
      throw new Error('Impossible de générer le rapport financier');
    }
  }
}