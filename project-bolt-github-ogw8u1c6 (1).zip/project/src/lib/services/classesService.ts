import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  getDoc,
  query, 
  where, 
  orderBy,
  serverTimestamp,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../firebase';
import { validateData, classValidationSchema } from '../validation';

export interface Class {
  id?: string;
  name: string;
  level: string;
  teacher: string;
  studentCount: number;
  maxCapacity: number;
  room: string;
  status: 'active' | 'inactive';
  createdAt?: Date;
  updatedAt?: Date;
}

const COLLECTION_NAME = 'classes';

export class ClassesService {
  static async create(classData: Omit<Class, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    const validation = validateData(classData, classValidationSchema);
    if (!validation.isValid) {
      throw new Error(`Données invalides: ${Object.values(validation.errors).join(', ')}`);
    }

    try {
      const docData = {
        ...classData,
        studentCount: classData.studentCount || 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      const docRef = await addDoc(collection(db, COLLECTION_NAME), docData);
      return docRef.id;
    } catch (error) {
      console.error('Erreur lors de la création de la classe:', error);
      throw new Error('Impossible de créer la classe');
    }
  }

  static async update(id: string, updates: Partial<Class>): Promise<void> {
    const validation = validateData(updates, classValidationSchema);
    if (!validation.isValid) {
      throw new Error(`Données invalides: ${Object.values(validation.errors).join(', ')}`);
    }

    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await updateDoc(docRef, {
        ...updates,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Erreur lors de la mise à jour de la classe:', error);
      throw new Error('Impossible de mettre à jour la classe');
    }
  }

  static async delete(id: string): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await deleteDoc(docRef);
    } catch (error) {
      console.error('Erreur lors de la suppression de la classe:', error);
      throw new Error('Impossible de supprimer la classe');
    }
  }

  static async getById(id: string): Promise<Class | null> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Class;
      }
      
      return null;
    } catch (error) {
      console.error('Erreur lors de la récupération de la classe:', error);
      throw new Error('Impossible de récupérer la classe');
    }
  }

  static async getAll(): Promise<Class[]> {
    try {
      const q = query(collection(db, COLLECTION_NAME), orderBy('name', 'asc'));
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Class;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des classes:', error);
      throw new Error('Impossible de récupérer les classes');
    }
  }

  static async getByLevel(level: string): Promise<Class[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('level', '==', level),
        orderBy('name', 'asc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Class;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des classes par niveau:', error);
      throw new Error('Impossible de récupérer les classes de ce niveau');
    }
  }

  static onSnapshot(callback: (classes: Class[]) => void) {
    const q = query(collection(db, COLLECTION_NAME), orderBy('name', 'asc'));
    
    return onSnapshot(q, (snapshot) => {
      const classes = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Class;
      });
      callback(classes);
    });
  }

  // Mettre à jour le nombre d'élèves dans une classe
  static async updateStudentCount(className: string, increment: number): Promise<void> {
    try {
      // Trouver la classe par son nom
      const q = query(collection(db, COLLECTION_NAME), where('name', '==', className));
      const querySnapshot = await getDocs(q);
      
      if (querySnapshot.empty) {
        throw new Error(`Classe ${className} non trouvée`);
      }
      
      const classDoc = querySnapshot.docs[0];
      const currentCount = classDoc.data().studentCount || 0;
      
      // Mettre à jour le compteur
      await updateDoc(doc(db, COLLECTION_NAME, classDoc.id), {
        studentCount: Math.max(0, currentCount + increment), // Éviter les nombres négatifs
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Erreur lors de la mise à jour du nombre d\'élèves:', error);
      throw new Error('Impossible de mettre à jour le nombre d\'élèves');
    }
  }
}