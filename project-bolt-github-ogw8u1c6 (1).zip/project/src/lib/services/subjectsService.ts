import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  getDoc,
  query, 
  where, 
  orderBy,
  serverTimestamp,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../firebase';
import { validateData, subjectValidationSchema } from '../validation';

export interface Subject {
  id?: string;
  name: string;
  code: string;
  description: string;
  hoursPerWeek: number;
  teachers: string[];
  classes: string[];
  color: string;
  status: 'active' | 'inactive';
  createdAt?: Date;
  updatedAt?: Date;
}

const COLLECTION_NAME = 'subjects';

export class SubjectsService {
  static async create(subjectData: Omit<Subject, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    const validation = validateData(subjectData, subjectValidationSchema);
    if (!validation.isValid) {
      throw new Error(`Données invalides: ${Object.values(validation.errors).join(', ')}`);
    }

    try {
      const docData = {
        ...subjectData,
        teachers: subjectData.teachers || [],
        classes: subjectData.classes || [],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      const docRef = await addDoc(collection(db, COLLECTION_NAME), docData);
      return docRef.id;
    } catch (error) {
      console.error('Erreur lors de la création de la matière:', error);
      throw new Error('Impossible de créer la matière');
    }
  }

  static async update(id: string, updates: Partial<Subject>): Promise<void> {
    const validation = validateData(updates, subjectValidationSchema);
    if (!validation.isValid) {
      throw new Error(`Données invalides: ${Object.values(validation.errors).join(', ')}`);
    }

    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await updateDoc(docRef, {
        ...updates,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Erreur lors de la mise à jour de la matière:', error);
      throw new Error('Impossible de mettre à jour la matière');
    }
  }

  static async delete(id: string): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await deleteDoc(docRef);
    } catch (error) {
      console.error('Erreur lors de la suppression de la matière:', error);
      throw new Error('Impossible de supprimer la matière');
    }
  }

  static async getAll(): Promise<Subject[]> {
    try {
      const q = query(collection(db, COLLECTION_NAME), orderBy('name', 'asc'));
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Subject;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des matières:', error);
      throw new Error('Impossible de récupérer les matières');
    }
  }

  static async getByTeacher(teacherName: string): Promise<Subject[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('teachers', 'array-contains', teacherName),
        orderBy('name', 'asc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Subject;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des matières par enseignant:', error);
      throw new Error('Impossible de récupérer les matières de cet enseignant');
    }
  }

  static onSnapshot(callback: (subjects: Subject[]) => void) {
    const q = query(collection(db, COLLECTION_NAME), orderBy('name', 'asc'));
    
    return onSnapshot(q, (snapshot) => {
      const subjects = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Subject;
      });
      callback(subjects);
    });
  }

  // Ajouter un enseignant à une matière
  static async addTeacherToSubject(subjectId: string, teacherName: string): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, subjectId);
      const docSnap = await getDoc(docRef);
      
      if (!docSnap.exists()) {
        throw new Error('Matière non trouvée');
      }
      
      const data = docSnap.data();
      const teachers = data.teachers || [];
      
      if (!teachers.includes(teacherName)) {
        await updateDoc(docRef, {
          teachers: [...teachers, teacherName],
          updatedAt: serverTimestamp()
        });
      }
    } catch (error) {
      console.error('Erreur lors de l\'ajout de l\'enseignant à la matière:', error);
      throw new Error('Impossible d\'ajouter l\'enseignant à la matière');
    }
  }

  // Ajouter une classe à une matière
  static async addClassToSubject(subjectId: string, className: string): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, subjectId);
      const docSnap = await getDoc(docRef);
      
      if (!docSnap.exists()) {
        throw new Error('Matière non trouvée');
      }
      
      const data = docSnap.data();
      const classes = data.classes || [];
      
      if (!classes.includes(className)) {
        await updateDoc(docRef, {
          classes: [...classes, className],
          updatedAt: serverTimestamp()
        });
      }
    } catch (error) {
      console.error('Erreur lors de l\'ajout de la classe à la matière:', error);
      throw new Error('Impossible d\'ajouter la classe à la matière');
    }
  }
}