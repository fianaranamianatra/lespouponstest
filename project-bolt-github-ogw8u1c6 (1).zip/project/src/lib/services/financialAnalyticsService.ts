import { 
  collection, 
  doc, 
  getDocs, 
  query, 
  where, 
  orderBy,
  Timestamp
} from 'firebase/firestore';
import { db } from '../firebase';
import { FinancialSettingsService } from './financialSettingsService';
import { PayrollService } from './payrollService';
import type { FinancialSetting } from '../firebase/collections';

export interface FinancialAnalytics {
  // Période d'analyse
  period: {
    startDate: string;
    endDate: string;
    label: string;
  };
  
  // Données de paie
  payroll: {
    totalGrossSalaries: number;
    totalNetSalaries: number;
    totalEmployeeContributions: number;
    totalEmployerContributions: number;
    totalEmployerCost: number;
    employeeCount: number;
  };
  
  // Détail des cotisations
  contributions: {
    cnaps: {
      employeeTotal: number;
      employerTotal: number;
      total: number;
      rate: { employee: number; employer: number };
    };
    ostie: {
      employeeTotal: number;
      employerTotal: number;
      total: number;
      rate: { employee: number; employer: number };
    };
  };
  
  // Autres revenus et dépenses
  otherFinances: {
    totalIncome: number;
    totalExpenses: number;
    netResult: number;
    byCategory: { [key: string]: number };
  };
  
  // Indicateurs clés
  kpis: {
    payrollRatio: number; // % du budget consacré aux salaires
    contributionRatio: number; // % des cotisations par rapport aux salaires
    averageSalary: number;
    medianSalary: number;
    salaryRange: { min: number; max: number };
  };
  
  // Projections
  projections: {
    annualPayrollCost: number;
    annualContributions: number;
    monthlyAverageExpenses: number;
  };
}

export interface PayrollReport {
  employee: {
    id: string;
    name: string;
    position: string;
    department: string;
  };
  salary: {
    gross: number;
    net: number;
    contributions: number;
    employerCost: number;
  };
  cnaps: {
    employee: number;
    employer: number;
    total: number;
  };
  ostie: {
    employee: number;
    employer: number;
    total: number;
  };
  period: string;
  reference: string;
}

export interface DepartmentAnalytics {
  department: string;
  employeeCount: number;
  totalGrossSalaries: number;
  totalNetSalaries: number;
  totalContributions: number;
  totalEmployerCost: number;
  averageSalary: number;
  budgetPercentage: number;
}

export class FinancialAnalyticsService {
  // Analyser les finances pour une période donnée
  static async analyzeFinances(startDate: string, endDate: string): Promise<FinancialAnalytics> {
    try {
      console.log(`📊 Analyse financière pour la période ${startDate} - ${endDate}`);
      
      // Récupérer les paramètres financiers
      const settings = await FinancialSettingsService.get();
      if (!settings) {
        throw new Error('Paramètres financiers non configurés');
      }
      
      // Récupérer les employés actifs
      const employeesSnapshot = await getDocs(
        query(collection(db, 'hierarchy'), where('status', '==', 'active'))
      );
      
      const employees = employeesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      
      // Calculer les données de paie
      let totalGrossSalaries = 0;
      let totalNetSalaries = 0;
      let totalEmployeeContributions = 0;
      let totalEmployerContributions = 0;
      let cnapsEmployeeTotal = 0;
      let cnapsEmployerTotal = 0;
      let ostieEmployeeTotal = 0;
      let ostieEmployerTotal = 0;
      
      const salaries: number[] = [];
      
      for (const employee of employees) {
        const salary = employee.salary || 0;
        salaries.push(salary);
        
        const contributions = FinancialSettingsService.calculateContributions(salary, settings);
        
        totalGrossSalaries += salary;
        totalNetSalaries += contributions.netSalary;
        totalEmployeeContributions += contributions.totalEmployee;
        totalEmployerContributions += contributions.totalEmployer;
        
        cnapsEmployeeTotal += contributions.cnaps.employee;
        cnapsEmployerTotal += contributions.cnaps.employer;
        ostieEmployeeTotal += contributions.ostie.employee;
        ostieEmployerTotal += contributions.ostie.employer;
      }
      
      // Récupérer les autres finances
      const financesSnapshot = await getDocs(
        query(
          collection(db, 'finances'),
          where('date', '>=', startDate),
          where('date', '<=', endDate)
        )
      );
      
      const finances = financesSnapshot.docs.map(doc => doc.data());
      const totalIncome = finances.filter(f => f.type === 'income').reduce((sum, f) => sum + f.amount, 0);
      const totalExpenses = finances.filter(f => f.type === 'expense').reduce((sum, f) => sum + f.amount, 0);
      
      // Calculer les indicateurs
      const averageSalary = salaries.length > 0 ? totalGrossSalaries / salaries.length : 0;
      const sortedSalaries = [...salaries].sort((a, b) => a - b);
      const medianSalary = sortedSalaries.length > 0 ? 
        sortedSalaries[Math.floor(sortedSalaries.length / 2)] : 0;
      
      const analytics: FinancialAnalytics = {
        period: {
          startDate,
          endDate,
          label: `${new Date(startDate).toLocaleDateString('fr-FR')} - ${new Date(endDate).toLocaleDateString('fr-FR')}`
        },
        
        payroll: {
          totalGrossSalaries,
          totalNetSalaries,
          totalEmployeeContributions,
          totalEmployerContributions,
          totalEmployerCost: totalGrossSalaries + totalEmployerContributions,
          employeeCount: employees.length
        },
        
        contributions: {
          cnaps: {
            employeeTotal: cnapsEmployeeTotal,
            employerTotal: cnapsEmployerTotal,
            total: cnapsEmployeeTotal + cnapsEmployerTotal,
            rate: {
              employee: settings.cnaps.employeeRate,
              employer: settings.cnaps.employerRate
            }
          },
          ostie: {
            employeeTotal: ostieEmployeeTotal,
            employerTotal: ostieEmployerTotal,
            total: ostieEmployeeTotal + ostieEmployerTotal,
            rate: {
              employee: settings.ostie.employeeRate,
              employer: settings.ostie.employerRate
            }
          }
        },
        
        otherFinances: {
          totalIncome,
          totalExpenses,
          netResult: totalIncome - totalExpenses,
          byCategory: this.groupByCategory(finances)
        },
        
        kpis: {
          payrollRatio: totalIncome > 0 ? (totalGrossSalaries / totalIncome) * 100 : 0,
          contributionRatio: totalGrossSalaries > 0 ? ((totalEmployeeContributions + totalEmployerContributions) / totalGrossSalaries) * 100 : 0,
          averageSalary,
          medianSalary,
          salaryRange: {
            min: Math.min(...salaries, 0),
            max: Math.max(...salaries, 0)
          }
        },
        
        projections: {
          annualPayrollCost: (totalGrossSalaries + totalEmployerContributions) * 12,
          annualContributions: (totalEmployeeContributions + totalEmployerContributions) * 12,
          monthlyAverageExpenses: totalExpenses
        }
      };
      
      return analytics;
    } catch (error) {
      console.error('Erreur lors de l\'analyse financière:', error);
      throw new Error('Impossible de générer l\'analyse financière');
    }
  }
  
  // Générer un rapport de paie pour tous les employés
  static async generatePayrollReport(paymentDate?: string): Promise<PayrollReport[]> {
    try {
      console.log('📋 Génération du rapport de paie...');
      
      const settings = await FinancialSettingsService.get();
      if (!settings) {
        throw new Error('Paramètres financiers non configurés');
      }
      
      // Récupérer les employés actifs
      const employeesSnapshot = await getDocs(
        query(collection(db, 'hierarchy'), where('status', '==', 'active'))
      );
      
      const employees = employeesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      
      const reports: PayrollReport[] = [];
      
      for (const employee of employees) {
        const salary = employee.salary || 0;
        const contributions = FinancialSettingsService.calculateContributions(salary, settings);
        
        reports.push({
          employee: {
            id: employee.id,
            name: `${employee.firstName} ${employee.lastName}`,
            position: employee.position,
            department: employee.department
          },
          salary: {
            gross: salary,
            net: contributions.netSalary,
            contributions: contributions.totalEmployee,
            employerCost: salary + contributions.totalEmployer
          },
          cnaps: {
            employee: contributions.cnaps.employee,
            employer: contributions.cnaps.employer,
            total: contributions.cnaps.total
          },
          ostie: {
            employee: contributions.ostie.employee,
            employer: contributions.ostie.employer,
            total: contributions.ostie.total
          },
          period: paymentDate || new Date().toISOString().split('T')[0],
          reference: PayrollService.generatePayrollReference(employee.id, paymentDate)
        });
      }
      
      return reports.sort((a, b) => a.employee.name.localeCompare(b.employee.name));
    } catch (error) {
      console.error('Erreur lors de la génération du rapport de paie:', error);
      throw new Error('Impossible de générer le rapport de paie');
    }
  }
  
  // Analyser par département
  static async analyzeDepartments(): Promise<DepartmentAnalytics[]> {
    try {
      console.log('🏢 Analyse par département...');
      
      const settings = await FinancialSettingsService.get();
      if (!settings) {
        throw new Error('Paramètres financiers non configurés');
      }
      
      // Récupérer les employés actifs
      const employeesSnapshot = await getDocs(
        query(collection(db, 'hierarchy'), where('status', '==', 'active'))
      );
      
      const employees = employeesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      
      // Grouper par département
      const departmentGroups: { [key: string]: any[] } = {};
      employees.forEach(employee => {
        const dept = employee.department || 'Non défini';
        if (!departmentGroups[dept]) {
          departmentGroups[dept] = [];
        }
        departmentGroups[dept].push(employee);
      });
      
      const totalBudget = employees.reduce((sum, emp) => sum + (emp.salary || 0), 0);
      
      const analytics: DepartmentAnalytics[] = [];
      
      Object.entries(departmentGroups).forEach(([department, deptEmployees]) => {
        let totalGrossSalaries = 0;
        let totalNetSalaries = 0;
        let totalContributions = 0;
        let totalEmployerCost = 0;
        
        deptEmployees.forEach(employee => {
          const salary = employee.salary || 0;
          const contributions = FinancialSettingsService.calculateContributions(salary, settings);
          
          totalGrossSalaries += salary;
          totalNetSalaries += contributions.netSalary;
          totalContributions += contributions.totalEmployee + contributions.totalEmployer;
          totalEmployerCost += salary + contributions.totalEmployer;
        });
        
        analytics.push({
          department,
          employeeCount: deptEmployees.length,
          totalGrossSalaries,
          totalNetSalaries,
          totalContributions,
          totalEmployerCost,
          averageSalary: deptEmployees.length > 0 ? totalGrossSalaries / deptEmployees.length : 0,
          budgetPercentage: totalBudget > 0 ? (totalGrossSalaries / totalBudget) * 100 : 0
        });
      });
      
      return analytics.sort((a, b) => b.totalGrossSalaries - a.totalGrossSalaries);
    } catch (error) {
      console.error('Erreur lors de l\'analyse par département:', error);
      throw new Error('Impossible d\'analyser les départements');
    }
  }
  
  // Calculer les projections annuelles
  static async calculateAnnualProjections(): Promise<{
    payroll: number;
    cnapsContributions: number;
    ostieContributions: number;
    totalEmployerCost: number;
    monthlyAverage: number;
  }> {
    try {
      const currentMonth = await this.analyzeFinances(
        new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0],
        new Date().toISOString().split('T')[0]
      );
      
      return {
        payroll: currentMonth.payroll.totalGrossSalaries * 12,
        cnapsContributions: currentMonth.contributions.cnaps.total * 12,
        ostieContributions: currentMonth.contributions.ostie.total * 12,
        totalEmployerCost: currentMonth.payroll.totalEmployerCost * 12,
        monthlyAverage: currentMonth.payroll.totalEmployerCost
      };
    } catch (error) {
      console.error('Erreur lors du calcul des projections:', error);
      throw new Error('Impossible de calculer les projections annuelles');
    }
  }
  
  // Comparer les périodes
  static async comparePeriods(
    period1: { start: string; end: string },
    period2: { start: string; end: string }
  ): Promise<{
    period1: FinancialAnalytics;
    period2: FinancialAnalytics;
    comparison: {
      payrollGrowth: number;
      contributionsGrowth: number;
      employeeGrowth: number;
      averageSalaryGrowth: number;
    };
  }> {
    try {
      const [analytics1, analytics2] = await Promise.all([
        this.analyzeFinances(period1.start, period1.end),
        this.analyzeFinances(period2.start, period2.end)
      ]);
      
      const comparison = {
        payrollGrowth: this.calculateGrowthRate(
          analytics1.payroll.totalGrossSalaries,
          analytics2.payroll.totalGrossSalaries
        ),
        contributionsGrowth: this.calculateGrowthRate(
          analytics1.payroll.totalEmployeeContributions + analytics1.payroll.totalEmployerContributions,
          analytics2.payroll.totalEmployeeContributions + analytics2.payroll.totalEmployerContributions
        ),
        employeeGrowth: this.calculateGrowthRate(
          analytics1.payroll.employeeCount,
          analytics2.payroll.employeeCount
        ),
        averageSalaryGrowth: this.calculateGrowthRate(
          analytics1.kpis.averageSalary,
          analytics2.kpis.averageSalary
        )
      };
      
      return {
        period1: analytics1,
        period2: analytics2,
        comparison
      };
    } catch (error) {
      console.error('Erreur lors de la comparaison des périodes:', error);
      throw new Error('Impossible de comparer les périodes');
    }
  }
  
  // Générer un rapport de conformité CNAPS/OSTIE
  static async generateComplianceReport(): Promise<{
    cnaps: {
      isConfigured: boolean;
      isActive: boolean;
      currentRates: { employee: number; employer: number };
      recommendedRates: { employee: number; employer: number };
      compliance: 'compliant' | 'warning' | 'non_compliant';
      issues: string[];
    };
    ostie: {
      isConfigured: boolean;
      isActive: boolean;
      currentRates: { employee: number; employer: number };
      recommendedRates: { employee: number; employer: number };
      compliance: 'compliant' | 'warning' | 'non_compliant';
      issues: string[];
    };
    overall: {
      compliance: 'compliant' | 'warning' | 'non_compliant';
      score: number;
      recommendations: string[];
    };
  }> {
    try {
      const settings = await FinancialSettingsService.get();
      const defaultSettings = FinancialSettingsService.getDefaultSettings();
      
      const cnapsIssues: string[] = [];
      const ostieIssues: string[] = [];
      const recommendations: string[] = [];
      
      // Vérifier CNAPS
      let cnapsCompliance: 'compliant' | 'warning' | 'non_compliant' = 'compliant';
      if (!settings) {
        cnapsCompliance = 'non_compliant';
        cnapsIssues.push('Paramètres CNAPS non configurés');
      } else if (!settings.cnaps.isActive) {
        cnapsCompliance = 'warning';
        cnapsIssues.push('CNAPS désactivé - Vérifiez la conformité légale');
      } else {
        if (settings.cnaps.employeeRate !== defaultSettings.cnaps.employeeRate) {
          cnapsCompliance = 'warning';
          cnapsIssues.push(`Taux salarié CNAPS (${settings.cnaps.employeeRate}%) différent du taux recommandé (${defaultSettings.cnaps.employeeRate}%)`);
        }
        if (settings.cnaps.employerRate !== defaultSettings.cnaps.employerRate) {
          cnapsCompliance = 'warning';
          cnapsIssues.push(`Taux employeur CNAPS (${settings.cnaps.employerRate}%) différent du taux recommandé (${defaultSettings.cnaps.employerRate}%)`);
        }
      }
      
      // Vérifier OSTIE
      let ostieCompliance: 'compliant' | 'warning' | 'non_compliant' = 'compliant';
      if (!settings) {
        ostieCompliance = 'non_compliant';
        ostieIssues.push('Paramètres OSTIE non configurés');
      } else if (!settings.ostie.isActive) {
        ostieCompliance = 'warning';
        ostieIssues.push('OSTIE désactivé - Vérifiez la conformité légale');
      } else {
        if (settings.ostie.employeeRate !== defaultSettings.ostie.employeeRate) {
          ostieCompliance = 'warning';
          ostieIssues.push(`Taux salarié OSTIE (${settings.ostie.employeeRate}%) différent du taux recommandé (${defaultSettings.ostie.employeeRate}%)`);
        }
        if (settings.ostie.employerRate !== defaultSettings.ostie.employerRate) {
          ostieCompliance = 'warning';
          ostieIssues.push(`Taux employeur OSTIE (${settings.ostie.employerRate}%) différent du taux recommandé (${defaultSettings.ostie.employerRate}%)`);
        }
      }
      
      // Évaluation globale
      let overallCompliance: 'compliant' | 'warning' | 'non_compliant' = 'compliant';
      let score = 100;
      
      if (cnapsCompliance === 'non_compliant' || ostieCompliance === 'non_compliant') {
        overallCompliance = 'non_compliant';
        score = 0;
      } else if (cnapsCompliance === 'warning' || ostieCompliance === 'warning') {
        overallCompliance = 'warning';
        score = 75;
      }
      
      // Recommandations
      if (!settings) {
        recommendations.push('Configurez immédiatement les paramètres CNAPS et OSTIE');
      } else {
        if (cnapsIssues.length > 0) {
          recommendations.push('Vérifiez les taux CNAPS avec la réglementation en vigueur');
        }
        if (ostieIssues.length > 0) {
          recommendations.push('Vérifiez les taux OSTIE avec l\'organisme');
        }
        if (settings.cnaps.isActive && settings.ostie.isActive) {
          recommendations.push('Effectuez les déclarations mensuelles dans les délais');
        }
      }
      
      return {
        cnaps: {
          isConfigured: !!settings,
          isActive: settings?.cnaps.isActive || false,
          currentRates: {
            employee: settings?.cnaps.employeeRate || 0,
            employer: settings?.cnaps.employerRate || 0
          },
          recommendedRates: {
            employee: defaultSettings.cnaps.employeeRate,
            employer: defaultSettings.cnaps.employerRate
          },
          compliance: cnapsCompliance,
          issues: cnapsIssues
        },
        ostie: {
          isConfigured: !!settings,
          isActive: settings?.ostie.isActive || false,
          currentRates: {
            employee: settings?.ostie.employeeRate || 0,
            employer: settings?.ostie.employerRate || 0
          },
          recommendedRates: {
            employee: defaultSettings.ostie.employeeRate,
            employer: defaultSettings.ostie.employerRate
          },
          compliance: ostieCompliance,
          issues: ostieIssues
        },
        overall: {
          compliance: overallCompliance,
          score,
          recommendations
        }
      };
    } catch (error) {
      console.error('Erreur lors de la génération du rapport de conformité:', error);
      throw new Error('Impossible de générer le rapport de conformité');
    }
  }
  
  // Méthodes utilitaires
  private static groupByCategory(finances: any[]): { [key: string]: number } {
    const grouped: { [key: string]: number } = {};
    
    finances.forEach(finance => {
      const key = `${finance.type}_${finance.category}`;
      grouped[key] = (grouped[key] || 0) + finance.amount;
    });
    
    return grouped;
  }
  
  private static calculateGrowthRate(oldValue: number, newValue: number): number {
    if (oldValue === 0) return newValue > 0 ? 100 : 0;
    return ((newValue - oldValue) / oldValue) * 100;
  }
  
  // Exporter les données en CSV
  static exportPayrollToCSV(reports: PayrollReport[]): string {
    const headers = [
      'Employé',
      'Poste',
      'Département',
      'Salaire Brut',
      'CNAPS Salarié',
      'CNAPS Employeur',
      'OSTIE Salarié', 
      'OSTIE Employeur',
      'Total Cotisations',
      'Salaire Net',
      'Coût Employeur',
      'Référence'
    ];
    
    const rows = reports.map(report => [
      report.employee.name,
      report.employee.position,
      report.employee.department,
      report.salary.gross,
      report.cnaps.employee,
      report.cnaps.employer,
      report.ostie.employee,
      report.ostie.employer,
      report.salary.contributions,
      report.salary.net,
      report.salary.employerCost,
      report.reference
    ]);
    
    return [headers, ...rows].map(row => row.join(',')).join('\n');
  }
  
  // Exporter l'analyse en JSON
  static exportAnalyticsToJSON(analytics: FinancialAnalytics): string {
    return JSON.stringify(analytics, null, 2);
  }
}