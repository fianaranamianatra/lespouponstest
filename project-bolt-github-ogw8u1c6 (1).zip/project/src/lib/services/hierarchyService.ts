import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  query, 
  where, 
  orderBy,
  serverTimestamp,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../firebase';

export interface HierarchyEmployee {
  id?: string;
  firstName: string;
  lastName: string;
  position: string;
  department: string;
  parentId?: string;
  level: number;
  email: string;
  phone: string;
  salary: number;
  hireDate: string;
  status: 'active' | 'inactive';
  createdAt?: Date;
  updatedAt?: Date;
}

const COLLECTION_NAME = 'hierarchy';

export class HierarchyService {
  static async create(employeeData: Omit<HierarchyEmployee, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    // Validation basique
    if (!employeeData.firstName || !employeeData.lastName || !employeeData.position) {
      throw new Error('Données employé incomplètes');
    }

    try {
      const docData = {
        ...employeeData,
        level: employeeData.level || 1,
        salary: Number(employeeData.salary),
        hireDate: employeeData.hireDate || new Date().toISOString().split('T')[0],
        status: employeeData.status || 'active',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      const docRef = await addDoc(collection(db, COLLECTION_NAME), docData);
      return docRef.id;
    } catch (error) {
      console.error('Erreur lors de la création de l\'employé:', error);
      throw new Error('Impossible de créer l\'employé');
    }
  }

  static async update(id: string, updates: Partial<HierarchyEmployee>): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      
      // Si le salaire est mis à jour, s'assurer qu'il est un nombre
      if (updates.salary !== undefined) {
        updates.salary = Number(updates.salary);
      }
      
      await updateDoc(docRef, {
        ...updates,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Erreur lors de la mise à jour de l\'employé:', error);
      throw new Error('Impossible de mettre à jour l\'employé');
    }
  }

  static async delete(id: string): Promise<void> {
    try {
      // Vérifier si cet employé a des subordonnés
      const subordinatesQuery = query(
        collection(db, COLLECTION_NAME),
        where('parentId', '==', id)
      );
      const subordinatesSnapshot = await getDocs(subordinatesQuery);
      
      if (!subordinatesSnapshot.empty) {
        throw new Error('Impossible de supprimer un employé qui a des subordonnés');
      }
      
      const docRef = doc(db, COLLECTION_NAME, id);
      await deleteDoc(docRef);
    } catch (error) {
      console.error('Erreur lors de la suppression de l\'employé:', error);
      throw new Error('Impossible de supprimer l\'employé');
    }
  }

  static async getAll(): Promise<HierarchyEmployee[]> {
    try {
      const q = query(collection(db, COLLECTION_NAME), orderBy('level'), orderBy('lastName'));
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as HierarchyEmployee;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des employés:', error);
      throw new Error('Impossible de récupérer les employés');
    }
  }

  static async getByDepartment(department: string): Promise<HierarchyEmployee[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('department', '==', department),
        orderBy('level'),
        orderBy('lastName')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as HierarchyEmployee;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des employés par département:', error);
      throw new Error('Impossible de récupérer les employés de ce département');
    }
  }

  static async getByLevel(level: number): Promise<HierarchyEmployee[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('level', '==', level),
        orderBy('lastName')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as HierarchyEmployee;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des employés par niveau:', error);
      throw new Error('Impossible de récupérer les employés de ce niveau');
    }
  }

  static async getSubordinates(parentId: string): Promise<HierarchyEmployee[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('parentId', '==', parentId),
        orderBy('level'),
        orderBy('lastName')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as HierarchyEmployee;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des subordonnés:', error);
      throw new Error('Impossible de récupérer les subordonnés');
    }
  }

  static onSnapshot(callback: (employees: HierarchyEmployee[]) => void) {
    const q = query(collection(db, COLLECTION_NAME), orderBy('level'), orderBy('lastName'));
    
    return onSnapshot(q, (snapshot) => {
      const employees = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as HierarchyEmployee;
      });
      callback(employees);
    });
  }

  // Calculer la masse salariale
  static async getTotalSalary(): Promise<number> {
    try {
      const employees = await this.getAll();
      return employees.reduce((total, employee) => total + employee.salary, 0);
    } catch (error) {
      console.error('Erreur lors du calcul de la masse salariale:', error);
      throw new Error('Impossible de calculer la masse salariale');
    }
  }

  // Obtenir la structure hiérarchique complète
  static async getHierarchyTree(): Promise<any> {
    try {
      const employees = await this.getAll();
      
      // Trouver la racine (niveau 1, sans parent)
      const roots = employees.filter(e => e.level === 1);
      
      // Construire l'arbre récursivement
      const buildTree = (node: HierarchyEmployee) => {
        const children = employees.filter(e => e.parentId === node.id);
        return {
          ...node,
          children: children.map(buildTree)
        };
      };
      
      return roots.map(buildTree);
    } catch (error) {
      console.error('Erreur lors de la récupération de la structure hiérarchique:', error);
      throw new Error('Impossible de récupérer la structure hiérarchique');
    }
  }
}