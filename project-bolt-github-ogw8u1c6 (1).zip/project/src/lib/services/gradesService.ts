import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  query, 
  where, 
  orderBy,
  serverTimestamp,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../firebase';
import { validateData, gradeValidationSchema } from '../validation';

export interface Grade {
  id?: string;
  studentId: string;
  studentName: string;
  subject: string;
  class: string;
  assignment: string;
  grade: number;
  maxGrade: number;
  date: string;
  teacher: string;
  type: 'exam' | 'homework' | 'quiz' | 'project';
  createdAt?: Date;
  updatedAt?: Date;
}

const COLLECTION_NAME = 'grades';

export class GradesService {
  static async create(gradeData: Omit<Grade, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    const validation = validateData(gradeData, gradeValidationSchema);
    if (!validation.isValid) {
      throw new Error(`Données invalides: ${Object.values(validation.errors).join(', ')}`);
    }

    // Validation métier: la note ne peut pas dépasser la note maximale
    if (gradeData.grade > gradeData.maxGrade) {
      throw new Error('La note ne peut pas dépasser la note maximale');
    }

    try {
      const docData = {
        ...gradeData,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      const docRef = await addDoc(collection(db, COLLECTION_NAME), docData);
      return docRef.id;
    } catch (error) {
      console.error('Erreur lors de la création de la note:', error);
      throw new Error('Impossible de créer la note');
    }
  }

  static async update(id: string, updates: Partial<Grade>): Promise<void> {
    const validation = validateData(updates, gradeValidationSchema);
    if (!validation.isValid) {
      throw new Error(`Données invalides: ${Object.values(validation.errors).join(', ')}`);
    }

    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await updateDoc(docRef, {
        ...updates,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Erreur lors de la mise à jour de la note:', error);
      throw new Error('Impossible de mettre à jour la note');
    }
  }

  static async delete(id: string): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await deleteDoc(docRef);
    } catch (error) {
      console.error('Erreur lors de la suppression de la note:', error);
      throw new Error('Impossible de supprimer la note');
    }
  }

  static async getAll(): Promise<Grade[]> {
    try {
      const q = query(collection(db, COLLECTION_NAME), orderBy('date', 'desc'));
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Grade;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des notes:', error);
      throw new Error('Impossible de récupérer les notes');
    }
  }

  static async getByStudent(studentId: string): Promise<Grade[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('studentId', '==', studentId),
        orderBy('date', 'desc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Grade;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des notes de l\'élève:', error);
      throw new Error('Impossible de récupérer les notes de cet élève');
    }
  }

  static async getByClass(className: string): Promise<Grade[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('class', '==', className),
        orderBy('date', 'desc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Grade;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des notes de la classe:', error);
      throw new Error('Impossible de récupérer les notes de cette classe');
    }
  }

  static onSnapshot(callback: (grades: Grade[]) => void) {
    const q = query(collection(db, COLLECTION_NAME), orderBy('date', 'desc'));
    
    return onSnapshot(q, (snapshot) => {
      const grades = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Grade;
      });
      callback(grades);
    });
  }

  // Calculer la moyenne d'un élève
  static async getStudentAverage(studentId: string, subject?: string): Promise<number> {
    try {
      let q = query(
        collection(db, COLLECTION_NAME), 
        where('studentId', '==', studentId)
      );

      if (subject) {
        q = query(q, where('subject', '==', subject));
      }

      const querySnapshot = await getDocs(q);
      const grades = querySnapshot.docs.map(doc => doc.data() as Grade);

      if (grades.length === 0) return 0;

      const totalPercentage = grades.reduce((sum, grade) => {
        return sum + (grade.grade / grade.maxGrade) * 20;
      }, 0);

      return totalPercentage / grades.length;
    } catch (error) {
      console.error('Erreur lors du calcul de la moyenne:', error);
      throw new Error('Impossible de calculer la moyenne');
    }
  }

  // Calculer la moyenne de classe
  static async getClassAverage(className: string, subject?: string): Promise<number> {
    try {
      let q = query(
        collection(db, COLLECTION_NAME), 
        where('class', '==', className)
      );

      if (subject) {
        q = query(q, where('subject', '==', subject));
      }

      const querySnapshot = await getDocs(q);
      const grades = querySnapshot.docs.map(doc => doc.data() as Grade);

      if (grades.length === 0) return 0;

      const totalPercentage = grades.reduce((sum, grade) => {
        return sum + (grade.grade / grade.maxGrade) * 20;
      }, 0);

      return totalPercentage / grades.length;
    } catch (error) {
      console.error('Erreur lors du calcul de la moyenne de classe:', error);
      throw new Error('Impossible de calculer la moyenne de classe');
    }
  }
}