import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  query, 
  where, 
  orderBy,
  serverTimestamp,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../firebase';
import { validateData, scheduleValidationSchema } from '../validation';

export interface Schedule {
  id?: string;
  class: string;
  subject: string;
  teacher: string;
  day: string;
  startTime: string;
  endTime: string;
  room: string;
  type: 'course' | 'exam' | 'tp' | 'sport' | 'break';
  createdAt?: Date;
  updatedAt?: Date;
}

const COLLECTION_NAME = 'schedules';

export class SchedulesService {
  static async create(scheduleData: Omit<Schedule, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    const validation = validateData(scheduleData, scheduleValidationSchema);
    if (!validation.isValid) {
      throw new Error(`Données invalides: ${Object.values(validation.errors).join(', ')}`);
    }

    // Validation métier: l'heure de fin doit être après l'heure de début
    if (scheduleData.startTime >= scheduleData.endTime) {
      throw new Error('L\'heure de fin doit être après l\'heure de début');
    }

    // Vérifier les conflits d'horaire
    const conflicts = await this.checkTimeConflicts(
      scheduleData.class,
      scheduleData.day,
      scheduleData.startTime,
      scheduleData.endTime,
      scheduleData.room
    );

    if (conflicts.length > 0) {
      throw new Error('Conflit d\'horaire détecté avec un autre cours');
    }

    try {
      const docData = {
        ...scheduleData,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      const docRef = await addDoc(collection(db, COLLECTION_NAME), docData);
      return docRef.id;
    } catch (error) {
      console.error('Erreur lors de la création du créneau:', error);
      throw new Error('Impossible de créer le créneau');
    }
  }

  static async update(id: string, updates: Partial<Schedule>): Promise<void> {
    const validation = validateData(updates, scheduleValidationSchema);
    if (!validation.isValid) {
      throw new Error(`Données invalides: ${Object.values(validation.errors).join(', ')}`);
    }

    // Validation métier si les heures sont modifiées
    if (updates.startTime && updates.endTime && updates.startTime >= updates.endTime) {
      throw new Error('L\'heure de fin doit être après l\'heure de début');
    }

    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await updateDoc(docRef, {
        ...updates,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Erreur lors de la mise à jour du créneau:', error);
      throw new Error('Impossible de mettre à jour le créneau');
    }
  }

  static async delete(id: string): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await deleteDoc(docRef);
    } catch (error) {
      console.error('Erreur lors de la suppression du créneau:', error);
      throw new Error('Impossible de supprimer le créneau');
    }
  }

  static async getAll(): Promise<Schedule[]> {
    try {
      const q = query(collection(db, COLLECTION_NAME), orderBy('day'), orderBy('startTime'));
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Schedule;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des créneaux:', error);
      throw new Error('Impossible de récupérer les créneaux');
    }
  }

  static async getByClass(className: string): Promise<Schedule[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('class', '==', className),
        orderBy('day'),
        orderBy('startTime')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Schedule;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des créneaux par classe:', error);
      throw new Error('Impossible de récupérer les créneaux de cette classe');
    }
  }

  static async getByTeacher(teacherName: string): Promise<Schedule[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('teacher', '==', teacherName),
        orderBy('day'),
        orderBy('startTime')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Schedule;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des créneaux par enseignant:', error);
      throw new Error('Impossible de récupérer les créneaux de cet enseignant');
    }
  }

  static onSnapshot(callback: (schedules: Schedule[]) => void) {
    const q = query(collection(db, COLLECTION_NAME), orderBy('day'), orderBy('startTime'));
    
    return onSnapshot(q, (snapshot) => {
      const schedules = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Schedule;
      });
      callback(schedules);
    });
  }

  // Vérifier les conflits d'horaire
  static async checkTimeConflicts(
    className: string,
    day: string,
    startTime: string,
    endTime: string,
    room: string,
    excludeId?: string
  ): Promise<Schedule[]> {
    try {
      // Vérifier les conflits pour la classe
      const classQuery = query(
        collection(db, COLLECTION_NAME),
        where('class', '==', className),
        where('day', '==', day)
      );
      
      // Vérifier les conflits pour la salle
      const roomQuery = query(
        collection(db, COLLECTION_NAME),
        where('room', '==', room),
        where('day', '==', day)
      );
      
      const [classSnapshot, roomSnapshot] = await Promise.all([
        getDocs(classQuery),
        getDocs(roomQuery)
      ]);
      
      // Combiner les résultats et éliminer les doublons
      const allDocs = [...classSnapshot.docs, ...roomSnapshot.docs];
      const uniqueDocs = Array.from(new Set(allDocs.map(doc => doc.id)))
        .map(id => allDocs.find(doc => doc.id === id)!);
      
      // Filtrer les conflits d'horaire
      const conflicts = uniqueDocs
        .filter(doc => !excludeId || doc.id !== excludeId)
        .map(doc => ({
          id: doc.id,
          ...doc.data()
        } as Schedule))
        .filter(schedule => {
          // Vérifier si les horaires se chevauchent
          return (
            (startTime >= schedule.startTime && startTime < schedule.endTime) ||
            (endTime > schedule.startTime && endTime <= schedule.endTime) ||
            (startTime <= schedule.startTime && endTime >= schedule.endTime)
          );
        });
      
      return conflicts;
    } catch (error) {
      console.error('Erreur lors de la vérification des conflits d\'horaire:', error);
      return [];
    }
  }
}