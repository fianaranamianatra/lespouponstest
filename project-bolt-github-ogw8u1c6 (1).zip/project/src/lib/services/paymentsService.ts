import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  query, 
  where, 
  orderBy,
  serverTimestamp,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../firebase';
import { validateData, paymentValidationSchema } from '../validation';

export interface Payment {
  id?: string;
  studentId: string;
  studentName: string;
  class: string;
  amount: number;
  paymentMethod: string;
  paymentDate: string;
  period: string;
  status: 'paid' | 'pending' | 'overdue';
  reference: string;
  notes?: string;
  createdAt?: Date;
  updatedAt?: Date;
}

const COLLECTION_NAME = 'payments';

export class PaymentsService {
  static async create(paymentData: Omit<Payment, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    const validation = validateData(paymentData, paymentValidationSchema);
    if (!validation.isValid) {
      throw new Error(`Données invalides: ${Object.values(validation.errors).join(', ')}`);
    }

    // Vérifier l'unicité de la référence
    const existingPayment = await this.getByReference(paymentData.reference);
    if (existingPayment) {
      throw new Error('Cette référence de paiement existe déjà');
    }

    try {
      const docData = {
        ...paymentData,
        status: paymentData.status || 'paid',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      const docRef = await addDoc(collection(db, COLLECTION_NAME), docData);
      return docRef.id;
    } catch (error) {
      console.error('Erreur lors de la création du paiement:', error);
      throw new Error('Impossible de créer le paiement');
    }
  }

  static async update(id: string, updates: Partial<Payment>): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await updateDoc(docRef, {
        ...updates,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Erreur lors de la mise à jour du paiement:', error);
      throw new Error('Impossible de mettre à jour le paiement');
    }
  }

  static async delete(id: string): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await deleteDoc(docRef);
    } catch (error) {
      console.error('Erreur lors de la suppression du paiement:', error);
      throw new Error('Impossible de supprimer le paiement');
    }
  }

  static async getAll(): Promise<Payment[]> {
    try {
      const q = query(collection(db, COLLECTION_NAME), orderBy('paymentDate', 'desc'));
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Payment;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des paiements:', error);
      throw new Error('Impossible de récupérer les paiements');
    }
  }

  static async getByStudent(studentId: string): Promise<Payment[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('studentId', '==', studentId),
        orderBy('paymentDate', 'desc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Payment;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des paiements de l\'élève:', error);
      throw new Error('Impossible de récupérer les paiements de cet élève');
    }
  }

  static async getByReference(reference: string): Promise<Payment | null> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('reference', '==', reference)
      );
      const querySnapshot = await getDocs(q);
      
      if (querySnapshot.empty) return null;
      
      const doc = querySnapshot.docs[0];
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        createdAt: data.createdAt?.toDate(),
        updatedAt: data.updatedAt?.toDate()
      } as Payment;
    } catch (error) {
      console.error('Erreur lors de la recherche par référence:', error);
      return null;
    }
  }

  static async getByStatus(status: 'paid' | 'pending' | 'overdue'): Promise<Payment[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('status', '==', status),
        orderBy('paymentDate', 'desc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Payment;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des paiements par statut:', error);
      throw new Error('Impossible de récupérer les paiements');
    }
  }

  static onSnapshot(callback: (payments: Payment[]) => void) {
    const q = query(collection(db, COLLECTION_NAME), orderBy('paymentDate', 'desc'));
    
    return onSnapshot(q, (snapshot) => {
      const payments = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Payment;
      });
      callback(payments);
    });
  }

  // Calculer les statistiques financières
  static async getFinancialStats() {
    try {
      const payments = await this.getAll();
      
      const stats = {
        totalRevenue: 0,
        paidAmount: 0,
        pendingAmount: 0,
        overdueAmount: 0,
        totalTransactions: payments.length,
        byMethod: {} as { [key: string]: number },
        byPeriod: {} as { [key: string]: number }
      };

      payments.forEach(payment => {
        stats.totalRevenue += payment.amount;
        
        switch (payment.status) {
          case 'paid':
            stats.paidAmount += payment.amount;
            break;
          case 'pending':
            stats.pendingAmount += payment.amount;
            break;
          case 'overdue':
            stats.overdueAmount += payment.amount;
            break;
        }

        // Par méthode de paiement
        stats.byMethod[payment.paymentMethod] = 
          (stats.byMethod[payment.paymentMethod] || 0) + payment.amount;

        // Par période
        stats.byPeriod[payment.period] = 
          (stats.byPeriod[payment.period] || 0) + payment.amount;
      });

      return stats;
    } catch (error) {
      console.error('Erreur lors du calcul des statistiques financières:', error);
      throw new Error('Impossible de calculer les statistiques financières');
    }
  }

  // Générer une référence unique
  static generateReference(): string {
    const timestamp = Date.now().toString().slice(-6);
    const random = Math.random().toString(36).substring(2, 5).toUpperCase();
    return `PAY-${timestamp}-${random}`;
  }
}