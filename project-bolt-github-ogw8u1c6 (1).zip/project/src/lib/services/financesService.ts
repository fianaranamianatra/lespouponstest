import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  query, 
  where, 
  orderBy,
  serverTimestamp,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../firebase';

export interface Finance {
  id?: string;
  type: 'income' | 'expense';
  category: string;
  amount: number;
  description: string;
  date: string;
  reference?: string;
  createdAt?: Date;
  updatedAt?: Date;
}

const COLLECTION_NAME = 'finances';

export class FinancesService {
  static async create(financeData: Omit<Finance, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    // Validation basique
    if (!financeData.type || !financeData.category || !financeData.amount || !financeData.date) {
      throw new Error('Données financières incomplètes');
    }

    try {
      const docData = {
        ...financeData,
        amount: Number(financeData.amount),
        date: financeData.date || new Date().toISOString().split('T')[0],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      const docRef = await addDoc(collection(db, COLLECTION_NAME), docData);
      return docRef.id;
    } catch (error) {
      console.error('Erreur lors de la création de l\'entrée financière:', error);
      throw new Error('Impossible de créer l\'entrée financière');
    }
  }

  static async update(id: string, updates: Partial<Finance>): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      
      // Si le montant est mis à jour, s'assurer qu'il est un nombre
      if (updates.amount !== undefined) {
        updates.amount = Number(updates.amount);
      }
      
      await updateDoc(docRef, {
        ...updates,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Erreur lors de la mise à jour de l\'entrée financière:', error);
      throw new Error('Impossible de mettre à jour l\'entrée financière');
    }
  }

  static async delete(id: string): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await deleteDoc(docRef);
    } catch (error) {
      console.error('Erreur lors de la suppression de l\'entrée financière:', error);
      throw new Error('Impossible de supprimer l\'entrée financière');
    }
  }

  static async getAll(): Promise<Finance[]> {
    try {
      const q = query(collection(db, COLLECTION_NAME), orderBy('date', 'desc'));
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Finance;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des données financières:', error);
      throw new Error('Impossible de récupérer les données financières');
    }
  }

  static async getByType(type: 'income' | 'expense'): Promise<Finance[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('type', '==', type),
        orderBy('date', 'desc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Finance;
      });
    } catch (error) {
      console.error(`Erreur lors de la récupération des ${type}s:`, error);
      throw new Error(`Impossible de récupérer les ${type}s`);
    }
  }

  static async getByCategory(category: string): Promise<Finance[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('category', '==', category),
        orderBy('date', 'desc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Finance;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des données par catégorie:', error);
      throw new Error('Impossible de récupérer les données pour cette catégorie');
    }
  }

  static async getByDateRange(startDate: string, endDate: string): Promise<Finance[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('date', '>=', startDate),
        where('date', '<=', endDate),
        orderBy('date', 'desc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Finance;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des données par période:', error);
      throw new Error('Impossible de récupérer les données pour cette période');
    }
  }

  static onSnapshot(callback: (finances: Finance[]) => void) {
    const q = query(collection(db, COLLECTION_NAME), orderBy('date', 'desc'));
    
    return onSnapshot(q, (snapshot) => {
      const finances = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Finance;
      });
      callback(finances);
    });
  }

  // Calculer les totaux
  static async getFinancialSummary(): Promise<{
    totalIncome: number;
    totalExpense: number;
    balance: number;
    byCategory: {[key: string]: number};
  }> {
    try {
      const finances = await this.getAll();
      
      const summary = {
        totalIncome: 0,
        totalExpense: 0,
        balance: 0,
        byCategory: {} as {[key: string]: number}
      };
      
      finances.forEach(item => {
        if (item.type === 'income') {
          summary.totalIncome += item.amount;
        } else {
          summary.totalExpense += item.amount;
        }
        
        // Agréger par catégorie
        const categoryKey = `${item.type}_${item.category}`;
        summary.byCategory[categoryKey] = (summary.byCategory[categoryKey] || 0) + item.amount;
      });
      
      summary.balance = summary.totalIncome - summary.totalExpense;
      
      return summary;
    } catch (error) {
      console.error('Erreur lors du calcul des résumés financiers:', error);
      throw new Error('Impossible de calculer les résumés financiers');
    }
  }
}