import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs, 
  getDoc,
  query, 
  where, 
  orderBy,
  serverTimestamp,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../firebase';
import { validateData, teacherValidationSchema } from '../validation';

export interface Teacher {
  id?: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  subject: string;
  classes: string[];
  experience: number;
  status: 'active' | 'inactive';
  createdAt?: Date;
  updatedAt?: Date;
}

const COLLECTION_NAME = 'teachers';

export class TeachersService {
  static async create(teacherData: Omit<Teacher, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    const validation = validateData(teacherData, teacherValidationSchema);
    if (!validation.isValid) {
      throw new Error(`Données invalides: ${Object.values(validation.errors).join(', ')}`);
    }

    try {
      const docData = {
        ...teacherData,
        classes: teacherData.classes || [],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      const docRef = await addDoc(collection(db, COLLECTION_NAME), docData);
      return docRef.id;
    } catch (error) {
      console.error('Erreur lors de la création de l\'enseignant:', error);
      throw new Error('Impossible de créer l\'enseignant');
    }
  }

  static async update(id: string, updates: Partial<Teacher>): Promise<void> {
    const validation = validateData(updates, teacherValidationSchema);
    if (!validation.isValid) {
      throw new Error(`Données invalides: ${Object.values(validation.errors).join(', ')}`);
    }

    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await updateDoc(docRef, {
        ...updates,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Erreur lors de la mise à jour de l\'enseignant:', error);
      throw new Error('Impossible de mettre à jour l\'enseignant');
    }
  }

  static async delete(id: string): Promise<void> {
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await deleteDoc(docRef);
    } catch (error) {
      console.error('Erreur lors de la suppression de l\'enseignant:', error);
      throw new Error('Impossible de supprimer l\'enseignant');
    }
  }

  static async getAll(): Promise<Teacher[]> {
    try {
      const q = query(collection(db, COLLECTION_NAME), orderBy('lastName', 'asc'));
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Teacher;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des enseignants:', error);
      throw new Error('Impossible de récupérer les enseignants');
    }
  }

  static async getBySubject(subject: string): Promise<Teacher[]> {
    try {
      const q = query(
        collection(db, COLLECTION_NAME), 
        where('subject', '==', subject),
        orderBy('lastName', 'asc')
      );
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Teacher;
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des enseignants par matière:', error);
      throw new Error('Impossible de récupérer les enseignants de cette matière');
    }
  }

  static onSnapshot(callback: (teachers: Teacher[]) => void) {
    const q = query(collection(db, COLLECTION_NAME), orderBy('lastName', 'asc'));
    
    return onSnapshot(q, (snapshot) => {
      const teachers = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as Teacher;
      });
      callback(teachers);
    });
  }
}