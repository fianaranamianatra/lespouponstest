import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs,
  updateDoc,
  serverTimestamp,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../firebase';
import type { FinancialSetting } from '../firebase/collections';

const COLLECTION_NAME = 'financialSettings';
const SETTINGS_DOC_ID = 'main'; // Document unique pour les paramètres

export class FinancialSettingsService {
  // Créer ou mettre à jour les paramètres financiers
  static async createOrUpdate(settingsData: Omit<FinancialSetting, 'id' | 'createdAt' | 'updatedAt'>): Promise<void> {
    // Validation basique
    if (!settingsData.cnaps || !settingsData.ostie) {
      throw new Error('Les paramètres CNAPS et OSTIE sont requis');
    }

    // Validation des taux (doivent être entre 0 et 100%)
    if (settingsData.cnaps.employeeRate < 0 || settingsData.cnaps.employeeRate > 100) {
      throw new Error('Le taux salarié CNAPS doit être entre 0 et 100%');
    }
    if (settingsData.cnaps.employerRate < 0 || settingsData.cnaps.employerRate > 100) {
      throw new Error('Le taux employeur CNAPS doit être entre 0 et 100%');
    }
    if (settingsData.ostie.employeeRate < 0 || settingsData.ostie.employeeRate > 100) {
      throw new Error('Le taux salarié OSTIE doit être entre 0 et 100%');
    }
    if (settingsData.ostie.employerRate < 0 || settingsData.ostie.employerRate > 100) {
      throw new Error('Le taux employeur OSTIE doit être entre 0 et 100%');
    }

    // Validation des plafonds (doivent être positifs)
    if (settingsData.cnaps.ceiling < 0) {
      throw new Error('Le plafond CNAPS doit être positif');
    }
    if (settingsData.ostie.ceiling < 0) {
      throw new Error('Le plafond OSTIE doit être positif');
    }

    try {
      const docRef = doc(db, COLLECTION_NAME, SETTINGS_DOC_ID);
      
      // Vérifier si le document existe déjà
      const existingDoc = await getDoc(docRef);
      
      const docData = {
        ...settingsData,
        effectiveDate: settingsData.effectiveDate || new Date().toISOString().split('T')[0],
        updatedAt: serverTimestamp()
      };

      if (existingDoc.exists()) {
        // Mettre à jour le document existant
        await updateDoc(docRef, docData);
      } else {
        // Créer un nouveau document avec createdAt
        await setDoc(docRef, {
          ...docData,
          createdAt: serverTimestamp()
        });
      }
    } catch (error) {
      console.error('Erreur lors de la sauvegarde des paramètres financiers:', error);
      throw new Error('Impossible de sauvegarder les paramètres financiers');
    }
  }

  // Récupérer les paramètres financiers
  static async get(): Promise<FinancialSetting | null> {
    try {
      const docRef = doc(db, COLLECTION_NAME, SETTINGS_DOC_ID);
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as FinancialSetting;
      }
      
      // Retourner des paramètres par défaut si aucun document n'existe
      return this.getDefaultSettings();
    } catch (error) {
      console.error('Erreur lors de la récupération des paramètres financiers:', error);
      throw new Error('Impossible de récupérer les paramètres financiers');
    }
  }

  // Paramètres par défaut pour Madagascar (2024)
  static getDefaultSettings(): FinancialSetting {
    return {
      cnaps: {
        employeeRate: 1.0, // 1% part salariale
        employerRate: 13.0, // 13% part patronale
        ceiling: 8000000, // 8 millions d'Ariary (plafond approximatif)
        isActive: true
      },
      ostie: {
        employeeRate: 1.0, // 1% part salariale
        employerRate: 5.0, // 5% part patronale
        ceiling: 5000000, // 5 millions d'Ariary (plafond approximatif)
        isActive: true
      },
      lastUpdatedBy: 'Système',
      effectiveDate: new Date().toISOString().split('T')[0],
      notes: 'Paramètres par défaut pour Madagascar - À ajuster selon la réglementation en vigueur',
      createdAt: new Date(),
      updatedAt: new Date()
    };
  }

  // Écouter les changements en temps réel
  static onSnapshot(callback: (settings: FinancialSetting | null) => void) {
    const docRef = doc(db, COLLECTION_NAME, SETTINGS_DOC_ID);
    
    return onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        const settings = {
          id: docSnap.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as FinancialSetting;
        callback(settings);
      } else {
        // Retourner les paramètres par défaut si le document n'existe pas
        callback(this.getDefaultSettings());
      }
    });
  }

  // Calculer les cotisations pour un salaire donné
  static calculateContributions(salary: number, settings: FinancialSetting): {
    cnaps: { employee: number; employer: number; total: number };
    ostie: { employee: number; employer: number; total: number };
    totalEmployee: number;
    totalEmployer: number;
    netSalary: number;
  } {
    // Appliquer les plafonds
    const cnapsBase = Math.min(salary, settings.cnaps.ceiling);
    const ostieBase = Math.min(salary, settings.ostie.ceiling);

    // Calculer les cotisations CNAPS
    const cnapsEmployee = settings.cnaps.isActive ? (cnapsBase * settings.cnaps.employeeRate) / 100 : 0;
    const cnapsEmployer = settings.cnaps.isActive ? (cnapsBase * settings.cnaps.employerRate) / 100 : 0;

    // Calculer les cotisations OSTIE
    const ostieEmployee = settings.ostie.isActive ? (ostieBase * settings.ostie.employeeRate) / 100 : 0;
    const ostieEmployer = settings.ostie.isActive ? (ostieBase * settings.ostie.employerRate) / 100 : 0;

    // Totaux
    const totalEmployee = cnapsEmployee + ostieEmployee;
    const totalEmployer = cnapsEmployer + ostieEmployer;
    const netSalary = salary - totalEmployee;

    return {
      cnaps: {
        employee: cnapsEmployee,
        employer: cnapsEmployer,
        total: cnapsEmployee + cnapsEmployer
      },
      ostie: {
        employee: ostieEmployee,
        employer: ostieEmployer,
        total: ostieEmployee + ostieEmployer
      },
      totalEmployee,
      totalEmployer,
      netSalary
    };
  }

  // Valider les paramètres
  static validateSettings(settings: Partial<FinancialSetting>): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (settings.cnaps) {
      if (settings.cnaps.employeeRate < 0 || settings.cnaps.employeeRate > 100) {
        errors.push('Le taux salarié CNAPS doit être entre 0 et 100%');
      }
      if (settings.cnaps.employerRate < 0 || settings.cnaps.employerRate > 100) {
        errors.push('Le taux employeur CNAPS doit être entre 0 et 100%');
      }
      if (settings.cnaps.ceiling < 0) {
        errors.push('Le plafond CNAPS doit être positif');
      }
    }

    if (settings.ostie) {
      if (settings.ostie.employeeRate < 0 || settings.ostie.employeeRate > 100) {
        errors.push('Le taux salarié OSTIE doit être entre 0 et 100%');
      }
      if (settings.ostie.employerRate < 0 || settings.ostie.employerRate > 100) {
        errors.push('Le taux employeur OSTIE doit être entre 0 et 100%');
      }
      if (settings.ostie.ceiling < 0) {
        errors.push('Le plafond OSTIE doit être positif');
      }
    }

    if (settings.effectiveDate) {
      const effectiveDate = new Date(settings.effectiveDate);
      const today = new Date();
      if (effectiveDate > today) {
        // Avertissement mais pas d'erreur pour les dates futures
        console.warn('Date d\'entrée en vigueur dans le futur');
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  // Obtenir l'historique des modifications (si nécessaire pour l'audit)
  static async getHistory(): Promise<FinancialSetting[]> {
    try {
      // Pour l'instant, on retourne juste les paramètres actuels
      // Dans une version future, on pourrait créer une collection d'historique
      const current = await this.get();
      return current ? [current] : [];
    } catch (error) {
      console.error('Erreur lors de la récupération de l\'historique:', error);
      return [];
    }
  }
}