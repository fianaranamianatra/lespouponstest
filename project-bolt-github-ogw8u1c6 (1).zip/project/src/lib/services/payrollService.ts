// Service de calcul de paie avec OSTIE et CNAPS
import { FinancialSettingsService } from './financialSettingsService';
import type { FinancialSetting } from '../firebase/collections';

export interface PayrollCalculation {
  // Salaire de base
  grossSalary: number;
  
  // Cotisations CNAPS
  cnaps: {
    employeeContribution: number;
    employerContribution: number;
    total: number;
    rate: {
      employee: number;
      employer: number;
    };
    ceiling: number;
    isActive: boolean;
  };
  
  // Cotisations OSTIE
  ostie: {
    employeeContribution: number;
    employerContribution: number;
    total: number;
    rate: {
      employee: number;
      employer: number;
    };
    ceiling: number;
    isActive: boolean;
  };
  
  // Totaux
  totalEmployeeContributions: number;
  totalEmployerContributions: number;
  totalContributions: number;
  
  // Salaire net
  netSalary: number;
  
  // Coût total pour l'employeur
  totalEmployerCost: number;
  
  // Métadonnées
  calculatedAt: Date;
  settingsVersion: string;
}

export interface PayrollSummary {
  employeeId: string;
  employeeName: string;
  position: string;
  department: string;
  calculation: PayrollCalculation;
  paymentDate?: string;
  status: 'draft' | 'validated' | 'paid';
  reference?: string;
}

export class PayrollService {
  // Calculer la paie d'un employé
  static async calculatePayroll(
    employeeId: string,
    grossSalary: number,
    paymentDate?: string
  ): Promise<PayrollCalculation> {
    try {
      // Récupérer les paramètres financiers actuels
      const settings = await FinancialSettingsService.get();
      if (!settings) {
        throw new Error('Paramètres financiers non configurés');
      }

      // Utiliser la méthode de calcul du service des paramètres
      const contributions = FinancialSettingsService.calculateContributions(grossSalary, settings);

      // Construire le résultat détaillé
      const calculation: PayrollCalculation = {
        grossSalary,
        
        cnaps: {
          employeeContribution: contributions.cnaps.employee,
          employerContribution: contributions.cnaps.employer,
          total: contributions.cnaps.total,
          rate: {
            employee: settings.cnaps.employeeRate,
            employer: settings.cnaps.employerRate
          },
          ceiling: settings.cnaps.ceiling,
          isActive: settings.cnaps.isActive
        },
        
        ostie: {
          employeeContribution: contributions.ostie.employee,
          employerContribution: contributions.ostie.employer,
          total: contributions.ostie.total,
          rate: {
            employee: settings.ostie.employeeRate,
            employer: settings.ostie.employerRate
          },
          ceiling: settings.ostie.ceiling,
          isActive: settings.ostie.isActive
        },
        
        totalEmployeeContributions: contributions.totalEmployee,
        totalEmployerContributions: contributions.totalEmployer,
        totalContributions: contributions.totalEmployee + contributions.totalEmployer,
        
        netSalary: contributions.netSalary,
        totalEmployerCost: grossSalary + contributions.totalEmployer,
        
        calculatedAt: new Date(),
        settingsVersion: settings.effectiveDate
      };

      return calculation;
    } catch (error) {
      console.error('Erreur lors du calcul de la paie:', error);
      throw new Error('Impossible de calculer la paie');
    }
  }

  // Calculer la paie pour plusieurs employés
  static async calculateBulkPayroll(
    employees: Array<{ id: string; name: string; position: string; department: string; salary: number }>,
    paymentDate?: string
  ): Promise<PayrollSummary[]> {
    try {
      const results: PayrollSummary[] = [];
      
      for (const employee of employees) {
        // Permettre à l'interface utilisateur de rester réactive
        await new Promise(resolve => setTimeout(resolve, 10));
        
        const calculation = await this.calculatePayroll(employee.id, employee.salary, paymentDate);
        
        results.push({
          employeeId: employee.id,
          employeeName: employee.name,
          position: employee.position,
          department: employee.department,
          calculation,
          paymentDate,
          status: 'draft',
          reference: this.generatePayrollReference(employee.id, paymentDate)
        });
      }
      
      return results;
    } catch (error) {
      console.error('Erreur lors du calcul de paie en lot:', error);
      throw new Error('Impossible de calculer la paie en lot');
    }
  }

  // Générer une référence de paie unique
  static generatePayrollReference(employeeId: string, paymentDate?: string): string {
    const date = paymentDate ? new Date(paymentDate) : new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const employeeRef = employeeId.substring(0, 6).toUpperCase();
    
    return `PAY-${year}${month}-${employeeRef}`;
  }

  // Calculer le coût total des salaires pour l'école
  static async calculateTotalPayrollCost(
    employees: Array<{ salary: number }>
  ): Promise<{
    totalGrossSalaries: number;
    totalEmployeeContributions: number;
    totalEmployerContributions: number;
    totalNetSalaries: number;
    totalEmployerCost: number;
  }> {
    try {
      const settings = await FinancialSettingsService.get();
      if (!settings) {
        throw new Error('Paramètres financiers non configurés');
      }

      let totalGrossSalaries = 0;
      let totalEmployeeContributions = 0;
      let totalEmployerContributions = 0;
      let totalNetSalaries = 0;

      for (const employee of employees) {
        const contributions = FinancialSettingsService.calculateContributions(employee.salary, settings);
        
        totalGrossSalaries += employee.salary;
        totalEmployeeContributions += contributions.totalEmployee;
        totalEmployerContributions += contributions.totalEmployer;
        totalNetSalaries += contributions.netSalary;
      }

      return {
        totalGrossSalaries,
        totalEmployeeContributions,
        totalEmployerContributions,
        totalNetSalaries,
        totalEmployerCost: totalGrossSalaries + totalEmployerContributions
      };
    } catch (error) {
      console.error('Erreur lors du calcul du coût total des salaires:', error);
      throw new Error('Impossible de calculer le coût total des salaires');
    }
  }

  // Valider les calculs de paie
  static validatePayrollCalculation(calculation: PayrollCalculation): {
    isValid: boolean;
    errors: string[];
    warnings: string[];
  } {
    const errors: string[] = [];
    const warnings: string[] = [];

    // Vérifications de base
    if (calculation.grossSalary <= 0) {
      errors.push('Le salaire brut doit être supérieur à 0');
    }

    if (calculation.netSalary < 0) {
      errors.push('Le salaire net ne peut pas être négatif');
    }

    if (calculation.totalEmployeeContributions > calculation.grossSalary) {
      errors.push('Les cotisations salariales ne peuvent pas dépasser le salaire brut');
    }

    // Avertissements
    if (calculation.grossSalary > 10000000) { // 10 millions d'Ariary
      warnings.push('Salaire élevé - Vérifiez les plafonds de cotisation');
    }

    if (!calculation.cnaps.isActive && !calculation.ostie.isActive) {
      warnings.push('Aucune cotisation sociale activée');
    }

    // Vérifier la cohérence des calculs
    const expectedNetSalary = calculation.grossSalary - calculation.totalEmployeeContributions;
    if (Math.abs(calculation.netSalary - expectedNetSalary) > 0.01) {
      errors.push('Incohérence dans le calcul du salaire net');
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }

  // Formater un bulletin de paie
  static formatPayslip(summary: PayrollSummary): string {
    const calc = summary.calculation;
    
    return `
═══════════════════════════════════════════════════════════════
                        BULLETIN DE PAIE
                         École LES POUPONS
═══════════════════════════════════════════════════════════════

INFORMATIONS EMPLOYÉ
────────────────────────────────────────────────────────────────
Nom et Prénom    : ${summary.employeeName}
Poste            : ${summary.position}
Département      : ${summary.department}
Période de paie  : ${summary.paymentDate || new Date().toLocaleDateString('fr-FR')}
Référence        : ${summary.reference || 'Non définie'}
Date d'édition   : ${new Date().toLocaleDateString('fr-FR')}

DÉTAIL DU SALAIRE
────────────────────────────────────────────────────────────────
Salaire brut                                ${calc.grossSalary.toLocaleString().padStart(15)} Ar

COTISATIONS SALARIALES (retenues sur salaire)
────────────────────────────────────────────────────────────────
${calc.cnaps.isActive ? 
  `CNAPS - Part salariale (${calc.cnaps.rate.employee.toFixed(1)}%)     ${('-' + calc.cnaps.employeeContribution.toLocaleString()).padStart(15)} Ar` : 
  'CNAPS - Part salariale                    DÉSACTIVÉ'
}
${calc.ostie.isActive ? 
  `OSTIE - Part salariale (${calc.ostie.rate.employee.toFixed(1)}%)     ${('-' + calc.ostie.employeeContribution.toLocaleString()).padStart(15)} Ar` : 
  'OSTIE - Part salariale                    DÉSACTIVÉ'
}
                                           ─────────────────
Total cotisations salariales               ${('-' + calc.totalEmployeeContributions.toLocaleString()).padStart(15)} Ar

SALAIRE NET À PAYER                        ${calc.netSalary.toLocaleString().padStart(15)} Ar

CHARGES PATRONALES (à la charge de l'employeur)
────────────────────────────────────────────────────────────────
${calc.cnaps.isActive ? 
  `CNAPS - Part patronale (${calc.cnaps.rate.employer.toFixed(1)}%)    ${('+' + calc.cnaps.employerContribution.toLocaleString()).padStart(15)} Ar` : 
  'CNAPS - Part patronale                    DÉSACTIVÉ'
}
${calc.ostie.isActive ? 
  `OSTIE - Part patronale (${calc.ostie.rate.employer.toFixed(1)}%)     ${('+' + calc.ostie.employerContribution.toLocaleString()).padStart(15)} Ar` : 
  'OSTIE - Part patronale                    DÉSACTIVÉ'
}
                                           ─────────────────
Total charges patronales                   ${('+' + calc.totalEmployerContributions.toLocaleString()).padStart(15)} Ar

COÛT TOTAL POUR L'EMPLOYEUR                ${calc.totalEmployerCost.toLocaleString().padStart(15)} Ar

═══════════════════════════════════════════════════════════════
INFORMATIONS LÉGALES
───────────────────────────────────────────────────────────────
• CNAPS : Caisse Nationale de Prévoyance Sociale
• OSTIE : Organisme Sanitaire Tananarivien Inter-Entreprises
• Les cotisations sont calculées selon la réglementation en vigueur
• Ce bulletin fait foi pour tous usages légaux

Calculé le : ${calc.calculatedAt.toLocaleDateString('fr-FR')} à ${calc.calculatedAt.toLocaleTimeString('fr-FR')}
Paramètres version : ${calc.settingsVersion}

École LES POUPONS - Antananarivo, Madagascar
═══════════════════════════════════════════════════════════════
    `.trim();
  }
}