import {
  ref,
  uploadBytes,
  uploadBytesResumable,
  getDownloadURL,
  deleteObject,
  listAll,
  getMetadata
} from "firebase/storage";
import { storage } from "./firebase";

export interface UploadProgress {
  progress: number;
  bytesTransferred: number;
  totalBytes: number;
}

export interface FileMetadata {
  name: string;
  size: number;
  contentType: string;
  timeCreated: string;
  updated: string;
  downloadURL: string;
}

// Upload d'un fichier avec progress
export const uploadFile = (
  file: File,
  path: string,
  onProgress?: (progress: UploadProgress) => void
): Promise<string> => {
  return new Promise((resolve, reject) => {
    const storageRef = ref(storage, path);
    const uploadTask = uploadBytesResumable(storageRef, file);

    uploadTask.on(
      'state_changed',
      (snapshot) => {
        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        if (onProgress) {
          onProgress({
            progress,
            bytesTransferred: snapshot.bytesTransferred,
            totalBytes: snapshot.totalBytes
          });
        }
      },
      (error) => {
        console.error('Erreur lors de l\'upload:', error);
        reject(error);
      },
      async () => {
        try {
          const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
          resolve(downloadURL);
        } catch (error) {
          reject(error);
        }
      }
    );
  });
};

// Upload simple d'un fichier
export const uploadFileSimple = async (file: File, path: string): Promise<string> => {
  try {
    const storageRef = ref(storage, path);
    const snapshot = await uploadBytes(storageRef, file);
    const downloadURL = await getDownloadURL(snapshot.ref);
    return downloadURL;
  } catch (error) {
    console.error('Erreur lors de l\'upload simple:', error);
    throw error;
  }
};

// Upload d'avatar d'utilisateur
export const uploadUserAvatar = async (
  file: File,
  userId: string,
  onProgress?: (progress: UploadProgress) => void
): Promise<string> => {
  const path = `avatars/${userId}/${Date.now()}_${file.name}`;
  return uploadFile(file, path, onProgress);
};

// Upload de documents d'élèves
export const uploadStudentDocument = async (
  file: File,
  studentId: string,
  documentType: string,
  onProgress?: (progress: UploadProgress) => void
): Promise<string> => {
  const path = `students/${studentId}/documents/${documentType}/${Date.now()}_${file.name}`;
  return uploadFile(file, path, onProgress);
};

// Upload de rapports
export const uploadReport = async (
  file: File,
  reportType: string,
  onProgress?: (progress: UploadProgress) => void
): Promise<string> => {
  const path = `reports/${reportType}/${Date.now()}_${file.name}`;
  return uploadFile(file, path, onProgress);
};

// Supprimer un fichier
export const deleteFile = async (path: string): Promise<void> => {
  try {
    const storageRef = ref(storage, path);
    await deleteObject(storageRef);
  } catch (error) {
    console.error('Erreur lors de la suppression:', error);
    throw error;
  }
};

// Supprimer un fichier par URL
export const deleteFileByURL = async (url: string): Promise<void> => {
  try {
    const storageRef = ref(storage, url);
    await deleteObject(storageRef);
  } catch (error) {
    console.error('Erreur lors de la suppression par URL:', error);
    throw error;
  }
};

// Lister les fichiers dans un dossier
export const listFiles = async (path: string): Promise<FileMetadata[]> => {
  try {
    const storageRef = ref(storage, path);
    const result = await listAll(storageRef);
    
    const files: FileMetadata[] = [];
    
    for (const itemRef of result.items) {
      const metadata = await getMetadata(itemRef);
      const downloadURL = await getDownloadURL(itemRef);
      
      files.push({
        name: metadata.name,
        size: metadata.size,
        contentType: metadata.contentType || '',
        timeCreated: metadata.timeCreated,
        updated: metadata.updated,
        downloadURL
      });
    }
    
    return files;
  } catch (error) {
    console.error('Erreur lors de la liste des fichiers:', error);
    throw error;
  }
};

// Obtenir les métadonnées d'un fichier
export const getFileMetadata = async (path: string): Promise<FileMetadata | null> => {
  try {
    const storageRef = ref(storage, path);
    const metadata = await getMetadata(storageRef);
    const downloadURL = await getDownloadURL(storageRef);
    
    return {
      name: metadata.name,
      size: metadata.size,
      contentType: metadata.contentType || '',
      timeCreated: metadata.timeCreated,
      updated: metadata.updated,
      downloadURL
    };
  } catch (error) {
    console.error('Erreur lors de la récupération des métadonnées:', error);
    return null;
  }
};

// Utilitaires pour la validation des fichiers
export const validateFile = (file: File, maxSize: number = 5 * 1024 * 1024, allowedTypes: string[] = []): boolean => {
  // Vérifier la taille
  if (file.size > maxSize) {
    throw new Error(`Le fichier est trop volumineux. Taille maximale: ${maxSize / 1024 / 1024}MB`);
  }
  
  // Vérifier le type si spécifié
  if (allowedTypes.length > 0 && !allowedTypes.includes(file.type)) {
    throw new Error(`Type de fichier non autorisé. Types acceptés: ${allowedTypes.join(', ')}`);
  }
  
  return true;
};

// Types de fichiers autorisés
export const FILE_TYPES = {
  IMAGES: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
  DOCUMENTS: ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
  SPREADSHEETS: ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
  ALL_DOCUMENTS: ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']
};