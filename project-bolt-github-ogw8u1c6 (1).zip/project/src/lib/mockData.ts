// Données de démonstration pour le mode hors ligne
export const mockDashboardStats = {
  totalStudents: 39,
  totalTeachers: 25,
  totalClasses: 20,
  activeStudents: 39,
  totalRevenue: 19500000,
  pendingPayments: 2500000,
  averageGrade: 14.2,
  attendanceRate: 95.2
};

export const mockMonthlyData = [
  { month: 'Jan', students: 35, revenue: 17500000, grades: 120 },
  { month: 'Fév', students: 36, revenue: 18000000, grades: 125 },
  { month: 'Mar', students: 37, revenue: 18500000, grades: 130 },
  { month: 'Avr', students: 38, revenue: 19000000, grades: 135 },
  { month: 'Mai', students: 39, revenue: 19500000, grades: 140 },
  { month: 'Jun', students: 39, revenue: 19500000, grades: 138 },
  { month: 'Jul', students: 39, revenue: 19500000, grades: 142 },
  { month: 'Aoû', students: 39, revenue: 19500000, grades: 145 },
  { month: 'Sep', students: 39, revenue: 19500000, grades: 140 },
  { month: 'Oct', students: 39, revenue: 19500000, grades: 143 },
  { month: 'Nov', students: 39, revenue: 19500000, grades: 138 }
];

export const mockTopStudents = [
  { id: '1', name: 'Djannel ANDRIASOLOMALALA', average: 18.5 },
  { id: '2', name: 'Fitahiana Alma ANDRIANARISON', average: 17.8 },
  { id: '3', name: 'Venot Brivael RANANDRIARIJAONA', average: 17.2 },
  { id: '4', name: 'Ange Chloé RAKOTOHARISON', average: 16.9 },
  { id: '5', name: 'Eunice TIVERNE', average: 16.5 }
];