import { collection, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { db } from './firebase';
import { mockDashboardStats, mockMonthlyData, mockTopStudents } from './mockData';

export interface DashboardStats {
  totalStudents: number;
  totalTeachers: number;
  totalClasses: number;
  activeStudents: number;
  totalRevenue: number;
  pendingPayments: number;
  averageGrade: number;
  attendanceRate: number;
}

export interface MonthlyData {
  month: string;
  students: number;
  revenue: number;
  grades: number;
}

// Calculer les statistiques du tableau de bord
export const getDashboardStats = async (): Promise<DashboardStats> => {
  try {
    // Compter les élèves
    const studentsSnapshot = await getDocs(collection(db, 'students'));
    const totalStudents = studentsSnapshot.size;
    const activeStudents = studentsSnapshot.docs.filter(doc => 
      doc.data().status === 'active'
    ).length;

    // Compter les enseignants
    const teachersSnapshot = await getDocs(collection(db, 'teachers'));
    const totalTeachers = teachersSnapshot.size;

    // Compter les classes
    const classesSnapshot = await getDocs(collection(db, 'classes'));
    const totalClasses = classesSnapshot.size;

    // Calculer les revenus
    const paymentsSnapshot = await getDocs(
      query(collection(db, 'payments'), where('status', '==', 'paid'))
    );
    const totalRevenue = paymentsSnapshot.docs.reduce((sum, doc) => 
      sum + (doc.data().amount || 0), 0
    );

    // Paiements en attente
    const pendingPaymentsSnapshot = await getDocs(
      query(collection(db, 'payments'), where('status', '==', 'pending'))
    );
    const pendingPayments = pendingPaymentsSnapshot.docs.reduce((sum, doc) => 
      sum + (doc.data().amount || 0), 0
    );

    // Moyenne des notes
    const gradesSnapshot = await getDocs(collection(db, 'grades'));
    const grades = gradesSnapshot.docs.map(doc => doc.data());
    const averageGrade = grades.length > 0 
      ? grades.reduce((sum, grade) => sum + (grade.grade / grade.maxGrade * 20), 0) / grades.length
      : 0;

    return {
      totalStudents,
      totalTeachers,
      totalClasses,
      activeStudents,
      totalRevenue,
      pendingPayments,
      averageGrade,
      attendanceRate: 95.2 // Placeholder - à implémenter avec un système d'assiduité
    };
  } catch (error) {
    console.error('Erreur lors du calcul des statistiques:', error);
    // Retourner les données de démonstration en cas d'erreur
    return mockDashboardStats;
  }
};

// Obtenir les données mensuelles pour les graphiques
export const getMonthlyData = async (year: number = new Date().getFullYear()): Promise<MonthlyData[]> => {
  try {
    const months = [
      'Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun',
      'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'
    ];

    const monthlyData: MonthlyData[] = [];

    for (let month = 0; month < 12; month++) {
      const startDate = new Date(year, month, 1);
      const endDate = new Date(year, month + 1, 0);

      // Élèves inscrits ce mois
      const studentsQuery = query(
        collection(db, 'students'),
        where('createdAt', '>=', startDate),
        where('createdAt', '<=', endDate)
      );
      const studentsSnapshot = await getDocs(studentsQuery);

      // Revenus du mois
      const paymentsQuery = query(
        collection(db, 'payments'),
        where('paymentDate', '>=', startDate),
        where('paymentDate', '<=', endDate),
        where('status', '==', 'paid')
      );
      const paymentsSnapshot = await getDocs(paymentsQuery);
      const monthRevenue = paymentsSnapshot.docs.reduce((sum, doc) => 
        sum + (doc.data().amount || 0), 0
      );

      // Notes du mois
      const gradesQuery = query(
        collection(db, 'grades'),
        where('date', '>=', startDate),
        where('date', '<=', endDate)
      );
      const gradesSnapshot = await getDocs(gradesQuery);

      monthlyData.push({
        month: months[month],
        students: studentsSnapshot.size,
        revenue: monthRevenue,
        grades: gradesSnapshot.size
      });
    }

    return monthlyData;
  } catch (error) {
    console.error('Erreur lors de la récupération des données mensuelles:', error);
    // Retourner les données de démonstration en cas d'erreur
    return mockMonthlyData;
  }
};

// Obtenir les top performers
export const getTopStudents = async (limit: number = 10) => {
  try {
    const gradesSnapshot = await getDocs(collection(db, 'grades'));
    const studentGrades: { [key: string]: { total: number; count: number; name: string } } = {};

    gradesSnapshot.docs.forEach(doc => {
      const grade = doc.data();
      const studentId = grade.studentId;
      const percentage = (grade.grade / grade.maxGrade) * 100;

      if (!studentGrades[studentId]) {
        studentGrades[studentId] = {
          total: 0,
          count: 0,
          name: grade.studentName
        };
      }

      studentGrades[studentId].total += percentage;
      studentGrades[studentId].count += 1;
    });

    const topStudents = Object.entries(studentGrades)
      .map(([id, data]) => ({
        id,
        name: data.name,
        average: data.total / data.count
      }))
      .sort((a, b) => b.average - a.average)
      .slice(0, limit);

    return topStudents;
  } catch (error) {
    console.error('Erreur lors de la récupération des meilleurs élèves:', error);
    // Retourner les données de démonstration en cas d'erreur
    return mockTopStudents.slice(0, limit);
  }
};