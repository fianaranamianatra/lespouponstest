// Données d'exemple pour peupler Firebase
export const exampleStudents = [
  {
    firstName: "Marie",
    lastName: "DUBOIS",
    dateOfBirth: "2015-03-15",
    class: "CP",
    address: "123 Rue de la Paix, Antananarivo",
    phone: "+261 34 12 345 67",
    parentName: "Jean DUBOIS",
    parentEmail: "jean.dubois@email.mg",
    status: "active"
  },
  {
    firstName: "Pierre",
    lastName: "MARTIN",
    dateOfBirth: "2014-07-22",
    class: "CE1",
    address: "456 Avenue de l'Indépendance, Antananarivo",
    phone: "+261 34 23 456 78",
    parentName: "Sophie MARTIN",
    parentEmail: "sophie.martin@email.mg",
    status: "active"
  },
  {
    firstName: "Julie",
    lastName: "BERNARD",
    dateOfBirth: "2013-11-08",
    class: "CE2",
    address: "789 Boulevard Ratsimilaho, Antananarivo",
    phone: "+261 34 34 567 89",
    parentName: "Michel BERNARD",
    parentEmail: "michel.bernard@email.mg",
    status: "active"
  },
  {
    firstName: "Thomas",
    lastName: "LEROY",
    dateOfBirth: "2012-05-14",
    class: "CM1",
    address: "321 Rue Rainandriamampandry, Antananarivo",
    phone: "+261 34 45 678 90",
    parentName: "Anne LEROY",
    parentEmail: "anne.leroy@email.mg",
    status: "active"
  },
  {
    firstName: "Emma",
    lastName: "ROUSSEAU",
    dateOfBirth: "2011-09-30",
    class: "CM2",
    address: "654 Avenue du 26 Juin, Antananarivo",
    phone: "+261 34 56 789 01",
    parentName: "Paul ROUSSEAU",
    parentEmail: "paul.rousseau@email.mg",
    status: "active"
  },
  {
    firstName: "Lucas",
    lastName: "MOREAU",
    dateOfBirth: "2015-01-12",
    class: "CP",
    address: "987 Rue Andrianampoinimerina, Antananarivo",
    phone: "+261 34 67 890 12",
    parentName: "Claire MOREAU",
    parentEmail: "claire.moreau@email.mg",
    status: "active"
  },
  {
    firstName: "Léa",
    lastName: "SIMON",
    dateOfBirth: "2014-04-18",
    class: "CE1",
    address: "147 Boulevard de l'Europe, Antananarivo",
    phone: "+261 34 78 901 23",
    parentName: "David SIMON",
    parentEmail: "david.simon@email.mg",
    status: "active"
  },
  {
    firstName: "Hugo",
    lastName: "LAURENT",
    dateOfBirth: "2013-08-25",
    class: "CE2",
    address: "258 Rue de la République, Antananarivo",
    phone: "+261 34 89 012 34",
    parentName: "Isabelle LAURENT",
    parentEmail: "isabelle.laurent@email.mg",
    status: "active"
  }
];

export const exampleTeachers = [
  {
    firstName: "Catherine",
    lastName: "MOREAU",
    dateOfBirth: "1985-03-15",
    email: "catherine.moreau@lespoupons.mg",
    phone: "+261 34 11 111 11",
    subject: "Mathématiques",
    classes: ["CP", "CE1"],
    experience: 8,
    status: "CDI",
    entryDate: "2020-09-01"
  },
  {
    firstName: "Jean-Pierre",
    lastName: "DURAND",
    dateOfBirth: "1978-07-22",
    email: "jeanpierre.durand@lespoupons.mg",
    phone: "+261 34 22 222 22",
    subject: "Français",
    classes: ["CE2", "CM1"],
    experience: 12,
    status: "CDI",
    entryDate: "2018-09-01"
  },
  {
    firstName: "Marie",
    lastName: "LAMBERT",
    dateOfBirth: "1990-11-08",
    email: "marie.lambert@lespoupons.mg",
    phone: "+261 34 33 333 33",
    subject: "Anglais",
    classes: ["CM1", "CM2"],
    experience: 6,
    status: "CDD",
    entryDate: "2021-09-01"
  },
  {
    firstName: "Patrick",
    lastName: "ROUSSEAU",
    dateOfBirth: "1975-05-14",
    email: "patrick.rousseau@lespoupons.mg",
    phone: "+261 34 44 444 44",
    subject: "Sciences",
    classes: ["CE1", "CE2", "CM1"],
    experience: 10,
    status: "FRAM",
    entryDate: "2019-09-01",
    retirementDate: "2029-09-01"
  },
  {
    firstName: "Sophie",
    lastName: "MARTIN",
    dateOfBirth: "1988-12-03",
    email: "sophie.martin@lespoupons.mg",
    phone: "+261 34 55 555 55",
    subject: "Histoire-Géographie",
    classes: ["CM2"],
    experience: 5,
    status: "CDD",
    entryDate: "2022-09-01"
  }
];

export const exampleClasses = [
  {
    name: "CP",
    level: "Cours Préparatoire",
    teacher: "Catherine MOREAU",
    studentCount: 0,
    maxCapacity: 25,
    room: "Salle 101",
    status: "active"
  },
  {
    name: "CE1",
    level: "Cours Élémentaire 1",
    teacher: "Catherine MOREAU",
    studentCount: 0,
    maxCapacity: 25,
    room: "Salle 102",
    status: "active"
  },
  {
    name: "CE2",
    level: "Cours Élémentaire 2",
    teacher: "Jean-Pierre DURAND",
    studentCount: 0,
    maxCapacity: 28,
    room: "Salle 103",
    status: "active"
  },
  {
    name: "CM1",
    level: "Cours Moyen 1",
    teacher: "Jean-Pierre DURAND",
    studentCount: 0,
    maxCapacity: 30,
    room: "Salle 104",
    status: "active"
  },
  {
    name: "CM2",
    level: "Cours Moyen 2",
    teacher: "Sophie MARTIN",
    studentCount: 0,
    maxCapacity: 30,
    room: "Salle 105",
    status: "active"
  }
];

export const exampleSubjects = [
  {
    name: "Mathématiques",
    code: "MATH",
    description: "Mathématiques générales et appliquées",
    hoursPerWeek: 5,
    teachers: ["Catherine MOREAU"],
    classes: ["CP", "CE1", "CE2", "CM1", "CM2"],
    color: "blue",
    status: "active"
  },
  {
    name: "Français",
    code: "FR",
    description: "Langue française et littérature",
    hoursPerWeek: 6,
    teachers: ["Jean-Pierre DURAND"],
    classes: ["CP", "CE1", "CE2", "CM1", "CM2"],
    color: "green",
    status: "active"
  },
  {
    name: "Anglais",
    code: "ANG",
    description: "Langue anglaise",
    hoursPerWeek: 2,
    teachers: ["Marie LAMBERT"],
    classes: ["CM1", "CM2"],
    color: "purple",
    status: "active"
  },
  {
    name: "Sciences",
    code: "SCI",
    description: "Sciences physiques et naturelles",
    hoursPerWeek: 3,
    teachers: ["Patrick ROUSSEAU"],
    classes: ["CE1", "CE2", "CM1", "CM2"],
    color: "orange",
    status: "active"
  },
  {
    name: "Histoire-Géographie",
    code: "HG",
    description: "Histoire et géographie",
    hoursPerWeek: 3,
    teachers: ["Sophie MARTIN"],
    classes: ["CE2", "CM1", "CM2"],
    color: "red",
    status: "active"
  }
];

export const exampleGrades = [
  {
    studentId: "student1",
    studentName: "Marie DUBOIS",
    subject: "Mathématiques",
    class: "CP",
    assignment: "Contrôle Addition",
    grade: 16,
    maxGrade: 20,
    date: "2024-11-15",
    teacher: "Catherine MOREAU",
    type: "exam"
  },
  {
    studentId: "student2",
    studentName: "Pierre MARTIN",
    subject: "Français",
    class: "CE1",
    assignment: "Dictée",
    grade: 14,
    maxGrade: 20,
    date: "2024-11-14",
    teacher: "Jean-Pierre DURAND",
    type: "homework"
  },
  {
    studentId: "student3",
    studentName: "Julie BERNARD",
    subject: "Sciences",
    class: "CE2",
    assignment: "Quiz Nature",
    grade: 18,
    maxGrade: 20,
    date: "2024-11-13",
    teacher: "Patrick ROUSSEAU",
    type: "quiz"
  }
];

export const exampleFees = [
  {
    studentId: "student1",
    studentName: "Marie DUBOIS",
    class: "CP",
    amount: 500000,
    paymentMethod: "bank_transfer",
    paymentDate: "2024-11-01",
    period: "Trimestre 1",
    status: "paid",
    reference: "PAY-2024-001",
    notes: "Paiement complet"
  },
  {
    studentId: "student2",
    studentName: "Pierre MARTIN",
    class: "CE1",
    amount: 500000,
    paymentMethod: "cash",
    paymentDate: "2024-11-05",
    period: "Trimestre 1",
    status: "paid",
    reference: "PAY-2024-002"
  },
  {
    studentId: "student3",
    studentName: "Julie BERNARD",
    class: "CE2",
    amount: 250000,
    paymentMethod: "mobile_money",
    paymentDate: "2024-11-10",
    period: "Trimestre 1",
    status: "pending",
    reference: "PAY-2024-003",
    notes: "Paiement partiel"
  }
];

export const exampleSchedules = [
  {
    class: "CP",
    subject: "Mathématiques",
    teacher: "Catherine MOREAU",
    day: "Lundi",
    startTime: "08:00",
    endTime: "09:00",
    room: "Salle 101",
    type: "course"
  },
  {
    class: "CP",
    subject: "Français",
    teacher: "Catherine MOREAU",
    day: "Lundi",
    startTime: "09:00",
    endTime: "10:00",
    room: "Salle 101",
    type: "course"
  },
  {
    class: "CE1",
    subject: "Sciences",
    teacher: "Patrick ROUSSEAU",
    day: "Mardi",
    startTime: "10:00",
    endTime: "11:00",
    room: "Laboratoire",
    type: "tp"
  }
];

export const exampleFinances = [
  {
    type: "income",
    category: "Écolage",
    amount: 2500000,
    description: "Paiements écolage novembre",
    date: "2024-11-01",
    reference: "INC-2024-001"
  },
  {
    type: "expense",
    category: "Salaires",
    amount: 1500000,
    description: "Salaires enseignants novembre",
    date: "2024-11-01",
    reference: "EXP-2024-001"
  },
  {
    type: "expense",
    category: "Fournitures",
    amount: 200000,
    description: "Achat fournitures scolaires",
    date: "2024-11-05",
    reference: "EXP-2024-002"
  }
];

export const exampleHierarchy = [
  {
    firstName: "Jean-Claude",
    lastName: "RAMAROSON",
    position: "Directeur",
    department: "Direction",
    level: 1,
    email: "directeur@lespoupons.mg",
    phone: "+261 34 10 000 00",
    salary: 2500000,
    hireDate: "2020-01-01",
    status: "active"
  },
  {
    firstName: "Marie-Claire",
    lastName: "ANDRIANTSOA",
    position: "Sous-Directrice",
    department: "Direction",
    parentId: "hierarchy1",
    level: 2,
    email: "sousdirectrice@lespoupons.mg",
    phone: "+261 34 10 000 01",
    salary: 2000000,
    hireDate: "2020-02-01",
    status: "active"
  },
  {
    firstName: "Hery",
    lastName: "RAKOTONIRINA",
    position: "Comptable",
    department: "Administration",
    parentId: "hierarchy1",
    level: 2,
    email: "comptable@lespoupons.mg",
    phone: "+261 34 10 000 02",
    salary: 1200000,
    hireDate: "2020-03-01",
    status: "active"
  }
];

export const exampleCommunications = [
  {
    sender: "Sophie Martin",
    recipient: "Catherine Moreau",
    subject: "Question sur les devoirs",
    content: "Bonjour, j'aimerais savoir si Marie peut avoir un délai pour son devoir de mathématiques...",
    type: "parent",
    status: "sent",
    priority: "medium",
    date: "2024-11-20"
  },
  {
    sender: "Administration",
    recipient: "Tous les parents",
    subject: "Réunion parents-professeurs",
    content: "La réunion parents-professeurs aura lieu le 25 novembre...",
    type: "admin",
    status: "sent",
    priority: "high",
    date: "2024-11-18"
  }
];

export const exampleReports = [
  {
    title: "Bulletin Trimestriel - CP",
    description: "Rapport des notes du premier trimestre",
    type: "academic",
    generated: "2024-11-20",
    size: "2.3 MB",
    format: "PDF",
    createdBy: "Catherine MOREAU"
  },
  {
    title: "Rapport Financier - Novembre",
    description: "État financier du mois de novembre",
    type: "financial",
    generated: "2024-11-19",
    size: "1.8 MB",
    format: "Excel",
    createdBy: "Hery RAKOTONIRINA"
  }
];

export const exampleUsers = [
  {
    uid: "admin123",
    email: "admin@lespoupons.mg",
    firstName: "Admin",
    lastName: "LES POUPONS",
    role: "admin",
    isActive: true
  },
  {
    uid: "director123",
    email: "directeur@lespoupons.mg",
    firstName: "Jean-Claude",
    lastName: "RAMAROSON",
    role: "director",
    isActive: true
  },
  {
    uid: "teacher123",
    email: "enseignant@lespoupons.mg",
    firstName: "Catherine",
    lastName: "MOREAU",
    role: "teacher",
    isActive: true
  },
  {
    uid: "secretary123",
    email: "secretaire@lespoupons.mg",
    firstName: "Nadia",
    lastName: "RAZAFY",
    role: "secretary",
    isActive: true
  },
  {
    uid: "parent123",
    email: "parent@lespoupons.mg",
    firstName: "Sophie",
    lastName: "MARTIN",
    role: "parent",
    isActive: true
  }
];

export const exampleAdvancedFinances = [
  // Salaires
  {
    type: 'salary',
    category: 'Salaire Enseignant',
    employeeName: 'Catherine MOREAU',
    amount: 1200000,
    frequency: 'monthly',
    dueDate: '2024-11-30',
    status: 'paid',
    description: 'Salaire mensuel - Novembre 2024',
    reference: 'SAL-2024-001'
  },
  {
    type: 'salary',
    category: 'Salaire Administration',
    employeeName: 'Hery RAKOTONIRINA',
    amount: 1000000,
    frequency: 'monthly',
    dueDate: '2024-11-30',
    status: 'paid',
    description: 'Salaire comptable - Novembre 2024',
    reference: 'SAL-2024-002'
  },
  {
    type: 'salary',
    category: 'Salaire Direction',
    employeeName: 'Jean-Claude RAMAROSON',
    amount: 2500000,
    frequency: 'monthly',
    dueDate: '2024-11-30',
    status: 'paid',
    description: 'Salaire directeur - Novembre 2024',
    reference: 'SAL-2024-003'
  },
  {
    type: 'salary',
    category: 'Salaire Enseignant',
    employeeName: 'Marie-Claire ANDRIANTSOA',
    amount: 2000000,
    frequency: 'monthly',
    dueDate: '2024-11-30',
    status: 'paid',
    description: 'Salaire directrice pédagogique - Novembre 2024',
    reference: 'SAL-2024-004'
  },
  {
    type: 'salary',
    category: 'Salaire Administration',
    employeeName: 'Nadia RAZAFY',
    amount: 800000,
    frequency: 'monthly',
    dueDate: '2024-11-30',
    status: 'paid',
    description: 'Salaire secrétaire générale - Novembre 2024',
    reference: 'SAL-2024-005'
  },
  {
    type: 'salary',
    category: 'Salaire Enseignant',
    employeeName: 'Volatiana RASOLOFO',
    amount: 900000,
    frequency: 'monthly',
    dueDate: '2024-11-30',
    status: 'paid',
    description: 'Salaire institutrice TPSA - Novembre 2024',
    reference: 'SAL-2024-006'
  },
  {
    type: 'salary',
    category: 'Salaire Service',
    employeeName: 'Koto RAZAFY',
    amount: 500000,
    frequency: 'monthly',
    dueDate: '2024-11-30',
    status: 'paid',
    description: 'Salaire gardien principal - Novembre 2024',
    reference: 'SAL-2024-007'
  },
  {
    type: 'salary',
    category: 'Salaire Service',
    employeeName: 'Voahangy RAKOTONIRINA',
    amount: 450000,
    frequency: 'monthly',
    dueDate: '2024-11-30',
    status: 'paid',
    description: 'Salaire femme de ménage principal - Novembre 2024',
    reference: 'SAL-2024-008'
  },
  // Cotisations CNAPS calculées automatiquement
  {
    type: 'payroll',
    category: 'Cotisations CNAPS',
    employeeName: 'Catherine MOREAU',
    amount: 168000, // 1,200,000 * 14% (1% salarié + 13% employeur)
    frequency: 'monthly',
    dueDate: '2024-12-15',
    status: 'pending',
    description: 'Cotisations CNAPS - Catherine MOREAU - Novembre 2024',
    reference: 'CNAPS-2024-001'
  },
  {
    type: 'payroll',
    category: 'Cotisations OSTIE',
    employeeName: 'Catherine MOREAU',
    amount: 72000, // 1,200,000 * 6% (1% salarié + 5% employeur)
    frequency: 'monthly',
    dueDate: '2024-12-15',
    status: 'pending',
    description: 'Cotisations OSTIE - Catherine MOREAU - Novembre 2024',
    reference: 'OSTIE-2024-001'
  },
  {
    type: 'payroll',
    category: 'Cotisations CNAPS',
    employeeName: 'Jean-Claude RAMAROSON',
    amount: 350000, // 2,500,000 * 14%
    frequency: 'monthly',
    dueDate: '2024-12-15',
    status: 'pending',
    description: 'Cotisations CNAPS - Jean-Claude RAMAROSON - Novembre 2024',
    reference: 'CNAPS-2024-002'
  },
  {
    type: 'payroll',
    category: 'Cotisations OSTIE',
    employeeName: 'Jean-Claude RAMAROSON',
    amount: 150000, // 2,500,000 * 6%
    frequency: 'monthly',
    dueDate: '2024-12-15',
    status: 'pending',
    description: 'Cotisations OSTIE - Jean-Claude RAMAROSON - Novembre 2024',
    reference: 'OSTIE-2024-002'
  },
  // Électricité
  {
    type: 'electricity',
    category: 'Facture mensuelle',
    amount: 180000,
    frequency: 'monthly',
    dueDate: '2024-12-05',
    status: 'pending',
    description: 'Facture électricité JIRAMA - Novembre 2024',
    reference: 'ELEC-2024-001'
  },
  {
    type: 'electricity',
    category: 'Maintenance électrique',
    amount: 75000,
    frequency: 'one_time',
    dueDate: '2024-11-25',
    status: 'paid',
    description: 'Réparation éclairage salle de classe',
    reference: 'ELEC-2024-002'
  },
  // Frais d'inscription
  {
    type: 'registration_fee',
    category: 'Frais d\'inscription Maternelle',
    studentName: 'Marie DUBOIS',
    amount: 150000,
    frequency: 'yearly',
    dueDate: '2024-09-15',
    status: 'paid',
    description: 'Frais d\'inscription année 2024-2025',
    reference: 'INS-2024-001'
  },
  // Activités parascolaires
  {
    type: 'extracurricular',
    category: 'Club de Sport',
    studentName: 'Pierre MARTIN',
    amount: 50000,
    frequency: 'monthly',
    dueDate: '2024-11-30',
    status: 'pending',
    description: 'Club de football - Novembre 2024',
    reference: 'SPORT-2024-001'
  },
  // Cantine
  {
    type: 'canteen',
    category: 'Repas Mensuel',
    studentName: 'Julie BERNARD',
    amount: 80000,
    frequency: 'monthly',
    dueDate: '2024-11-30',
    status: 'paid',
    description: 'Repas cantine - Novembre 2024',
    reference: 'CANT-2024-001'
  },
  // Transport
  {
    type: 'transport',
    category: 'Transport scolaire',
    studentName: 'Thomas LEROY',
    amount: 60000,
    frequency: 'monthly',
    dueDate: '2024-11-30',
    status: 'paid',
    description: 'Transport scolaire - Novembre 2024',
    reference: 'TRANS-2024-001'
  },
  // Autres dépenses
  {
    type: 'other',
    category: 'Fournitures',
    amount: 120000,
    frequency: 'monthly',
    dueDate: '2024-11-20',
    status: 'paid',
    description: 'Fournitures scolaires - Novembre 2024',
    reference: 'FOUR-2024-001'
  }
];