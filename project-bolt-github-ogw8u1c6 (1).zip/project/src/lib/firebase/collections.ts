// Types pour toutes les collections Firebase
export interface Student {
  id?: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  class: string;
  address: string;
  phone: string;
  parentName: string;
  parentEmail?: string;
  status: 'active' | 'inactive';
  createdAt?: Date;
  updatedAt?: Date;
}

export interface Teacher {
  id?: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  email: string;
  phone: string;
  subject: string;
  classes: string[];
  experience: number;
  status: 'CDI' | 'CDD' | 'FRAM';
  entryDate?: string;
  retirementDate?: string;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface Class {
  id?: string;
  name: string;
  level: string;
  teacher: string;
  studentCount: number;
  maxCapacity: number;
  room: string;
  status: 'active' | 'inactive';
  createdAt?: Date;
  updatedAt?: Date;
}

export interface Subject {
  id?: string;
  name: string;
  code: string;
  description: string;
  hoursPerWeek: number;
  teachers: string[];
  classes: string[];
  color: string;
  status: 'active' | 'inactive';
  createdAt?: Date;
  updatedAt?: Date;
}

export interface Grade {
  id?: string;
  studentId: string;
  studentName: string;
  subject: string;
  class: string;
  assignment: string;
  grade: number;
  maxGrade: number;
  date: string;
  teacher: string;
  type: 'exam' | 'homework' | 'quiz' | 'project';
  createdAt?: Date;
  updatedAt?: Date;
}

export interface Fee {
  id?: string;
  studentId: string;
  studentName: string;
  class: string;
  amount: number;
  paymentMethod: string;
  paymentDate: string;
  period: string;
  status: 'paid' | 'pending' | 'overdue';
  reference: string;
  notes?: string;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface Schedule {
  id?: string;
  class: string;
  subject: string;
  teacher: string;
  day: string;
  startTime: string;
  endTime: string;
  room: string;
  type: 'course' | 'exam' | 'tp' | 'sport' | 'break';
  createdAt?: Date;
  updatedAt?: Date;
}

export interface Finance {
  id?: string;
  type: 'income' | 'expense';
  category: string;
  amount: number;
  description: string;
  date: string;
  reference?: string;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface HierarchyEmployee {
  id?: string;
  firstName: string;
  lastName: string;
  position: string;
  department: string;
  parentId?: string;
  level: number;
  email: string;
  phone: string;
  salary: number;
  hireDate: string;
  status: 'active' | 'inactive';
  createdAt?: Date;
  updatedAt?: Date;
}

export interface Communication {
  id?: string;
  sender: string;
  recipient: string;
  subject: string;
  content: string;
  type: 'parent' | 'teacher' | 'admin';
  status: 'sent' | 'read' | 'replied';
  priority: 'low' | 'medium' | 'high';
  date: string;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface Report {
  id?: string;
  title: string;
  description: string;
  type: 'academic' | 'attendance' | 'financial' | 'behavioral';
  generated: string;
  size: string;
  format: 'PDF' | 'Excel' | 'Word';
  createdBy: string;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface FirebaseUserType {
  id?: string;
  uid: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  permissions?: string[];
  isActive: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface FinancialSetting {
  id?: string;
  // Paramètres CNAPS (Caisse Nationale de Prévoyance Sociale)
  cnaps: {
    employeeRate: number; // Taux part salariale (ex: 1%)
    employerRate: number; // Taux part patronale (ex: 13%)
    ceiling: number; // Plafond de cotisation en Ariary
    isActive: boolean; // Activation/désactivation
  };
  // Paramètres OSTIE (Organisme Sanitaire Tananarivien Inter-Entreprises)
  ostie: {
    employeeRate: number; // Taux part salariale (ex: 1%)
    employerRate: number; // Taux part patronale (ex: 5%)
    ceiling: number; // Plafond de cotisation en Ariary
    isActive: boolean; // Activation/désactivation
  };
  // Métadonnées
  lastUpdatedBy: string; // Nom de l'utilisateur qui a fait la dernière modification
  effectiveDate: string; // Date d'entrée en vigueur des paramètres
  notes?: string; // Notes ou commentaires sur les paramètres
  createdAt?: Date;
  updatedAt?: Date;
}