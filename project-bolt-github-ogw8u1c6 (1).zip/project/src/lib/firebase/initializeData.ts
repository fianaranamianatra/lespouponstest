import {
  studentsService,
  teachersService,
  advancedFinancesService,
  classesService,
  subjectsService,
  gradesService,
  feesService,
  schedulesService,
  financesService,
  hierarchyService,
  communicationsService,
  reportsService,
  usersService
} from './firebaseService';

import {
  exampleStudents,
  exampleTeachers,
  exampleClasses,
  exampleSubjects,
  exampleGrades,
  exampleFees,
  exampleSchedules,
  exampleFinances,
  exampleHierarchy,
  exampleCommunications,
  exampleReports,
  exampleUsers,
  exampleAdvancedFinances
} from './exampleData';

export const initializeExampleData = async (): Promise<void> => {
  try {
    console.log('🚀 Initialisation des données d\'exemple...');

    // Vérifier si des données existent déjà
    const existingStudents = await studentsService.getAll();
    if (existingStudents.length > 0) {
      console.log('⚠️ Des données existent déjà. Initialisation annulée.');
      return;
    }

    // Initialiser les données dans l'ordre des dépendances
    console.log('📚 Création des classes...');
    await classesService.createBatch(exampleClasses);

    console.log('👨‍🏫 Création des enseignants...');
    await teachersService.createBatch(exampleTeachers);

    console.log('📖 Création des matières...');
    await subjectsService.createBatch(exampleSubjects);

    console.log('👨‍🎓 Création des élèves...');
    await studentsService.createBatch(exampleStudents);

    console.log('📝 Création des notes...');
    await gradesService.createBatch(exampleGrades);

    console.log('💰 Création des données d\'écolage...');
    await feesService.createBatch(exampleFees);

    console.log('📅 Création de l\'emploi du temps...');
    await schedulesService.createBatch(exampleSchedules);

    console.log('💼 Création des données financières...');
    await financesService.createBatch(exampleFinances);

    console.log('🏢 Création du plan hiérarchique...');
    await hierarchyService.createBatch(exampleHierarchy);

    console.log('💬 Création des communications...');
    await communicationsService.createBatch(exampleCommunications);

    console.log('📊 Création des rapports...');
    await reportsService.createBatch(exampleReports);
    
    console.log('👥 Création des utilisateurs...');
    await usersService.createBatch(exampleUsers);

    console.log('💰 Création des données financières avancées...');
    await advancedFinancesService.createBatch(exampleAdvancedFinances);

    console.log('⚙️ Initialisation des paramètres financiers par défaut...');
    const { FinancialSettingsService } = await import('./firebaseService');
    const defaultSettings = FinancialSettingsService.getDefaultSettings();
    const settingsData = {
      cnaps: defaultSettings.cnaps,
      ostie: defaultSettings.ostie,
      lastUpdatedBy: 'Système d\'initialisation',
      effectiveDate: new Date().toISOString().split('T')[0],
      notes: 'Paramètres par défaut initialisés automatiquement pour Madagascar'
    };
    await FinancialSettingsService.createOrUpdate(settingsData);

    console.log('✅ Initialisation des données d\'exemple terminée avec succès !');
    
    // Afficher un message de succès à l'utilisateur
    alert('✅ Données d\'exemple initialisées avec succès !\n\n' +
          '📊 Vous pouvez maintenant tester toutes les fonctionnalités :\n' +
          '• 8 élèves dans différentes classes\n' +
          '• 5 enseignants avec leurs matières\n' +
          '• 5 classes (CP à CM2)\n' +
          '• 5 matières principales\n' +
          '• Notes et évaluations\n' +
          '• Données d\'écolage et paiements\n' +
          '• Emploi du temps\n' +
          '• Plan hiérarchique\n' +
          '• Communications\n' +
          '• Rapports\n\n' +
          '• Gestion financière avancée avec OSTIE et CNAPS\n' +
          '• Calculs de paie automatiques\n' +
          '• Paramètres financiers configurés\n' +
          '• Utilisateurs avec différents rôles\n\n' +
          'Toutes les données sont maintenant synchronisées avec Firebase !');

  } catch (error) {
    console.error('❌ Erreur lors de l\'initialisation des données:', error);
    alert('❌ Erreur lors de l\'initialisation des données d\'exemple.\n\n' +
          'Vérifiez votre connexion Firebase et réessayez.');
    throw error;
  }
};

export const clearAllData = async (): Promise<void> => {
  try {
    console.log('🗑️ Suppression de toutes les données...');

    const collections = [
      'students', 'teachers', 'classes', 'subjects', 'grades',
      'fees', 'schedules', 'finances', 'hierarchy', 'communications', 'reports', 'users', 'advanced_finances'
    ];

    for (const collectionName of collections) {
      const service = new (require('./firebaseService').FirebaseService)(collectionName);
      const items = await service.getAll();
      
      for (const item of items) {
        if (item.id) {
          await service.delete(item.id);
        }
      }
      console.log(`✅ Collection ${collectionName} vidée`);
    }

    console.log('✅ Toutes les données ont été supprimées');
    alert('✅ Toutes les données ont été supprimées avec succès !');

  } catch (error) {
    console.error('❌ Erreur lors de la suppression des données:', error);
    alert('❌ Erreur lors de la suppression des données.');
    throw error;
  }
};