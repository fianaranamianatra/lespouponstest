import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  getDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  serverTimestamp,
  writeBatch,
  Timestamp
} from 'firebase/firestore';
import { db } from '../firebase';
import type { FirebaseUserType } from './collections';

export class FirebaseService<T> {
  constructor(private collectionName: string) {}

  // Créer un document
  async create(data: Omit<T, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    try {
      const docData = {
        ...data,
        classes: data.classes || [], // Assurer que classes est toujours un tableau
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      console.log('🔥 Données envoyées à Firebase:', docData);
      const docRef = await addDoc(collection(db, this.collectionName), docData);
      console.log('✅ Document créé avec l\'ID:', docRef.id);
      return docRef.id;
    } catch (error) {
      console.error(`❌ Erreur Firebase lors de la création dans ${this.collectionName}:`, error);
      throw new Error(`Impossible de créer l'élément dans ${this.collectionName}`);
    }
  }

  // Lire un document par ID
  async getById(id: string): Promise<T | null> {
    try {
      const docRef = doc(db, this.collectionName, id);
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as T;
      }
      
      return null;
    } catch (error) {
      console.error(`Erreur lors de la lecture de ${this.collectionName}:`, error);
      throw new Error(`Impossible de récupérer l'élément de ${this.collectionName}`);
    }
  }

  // Lire tous les documents
  async getAll(): Promise<T[]> {
    try {
      const querySnapshot = await getDocs(collection(db, this.collectionName));
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as T;
      });
    } catch (error) {
      console.error(`Erreur lors de la lecture de ${this.collectionName}:`, error);
      throw new Error(`Impossible de récupérer les données de ${this.collectionName}`);
    }
  }

  // Lire avec requête
  async getWhere(field: string, operator: any, value: any): Promise<T[]> {
    try {
      const q = query(collection(db, this.collectionName), where(field, operator, value));
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as T;
      });
    } catch (error) {
      console.error(`Erreur lors de la requête ${this.collectionName}:`, error);
      throw new Error(`Impossible d'exécuter la requête sur ${this.collectionName}`);
    }
  }

  // Mettre à jour un document
  async update(id: string, data: Partial<T>): Promise<void> {
    try {
      const docRef = doc(db, this.collectionName, id);
      await updateDoc(docRef, {
        ...data,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error(`Erreur lors de la mise à jour de ${this.collectionName}:`, error);
      throw new Error(`Impossible de mettre à jour l'élément de ${this.collectionName}`);
    }
  }

  // Supprimer un document
  async delete(id: string): Promise<void> {
    try {
      const docRef = doc(db, this.collectionName, id);
      await deleteDoc(docRef);
    } catch (error) {
      console.error(`Erreur lors de la suppression de ${this.collectionName}:`, error);
      throw new Error(`Impossible de supprimer l'élément de ${this.collectionName}`);
    }
  }

  // Écouter les changements en temps réel
  onSnapshot(callback: (data: T[]) => void, errorCallback?: (error: Error) => void) {
    return onSnapshot(
      collection(db, this.collectionName),
      (snapshot) => {
        const data = snapshot.docs.map(doc => {
          const docData = doc.data();
          return {
            id: doc.id,
            ...docData,
            createdAt: docData.createdAt?.toDate(),
            updatedAt: docData.updatedAt?.toDate()
          } as T;
        });
        callback(data);
      },
      (error) => {
        console.error(`Erreur de synchronisation ${this.collectionName}:`, error);
        if (errorCallback) {
          errorCallback(new Error(`Erreur de synchronisation des données ${this.collectionName}`));
        }
      }
    );
  }

  // Créer plusieurs documents en lot
  async createBatch(items: Omit<T, 'id' | 'createdAt' | 'updatedAt'>[]): Promise<void> {
    try {
      const batch = writeBatch(db);
      
      items.forEach(item => {
        const docRef = doc(collection(db, this.collectionName));
        batch.set(docRef, {
          ...item,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
      });
      
      await batch.commit();
    } catch (error) {
      console.error(`Erreur lors de la création en lot dans ${this.collectionName}:`, error);
      throw new Error(`Impossible de créer les éléments en lot dans ${this.collectionName}`);
    }
  }
}

// Services pour chaque collection
export const studentsService = new FirebaseService<any>('students');
export const teachersService = new FirebaseService<any>('teachers');
export const classesService = new FirebaseService<any>('classes');
export const subjectsService = new FirebaseService<any>('subjects');
export const gradesService = new FirebaseService<any>('grades');
export const feesService = new FirebaseService<any>('fees');
export const schedulesService = new FirebaseService<any>('schedules');
export const financesService = new FirebaseService<any>('finances');
export const hierarchyService = new FirebaseService<any>('hierarchy');
export const communicationsService = new FirebaseService<any>('communications');
export const reportsService = new FirebaseService<any>('reports');
export const bulletinsService = new FirebaseService<any>('bulletins');
export const usersService = new FirebaseService<FirebaseUserType>('users');
export const advancedFinancesService = new FirebaseService<any>('advanced_finances');

// Service spécialisé pour les paramètres financiers
export { FinancialSettingsService } from '../services/financialSettingsService';