import { doc, setDoc, collection, getDocs, query, where, orderBy } from 'firebase/firestore';
import { db } from './firebase';

export interface CertificateRecord {
  id?: string;
  studentId: string;
  studentName: string;
  certificateNumber: string;
  schoolYear: string;
  issueDate: Date;
  issuedBy: string;
  createdAt: Date;
}

// Enregistrer un certificat émis
export const saveCertificateRecord = async (certificateData: Omit<CertificateRecord, 'id' | 'createdAt'>) => {
  try {
    const docRef = doc(collection(db, 'certificates'));
    await setDoc(docRef, {
      ...certificateData,
      createdAt: new Date()
    });
    return docRef.id;
  } catch (error) {
    console.error('Erreur lors de l\'enregistrement du certificat:', error);
    throw error;
  }
};

// Récupérer l'historique des certificats d'un élève
export const getStudentCertificates = async (studentId: string): Promise<CertificateRecord[]> => {
  try {
    const q = query(
      collection(db, 'certificates'),
      where('studentId', '==', studentId),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      issueDate: doc.data().issueDate?.toDate(),
      createdAt: doc.data().createdAt?.toDate()
    } as CertificateRecord));
  } catch (error) {
    console.error('Erreur lors de la récupération des certificats:', error);
    return [];
  }
};

// Récupérer tous les certificats émis
export const getAllCertificates = async (): Promise<CertificateRecord[]> => {
  try {
    const q = query(
      collection(db, 'certificates'),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      issueDate: doc.data().issueDate?.toDate(),
      createdAt: doc.data().createdAt?.toDate()
    } as CertificateRecord));
  } catch (error) {
    console.error('Erreur lors de la récupération de tous les certificats:', error);
    return [];
  }
};

// Générer un numéro de certificat unique
export const generateCertificateNumber = (): string => {
  const year = new Date().getFullYear();
  const timestamp = Date.now().toString().slice(-6);
  return `CERT-${year}-${timestamp}`;
};

// Valider un numéro de certificat
export const validateCertificateNumber = async (certificateNumber: string): Promise<boolean> => {
  try {
    const q = query(
      collection(db, 'certificates'),
      where('certificateNumber', '==', certificateNumber)
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.empty; // Retourne true si le numéro n'existe pas (donc valide)
  } catch (error) {
    console.error('Erreur lors de la validation du numéro de certificat:', error);
    return false;
  }
};