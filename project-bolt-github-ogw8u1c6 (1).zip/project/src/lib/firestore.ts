import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  onSnapshot,
  writeBatch,
  serverTimestamp,
  Timestamp
} from "firebase/firestore";
import { db } from "./firebase";

// Types pour les collections
export interface Student {
  id?: string;
  firstName: string;
  lastName: string;
  dateOfBirth: Date;
  class: string;
  address: string;
  phone: string;
  parentName: string;
  parentEmail?: string;
  status: 'active' | 'inactive';
  createdAt: Date;
  updatedAt: Date;
}

export interface Teacher {
  id?: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  subject: string;
  classes: string[];
  experience: number;
  status: 'active' | 'inactive';
  createdAt: Date;
  updatedAt: Date;
}

export interface Class {
  id?: string;
  name: string;
  level: string;
  teacher: string;
  studentCount: number;
  maxCapacity: number;
  room: string;
  status: 'active' | 'inactive';
  createdAt: Date;
  updatedAt: Date;
}

export interface Grade {
  id?: string;
  studentId: string;
  studentName: string;
  subject: string;
  class: string;
  assignment: string;
  grade: number;
  maxGrade: number;
  date: Date;
  teacher: string;
  type: 'exam' | 'homework' | 'quiz' | 'project';
  createdAt: Date;
  updatedAt: Date;
}

export interface Payment {
  id?: string;
  studentId: string;
  studentName: string;
  class: string;
  amount: number;
  paymentMethod: string;
  paymentDate: Date;
  period: string;
  status: 'paid' | 'pending' | 'overdue';
  reference: string;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

// Fonctions génériques pour CRUD
export class FirestoreService<T> {
  constructor(private collectionName: string) {}

  // Créer un document
  async create(data: Omit<T, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    try {
      const docData = {
        ...data,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      const docRef = await addDoc(collection(db, this.collectionName), docData);
      return docRef.id;
    } catch (error) {
      console.error(`Erreur lors de la création dans ${this.collectionName}:`, error);
      throw error;
    }
  }

  // Lire un document par ID
  async getById(id: string): Promise<T | null> {
    try {
      const docRef = doc(db, this.collectionName, id);
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as T;
      }
      
      return null;
    } catch (error) {
      console.error(`Erreur lors de la lecture de ${this.collectionName}:`, error);
      throw error;
    }
  }

  // Lire tous les documents
  async getAll(): Promise<T[]> {
    try {
      const querySnapshot = await getDocs(collection(db, this.collectionName));
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as T;
      });
    } catch (error) {
      console.error(`Erreur lors de la lecture de ${this.collectionName}:`, error);
      throw error;
    }
  }

  // Lire avec requête
  async getWhere(field: string, operator: any, value: any): Promise<T[]> {
    try {
      const q = query(collection(db, this.collectionName), where(field, operator, value));
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate()
        } as T;
      });
    } catch (error) {
      console.error(`Erreur lors de la requête ${this.collectionName}:`, error);
      throw error;
    }
  }

  // Mettre à jour un document
  async update(id: string, data: Partial<T>): Promise<void> {
    try {
      const docRef = doc(db, this.collectionName, id);
      await updateDoc(docRef, {
        ...data,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error(`Erreur lors de la mise à jour de ${this.collectionName}:`, error);
      throw error;
    }
  }

  // Supprimer un document
  async delete(id: string): Promise<void> {
    try {
      const docRef = doc(db, this.collectionName, id);
      await deleteDoc(docRef);
    } catch (error) {
      console.error(`Erreur lors de la suppression de ${this.collectionName}:`, error);
      throw error;
    }
  }

  // Écouter les changements en temps réel
  onSnapshot(callback: (data: T[]) => void) {
    return onSnapshot(collection(db, this.collectionName), (snapshot) => {
      const data = snapshot.docs.map(doc => {
        const docData = doc.data();
        return {
          id: doc.id,
          ...docData,
          createdAt: docData.createdAt?.toDate(),
          updatedAt: docData.updatedAt?.toDate()
        } as T;
      });
      callback(data);
    });
  }
}

// Services spécialisés
export const studentsService = new FirestoreService<Student>('students');
export const teachersService = new FirestoreService<Teacher>('teachers');
export const classesService = new FirestoreService<Class>('classes');
export const gradesService = new FirestoreService<Grade>('grades');
export const paymentsService = new FirestoreService<Payment>('payments');

// Fonctions spécialisées pour les statistiques
export const getStudentsByClass = async (className: string): Promise<Student[]> => {
  return studentsService.getWhere('class', '==', className);
};

export const getGradesByStudent = async (studentId: string): Promise<Grade[]> => {
  return gradesService.getWhere('studentId', '==', studentId);
};

export const getPaymentsByStudent = async (studentId: string): Promise<Payment[]> => {
  return paymentsService.getWhere('studentId', '==', studentId);
};

export const getTeachersBySubject = async (subject: string): Promise<Teacher[]> => {
  return teachersService.getWhere('subject', '==', subject);
};

// Fonction pour les opérations batch
export const batchOperations = {
  async createMultiple<T>(collectionName: string, items: T[]): Promise<void> {
    const batch = writeBatch(db);
    
    items.forEach(item => {
      const docRef = doc(collection(db, collectionName));
      batch.set(docRef, {
        ...item,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    });
    
    await batch.commit();
  },

  async updateMultiple(updates: { collection: string; id: string; data: any }[]): Promise<void> {
    const batch = writeBatch(db);
    
    updates.forEach(update => {
      const docRef = doc(db, update.collection, update.id);
      batch.update(docRef, {
        ...update.data,
        updatedAt: serverTimestamp()
      });
    });
    
    await batch.commit();
  }
};