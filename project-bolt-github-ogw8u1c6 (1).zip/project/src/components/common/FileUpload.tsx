import React, { useState, useRef } from 'react';
import { Upload, X, File, Image } from 'lucide-react';
import { uploadFile, validateFile, FILE_TYPES, UploadProgress } from '../../lib/storage';

interface FileUploadProps {
  onUploadComplete: (url: string) => void;
  onError: (error: string) => void;
  path: string;
  acceptedTypes?: string[];
  maxSize?: number;
  multiple?: boolean;
  className?: string;
}

export function FileUpload({
  onUploadComplete,
  onError,
  path,
  acceptedTypes = FILE_TYPES.ALL_DOCUMENTS,
  maxSize = 5 * 1024 * 1024, // 5MB
  multiple = false,
  className = ''
}: FileUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (files: FileList | null) => {
    if (!files || files.length === 0) return;

    const file = files[0]; // Pour l'instant, on ne gère qu'un fichier

    try {
      validateFile(file, maxSize, acceptedTypes);
      setUploading(true);
      setProgress(0);

      const filePath = `${path}/${Date.now()}_${file.name}`;
      
      const url = await uploadFile(file, filePath, (progressData: UploadProgress) => {
        setProgress(progressData.progress);
      });

      onUploadComplete(url);
    } catch (error: any) {
      onError(error.message);
    } finally {
      setUploading(false);
      setProgress(0);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    handleFileSelect(e.dataTransfer.files);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  };

  const isImageType = (type: string) => FILE_TYPES.IMAGES.includes(type);

  return (
    <div className={`relative ${className}`}>
      <input
        ref={fileInputRef}
        type="file"
        multiple={multiple}
        accept={acceptedTypes.join(',')}
        onChange={(e) => handleFileSelect(e.target.files)}
        className="hidden"
      />

      <div
        onClick={() => fileInputRef.current?.click()}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={`
          border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors
          ${dragOver ? 'border-blue-400 bg-blue-50' : 'border-gray-300 hover:border-gray-400'}
          ${uploading ? 'pointer-events-none opacity-50' : ''}
        `}
      >
        {uploading ? (
          <div className="space-y-3">
            <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-sm text-gray-600">Upload en cours... {Math.round(progress)}%</p>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <Upload className="w-12 h-12 text-gray-400 mx-auto" />
            <div>
              <p className="text-sm font-medium text-gray-900">
                Cliquez pour sélectionner ou glissez-déposez
              </p>
              <p className="text-xs text-gray-500 mt-1">
                Taille max: {Math.round(maxSize / 1024 / 1024)}MB
              </p>
              <p className="text-xs text-gray-500">
                Types acceptés: {acceptedTypes.map(type => type.split('/')[1]).join(', ')}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}