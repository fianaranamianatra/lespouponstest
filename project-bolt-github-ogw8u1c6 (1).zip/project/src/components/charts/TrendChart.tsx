import React from 'react';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface TrendData {
  period: string;
  value: number;
  change?: number;
}

interface TrendChartProps {
  data: TrendData[];
  title: string;
  color?: 'green' | 'red' | 'blue' | 'purple';
  format?: 'currency' | 'percentage' | 'number';
  height?: number;
}

export function TrendChart({ 
  data, 
  title, 
  color = 'blue', 
  format = 'currency',
  height = 200 
}: TrendChartProps) {
  if (!data || data.length === 0) {
    return (
      <div className={`bg-white rounded-xl p-6 border border-gray-100`}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium text-gray-900">{title}</h3>
        </div>
        <div className="flex items-center justify-center h-48">
          <p className="text-gray-500">Aucune donnée disponible</p>
        </div>
      </div>
    );
  }

  const maxValue = Math.max(...data.map(d => d.value));
  const minValue = Math.min(...data.map(d => d.value));
  const range = maxValue - minValue || 1; // Éviter la division par zéro
  
  const colorClasses = {
    green: {
      line: '#10b981',
      fill: 'rgba(16, 185, 129, 0.1)',
      dot: '#10b981',
      bg: 'bg-green-50',
      text: 'text-green-600'
    },
    red: {
      line: '#ef4444',
      fill: 'rgba(239, 68, 68, 0.1)',
      dot: '#ef4444',
      bg: 'bg-red-50',
      text: 'text-red-600'
    },
    blue: {
      line: '#3b82f6',
      fill: 'rgba(59, 130, 246, 0.1)',
      dot: '#3b82f6',
      bg: 'bg-blue-50',
      text: 'text-blue-600'
    },
    purple: {
      line: '#8b5cf6',
      fill: 'rgba(139, 92, 246, 0.1)',
      dot: '#8b5cf6',
      bg: 'bg-purple-50',
      text: 'text-purple-600'
    }
  };

  const formatValue = (value: number) => {
    switch (format) {
      case 'currency':
        return `${value.toLocaleString()} Ar`;
      case 'percentage':
        return `${value.toFixed(1)}%`;
      default:
        return value.toLocaleString();
    }
  };

  const getTrendIcon = (change?: number) => {
    if (change === undefined || change === null) return <Minus className="w-4 h-4" />;
    if (change > 0) return <TrendingUp className="w-4 h-4" />;
    return <TrendingDown className="w-4 h-4" />;
  };

  const getTrendColor = (change?: number) => {
    if (change === undefined || change === null) return 'text-gray-500';
    if (change > 0) return 'text-green-600';
    return 'text-red-600';
  };

  const chartWidth = 400;
  const chartHeight = height - 80;
  const padding = 40;

  const lastItem = data[data.length - 1];

  return (
    <div className={`${colorClasses[color].bg} rounded-xl p-6 border border-gray-100`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-medium text-gray-900">{title}</h3>
        <div className={`flex items-center space-x-1 ${getTrendColor(lastItem?.change)}`}>
          {getTrendIcon(lastItem?.change)}
          <span className="text-sm font-medium">
            {lastItem?.change !== undefined && lastItem?.change !== null ? 
              `${lastItem.change > 0 ? '+' : ''}${lastItem.change.toFixed(1)}%` 
              : 'Stable'
            }
          </span>
        </div>
      </div>

      <div className="mb-4">
        <div className={`text-2xl font-bold ${colorClasses[color].text}`}>
          {formatValue(lastItem?.value || 0)}
        </div>
        <div className="text-sm text-gray-500">
          Période actuelle: {lastItem?.period || 'N/A'}
        </div>
      </div>

      <div className="relative overflow-x-auto">
        <svg width={chartWidth} height={chartHeight + 40} className="min-w-full">
          {/* Grid lines */}
          {[0, 25, 50, 75, 100].map((y) => (
            <line
              key={y}
              x1={padding}
              y1={padding + (y / 100) * chartHeight}
              x2={chartWidth - padding}
              y2={padding + (y / 100) * chartHeight}
              stroke="#e5e7eb"
              strokeWidth="1"
              strokeDasharray="2,2"
            />
          ))}

          {/* Area fill */}
          <defs>
            <linearGradient id={`gradient-${color}`} x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor={colorClasses[color].line} stopOpacity="0.3" />
              <stop offset="100%" stopColor={colorClasses[color].line} stopOpacity="0" />
            </linearGradient>
          </defs>

          {data.length > 1 && (
            <path
              d={`M ${padding} ${padding + chartHeight - ((data[0]?.value - minValue) / range) * chartHeight} ${data.map((item, index) => {
                const x = padding + (index / Math.max(data.length - 1, 1)) * (chartWidth - 2 * padding);
                const y = padding + chartHeight - ((item.value - minValue) / range) * chartHeight;
                return `L ${x} ${y}`;
              }).join(' ')} L ${padding + (chartWidth - 2 * padding)} ${padding + chartHeight} L ${padding} ${padding + chartHeight} Z`}
              fill={`url(#gradient-${color})`}
            />
          )}

          {/* Data line */}
          {data.length > 1 && (
            <polyline
              fill="none"
              stroke={colorClasses[color].line}
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={data.map((item, index) => {
                const x = padding + (index / Math.max(data.length - 1, 1)) * (chartWidth - 2 * padding);
                const y = padding + chartHeight - ((item.value - minValue) / range) * chartHeight;
                return `${x},${y}`;
              }).join(' ')}
            />
          )}

          {/* Data points */}
          {data.map((item, index) => {
            const x = padding + (data.length > 1 ? index / (data.length - 1) : 0.5) * (chartWidth - 2 * padding);
            const y = padding + chartHeight - ((item.value - minValue) / range) * chartHeight;
            
            return (
              <g key={index}>
                <circle
                  cx={x}
                  cy={y}
                  r="4"
                  fill="white"
                  stroke={colorClasses[color].dot}
                  strokeWidth="3"
                />
                <text
                  x={x}
                  y={chartHeight + padding + 20}
                  textAnchor="middle"
                  className="text-xs fill-gray-600"
                >
                  {item.period}
                </text>
                
                {/* Hover tooltip */}
                <g className="opacity-0 hover:opacity-100 transition-opacity">
                  <rect
                    x={x - 30}
                    y={y - 35}
                    width="60"
                    height="25"
                    fill="rgba(0,0,0,0.8)"
                    rx="4"
                  />
                  <text
                    x={x}
                    y={y - 18}
                    textAnchor="middle"
                    className="text-xs fill-white"
                  >
                    {formatValue(item.value)}
                  </text>
                </g>
              </g>
            );
          })}

          {/* Y-axis labels */}
          {[0, 25, 50, 75, 100].map((y) => (
            <text
              key={y}
              x={padding - 10}
              y={padding + (y / 100) * chartHeight + 4}
              textAnchor="end"
              className="text-xs fill-gray-500"
            >
              {formatValue(minValue + ((100 - y) / 100) * range)}
            </text>
          ))}
        </svg>
      </div>
    </div>
  );
}