import React from 'react';
import { TrendingUp, TrendingDown, BarChart3, PieChart } from 'lucide-react';

interface ChartData {
  label: string;
  value: number;
  color: string;
  percentage?: number;
}

interface FinancialChartProps {
  type: 'bar' | 'pie' | 'line' | 'donut';
  data: ChartData[];
  title: string;
  height?: number;
  showLegend?: boolean;
  showValues?: boolean;
}

export function FinancialChart({ 
  type, 
  data, 
  title, 
  height = 300, 
  showLegend = true, 
  showValues = true 
}: FinancialChartProps) {
  const maxValue = Math.max(...data.map(d => d.value));
  const total = data.reduce((acc, d) => acc + d.value, 0);

  const getColorValue = (colorClass: string): string => {
    const colorMap: { [key: string]: string } = {
      'bg-blue-500': '#3b82f6',
      'bg-green-500': '#10b981',
      'bg-red-500': '#ef4444',
      'bg-yellow-500': '#f59e0b',
      'bg-purple-500': '#8b5cf6',
      'bg-orange-500': '#f97316',
      'bg-indigo-500': '#6366f1',
      'bg-pink-500': '#ec4899',
      'bg-teal-500': '#14b8a6',
      'bg-cyan-500': '#06b6d4'
    };
    return colorMap[colorClass] || '#6b7280';
  };

  const renderBarChart = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-medium text-gray-900">{title}</h3>
        <BarChart3 className="w-5 h-5 text-gray-400" />
      </div>
      
      <div className="space-y-3" style={{ height: `${height}px`, overflowY: 'auto' }}>
        {data.map((item, index) => (
          <div key={index} className="flex items-center space-x-3">
            <div className="w-20 text-sm text-gray-600 truncate">{item.label}</div>
            <div className="flex-1 relative">
              <div className="w-full bg-gray-200 rounded-full h-6">
                <div 
                  className={`h-6 rounded-full ${item.color} flex items-center justify-end pr-2 transition-all duration-1000 ease-out`}
                  style={{ width: `${maxValue > 0 ? (item.value / maxValue) * 100 : 0}%` }}
                >
                  {showValues && item.value > 0 && (
                    <span className="text-white text-xs font-medium">
                      {item.value.toLocaleString()} Ar
                    </span>
                  )}
                </div>
              </div>
            </div>
            <div className="w-16 text-sm text-gray-500 text-right">
              {total > 0 ? ((item.value / total) * 100).toFixed(1) : '0.0'}%
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderPieChart = () => {
    if (total === 0) {
      return (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-medium text-gray-900">{title}</h3>
            <PieChart className="w-5 h-5 text-gray-400" />
          </div>
          <div className="flex items-center justify-center h-48">
            <p className="text-gray-500">Aucune donnée disponible</p>
          </div>
        </div>
      );
    }

    let cumulativePercentage = 0;
    const radius = 80;
    const circumference = 2 * Math.PI * radius;
    
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-medium text-gray-900">{title}</h3>
          <PieChart className="w-5 h-5 text-gray-400" />
        </div>
        
        <div className="flex items-center justify-center">
          <div className="relative">
            <svg width="200" height="200" viewBox="0 0 200 200" className="transform -rotate-90">
              <circle
                cx="100"
                cy="100"
                r={radius}
                fill="none"
                stroke="#f3f4f6"
                strokeWidth="20"
              />
              {data.map((item, index) => {
                const percentage = (item.value / total) * 100;
                const strokeDasharray = `${(percentage / 100) * circumference} ${circumference}`;
                const strokeDashoffset = -cumulativePercentage * circumference / 100;
                cumulativePercentage += percentage;
                
                return (
                  <circle
                    key={index}
                    cx="100"
                    cy="100"
                    r={radius}
                    fill="none"
                    stroke={getColorValue(item.color)}
                    strokeWidth="20"
                    strokeDasharray={strokeDasharray}
                    strokeDashoffset={strokeDashoffset}
                    className="transition-all duration-1000 ease-out"
                  />
                );
              })}
            </svg>
            
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">
                  {total.toLocaleString()}
                </div>
                <div className="text-sm text-gray-500">Total Ar</div>
              </div>
            </div>
          </div>
        </div>
        
        {showLegend && (
          <div className="grid grid-cols-1 gap-2">
            {data.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div 
                    className={`w-3 h-3 rounded-full ${item.color}`}
                  ></div>
                  <span className="text-sm text-gray-600 truncate">{item.label}</span>
                </div>
                <div className="text-sm text-gray-900 font-medium">
                  {((item.value / total) * 100).toFixed(1)}%
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  const renderLineChart = () => {
    if (data.length === 0 || maxValue === 0) {
      return (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-medium text-gray-900">{title}</h3>
            <TrendingUp className="w-5 h-5 text-gray-400" />
          </div>
          <div className="flex items-center justify-center h-48">
            <p className="text-gray-500">Aucune donnée disponible</p>
          </div>
        </div>
      );
    }

    const chartHeight = height - 60;
    const chartWidth = 400;
    const padding = 40;
    
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-medium text-gray-900">{title}</h3>
          <TrendingUp className="w-5 h-5 text-gray-400" />
        </div>
        
        <div className="relative overflow-x-auto">
          <svg width={chartWidth} height={chartHeight + 40} className="min-w-full">
            {/* Grid lines */}
            {[0, 25, 50, 75, 100].map((y) => (
              <line
                key={y}
                x1={padding}
                y1={padding + (y / 100) * chartHeight}
                x2={chartWidth - padding}
                y2={padding + (y / 100) * chartHeight}
                stroke="#f3f4f6"
                strokeWidth="1"
              />
            ))}
            
            {/* Data line */}
            {data.length > 1 && (
              <polyline
                fill="none"
                stroke="#3b82f6"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
                points={data.map((item, index) => {
                  const x = padding + (index / Math.max(data.length - 1, 1)) * (chartWidth - 2 * padding);
                  const y = padding + chartHeight - (item.value / maxValue) * chartHeight;
                  return `${x},${y}`;
                }).join(' ')}
              />
            )}
            
            {/* Data points */}
            {data.map((item, index) => {
              const x = padding + (data.length > 1 ? index / (data.length - 1) : 0.5) * (chartWidth - 2 * padding);
              const y = padding + chartHeight - (item.value / maxValue) * chartHeight;
              
              return (
                <g key={index}>
                  <circle
                    cx={x}
                    cy={y}
                    r="4"
                    fill="#3b82f6"
                  />
                  <text
                    x={x}
                    y={chartHeight + padding + 20}
                    textAnchor="middle"
                    className="text-xs fill-gray-600"
                  >
                    {item.label}
                  </text>
                </g>
              );
            })}
            
            {/* Y-axis labels */}
            {[0, 25, 50, 75, 100].map((y) => (
              <text
                key={y}
                x={padding - 10}
                y={padding + (y / 100) * chartHeight + 4}
                textAnchor="end"
                className="text-xs fill-gray-500"
              >
                {((maxValue * (100 - y)) / 100).toLocaleString()}
              </text>
            ))}
          </svg>
        </div>
      </div>
    );
  };

  const renderDonutChart = () => {
    if (total === 0) {
      return (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-medium text-gray-900">{title}</h3>
            <PieChart className="w-5 h-5 text-gray-400" />
          </div>
          <div className="flex items-center justify-center h-48">
            <p className="text-gray-500">Aucune donnée disponible</p>
          </div>
        </div>
      );
    }

    let cumulativePercentage = 0;
    const innerRadius = 50;
    const outerRadius = 80;
    const circumference = 2 * Math.PI * outerRadius;
    
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-medium text-gray-900">{title}</h3>
          <PieChart className="w-5 h-5 text-gray-400" />
        </div>
        
        <div className="flex items-center justify-center">
          <div className="relative">
            <svg width="200" height="200" viewBox="0 0 200 200" className="transform -rotate-90">
              <circle
                cx="100"
                cy="100"
                r={outerRadius}
                fill="none"
                stroke="#f3f4f6"
                strokeWidth={outerRadius - innerRadius}
              />
              {data.map((item, index) => {
                const percentage = (item.value / total) * 100;
                const strokeDasharray = `${(percentage / 100) * circumference} ${circumference}`;
                const strokeDashoffset = -cumulativePercentage * circumference / 100;
                cumulativePercentage += percentage;
                
                return (
                  <circle
                    key={index}
                    cx="100"
                    cy="100"
                    r={outerRadius}
                    fill="none"
                    stroke={getColorValue(item.color)}
                    strokeWidth={outerRadius - innerRadius}
                    strokeDasharray={strokeDasharray}
                    strokeDashoffset={strokeDashoffset}
                    className="transition-all duration-1000 ease-out"
                  />
                );
              })}
            </svg>
            
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-xl font-bold text-gray-900">
                  {data.length}
                </div>
                <div className="text-xs text-gray-500">Catégories</div>
              </div>
            </div>
          </div>
        </div>
        
        {showLegend && (
          <div className="space-y-1">
            {data.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${item.color}`}></div>
                  <span className="text-sm text-gray-600">{item.label}</span>
                </div>
                <div className="text-sm text-gray-900 font-medium">
                  {item.value.toLocaleString()} Ar
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      {type === 'bar' && renderBarChart()}
      {type === 'pie' && renderPieChart()}
      {type === 'line' && renderLineChart()}
      {type === 'donut' && renderDonutChart()}
    </div>
  );
}