import React, { useState } from 'react';
import { Modal } from '../Modal';
import { CertificateTemplate } from './CertificateTemplate';
import { saveCertificateRecord, generateCertificateNumber } from '../../lib/certificates';
import { useAuth } from '../../hooks/useAuth';
import { Calendar, FileText, Hash } from 'lucide-react';

interface Student {
  id: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  class: string;
  address: string;
  parentName: string;
}

interface CertificateModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: Student;
}

export function CertificateModal({ isOpen, onClose, student }: CertificateModalProps) {
  const { profile } = useAuth();
  const [formData, setFormData] = useState({
    schoolYear: '2024-2025',
    issueDate: new Date().toISOString().split('T')[0],
    certificateNumber: generateCertificateNumber()
  });
  
  const [showPreview, setShowPreview] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleGenerateCertificate = () => {
    setShowPreview(true);
  };

  const handlePrint = () => {
    // Enregistrer le certificat dans la base de données
    handleSaveCertificate();
    
    // Créer une nouvelle fenêtre pour l'impression
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      const certificateContent = document.getElementById('certificate-content');
      if (certificateContent) {
        printWindow.document.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <title>Certificat de Scolarité - ${student.firstName} ${student.lastName}</title>
              <style>
                body { 
                  margin: 0; 
                  padding: 20px; 
                  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                  background: white;
                }
                .print\\:hidden { display: none !important; }
                @media print {
                  body { margin: 0; padding: 0; }
                  .print\\:hidden { display: none !important; }
                }
                /* Styles Tailwind essentiels pour l'impression */
                .bg-white { background-color: white; }
                .p-8 { padding: 2rem; }
                .max-w-4xl { max-width: 56rem; }
                .mx-auto { margin-left: auto; margin-right: auto; }
                .border-4 { border-width: 4px; }
                .border-blue-600 { border-color: #2563eb; }
                .text-center { text-align: center; }
                .text-left { text-align: left; }
                .text-justify { text-align: justify; }
                .mb-8 { margin-bottom: 2rem; }
                .mb-4 { margin-bottom: 1rem; }
                .mb-2 { margin-bottom: 0.5rem; }
                .mt-12 { margin-top: 3rem; }
                .mt-8 { margin-top: 2rem; }
                .mt-6 { margin-top: 1.5rem; }
                .mt-4 { margin-top: 1rem; }
                .mt-2 { margin-top: 0.5rem; }
                .mt-1 { margin-top: 0.25rem; }
                .pt-4 { padding-top: 1rem; }
                .pb-4 { padding-bottom: 1rem; }
                .text-2xl { font-size: 1.5rem; line-height: 2rem; }
                .text-3xl { font-size: 1.875rem; line-height: 2.25rem; }
                .text-lg { font-size: 1.125rem; line-height: 1.75rem; }
                .text-sm { font-size: 0.875rem; line-height: 1.25rem; }
                .text-xs { font-size: 0.75rem; line-height: 1rem; }
                .font-bold { font-weight: 700; }
                .font-semibold { font-weight: 600; }
                .text-blue-800 { color: #1e40af; }
                .text-gray-800 { color: #1f2937; }
                .text-gray-700 { color: #374151; }
                .text-gray-600 { color: #4b5563; }
                .text-gray-500 { color: #6b7280; }
                .text-gray-400 { color: #9ca3af; }
                .bg-blue-50 { background-color: #eff6ff; }
                .border-l-4 { border-left-width: 4px; }
                .border-blue-500 { border-color: #3b82f6; }
                .border-t { border-top-width: 1px; }
                .border-t-2 { border-top-width: 2px; }
                .border-blue-200 { border-color: #dbeafe; }
                .border-gray-200 { border-color: #e5e7eb; }
                .border-gray-400 { border-color: #9ca3af; }
                .rounded-lg { border-radius: 0.5rem; }
                .rounded-full { border-radius: 9999px; }
                .p-6 { padding: 1.5rem; }
                .w-32 { width: 8rem; }
                .w-24 { width: 6rem; }
                .h-24 { height: 6rem; }
                .h-1 { height: 0.25rem; }
                .flex { display: flex; }
                .items-center { align-items: center; }
                .justify-center { justify-content: center; }
                .justify-between { justify-content: space-between; }
                .items-end { align-items: flex-end; }
                .space-y-6 > * + * { margin-top: 1.5rem; }
                .space-y-4 > * + * { margin-top: 1rem; }
                .gap-4 { gap: 1rem; }
                .grid { display: grid; }
                .grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)); }
                .grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
                .leading-relaxed { line-height: 1.625; }
                .relative { position: relative; }
                .absolute { position: absolute; }
                .inset-0 { top: 0; right: 0; bottom: 0; left: 0; }
                .opacity-5 { opacity: 0.05; }
                .pointer-events-none { pointer-events: none; }
                .z-10 { z-index: 10; }
                .w-16 { width: 4rem; }
                .h-16 { height: 4rem; }
                .w-8 { width: 2rem; }
                .h-8 { height: 2rem; }
                .w-96 { width: 24rem; }
                .h-96 { height: 24rem; }
                .w-3 { width: 0.75rem; }
                .h-3 { height: 0.75rem; }
                .mr-4 { margin-right: 1rem; }
                .mr-1 { margin-right: 0.25rem; }
                .bg-gradient-to-br { background-image: linear-gradient(to bottom right, var(--tw-gradient-stops)); }
                .from-blue-500 { --tw-gradient-from: #3b82f6; --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to, rgba(59, 130, 246, 0)); }
                .to-blue-600 { --tw-gradient-to: #2563eb; }
                .bg-gradient-to-r { background-image: linear-gradient(to right, var(--tw-gradient-stops)); }
                .from-blue-400 { --tw-gradient-from: #60a5fa; --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to, rgba(96, 165, 250, 0)); }
                .border-2 { border-width: 2px; }
                .border-dashed { border-style: dashed; }
                .border-gray-300 { border-color: #d1d5db; }
                @media (min-width: 768px) {
                  .md\\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
                }
              </style>
            </head>
            <body>
              ${certificateContent.outerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.print();
      }
    }
  };

  const handleSaveCertificate = async () => {
    if (!profile) return;
    
    try {
      setSaving(true);
      await saveCertificateRecord({
        studentId: student.id,
        studentName: `${student.firstName} ${student.lastName}`,
        certificateNumber: formData.certificateNumber,
        schoolYear: formData.schoolYear,
        issueDate: new Date(formData.issueDate),
        issuedBy: `${profile.firstName} ${profile.lastName}`
      });
    } catch (error) {
      console.error('Erreur lors de l\'enregistrement du certificat:', error);
    } finally {
      setSaving(false);
    }
  };

  const certificateData = {
    student,
    schoolYear: formData.schoolYear,
    issueDate: formData.issueDate,
    certificateNumber: formData.certificateNumber
  };

  if (showPreview) {
    return (
      <Modal
        isOpen={isOpen}
        onClose={onClose}
        title="Certificat de Scolarité"
        size="xl"
      >
        <CertificateTemplate 
          data={certificateData}
          onPrint={handlePrint}
        />
        <div className="mt-6 flex justify-between">
          <button
            onClick={() => setShowPreview(false)}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Retour
          </button>
          <button
            onClick={handlePrint}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
            disabled={saving}
          >
            {saving ? 'Enregistrement...' : 'Imprimer'}
          </button>
        </div>
      </Modal>
    );
  }

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Générer un Certificat de Scolarité"
      size="lg"
    >
      <div className="space-y-6">
        {/* Informations de l'élève */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h3 className="font-medium text-gray-900 mb-3">Informations de l'élève</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <p><span className="font-medium">Nom complet :</span> {student.firstName} {student.lastName}</p>
              <p><span className="font-medium">Date de naissance :</span> {new Date(student.dateOfBirth).toLocaleDateString('fr-FR')}</p>
            </div>
            <div>
              <p><span className="font-medium">Classe :</span> {student.class}</p>
              <p><span className="font-medium">Parent/Tuteur :</span> {student.parentName}</p>
            </div>
          </div>
        </div>

        {/* Paramètres du certificat */}
        <div className="space-y-4">
          <h3 className="font-medium text-gray-900">Paramètres du certificat</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="w-4 h-4 inline mr-2" />
                Année scolaire
              </label>
              <select
                name="schoolYear"
                value={formData.schoolYear}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="2024-2025">2024-2025</option>
                <option value="2023-2024">2023-2024</option>
                <option value="2022-2023">2022-2023</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <FileText className="w-4 h-4 inline mr-2" />
                Date d'émission
              </label>
              <input
                type="date"
                name="issueDate"
                value={formData.issueDate}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Hash className="w-4 h-4 inline mr-2" />
                Numéro de certificat
              </label>
              <input
                type="text"
                name="certificateNumber"
                value={formData.certificateNumber}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="CERT-123456"
              />
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex space-x-3 pt-4">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Annuler
          </button>
          <button
            onClick={handleGenerateCertificate}
            className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Générer le certificat
          </button>
        </div>
      </div>
    </Modal>
  );
}