import React from 'react';
import { School, Calendar, MapPin, Phone, Mail } from 'lucide-react';

interface CertificateData {
  student: {
    firstName: string;
    lastName: string;
    dateOfBirth: string;
    class: string;
    address: string;
    parentName: string;
  };
  schoolYear: string;
  issueDate: string;
  certificateNumber: string;
}

interface CertificateTemplateProps {
  data: CertificateData;
  onPrint?: () => void;
}

export function CertificateTemplate({ data, onPrint }: CertificateTemplateProps) {
  const currentDate = new Date().toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  return (
    <div className="bg-white p-8 max-w-4xl mx-auto" id="certificate-content">
      {/* En-tête officiel */}
      <div className="border-4 border-blue-600 p-8 relative">
        {/* Filigrane */}
        <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none">
          <School className="w-96 h-96 text-blue-600" />
        </div>
        
        {/* Header */}
        <div className="text-center mb-8 relative z-10">
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center mr-4">
              <School className="w-8 h-8 text-white" />
            </div>
            <div className="text-left">
              <h1 className="text-2xl font-bold text-blue-800">ÉCOLE LES POUPONS</h1>
              <p className="text-sm text-gray-600">École Maternelle et Primaire</p>
            </div>
          </div>
          
          <div className="border-t-2 border-blue-200 pt-4">
            <div className="flex justify-between text-xs text-gray-600">
              <div className="flex items-center">
                <MapPin className="w-3 h-3 mr-1" />
                Antananarivo, Madagascar
              </div>
              <div className="flex items-center">
                <Phone className="w-3 h-3 mr-1" />
                +261 34 12 345 67
              </div>
              <div className="flex items-center">
                <Mail className="w-3 h-3 mr-1" />
                contact@lespoupons.mg
              </div>
            </div>
          </div>
        </div>

        {/* Titre du certificat */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-800 mb-2">CERTIFICAT DE SCOLARITÉ</h2>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-400 to-blue-600 mx-auto"></div>
        </div>

        {/* Numéro et date */}
        <div className="flex justify-between mb-8 text-sm">
          <div>
            <span className="font-semibold">N° {data.certificateNumber}</span>
          </div>
          <div>
            <span className="font-semibold">Antananarivo, le {currentDate}</span>
          </div>
        </div>

        {/* Corps du certificat */}
        <div className="space-y-6 text-justify leading-relaxed">
          <p className="text-lg">
            <span className="font-semibold">Le Directeur de l'École LES POUPONS</span> certifie que :
          </p>

          <div className="bg-blue-50 p-6 rounded-lg border-l-4 border-blue-500">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="mb-2">
                  <span className="font-semibold text-blue-800">Nom et Prénom :</span><br />
                  <span className="text-lg font-bold text-gray-800">
                    {data.student.lastName} {data.student.firstName}
                  </span>
                </p>
                <p className="mb-2">
                  <span className="font-semibold text-blue-800">Date de naissance :</span><br />
                  <span className="text-gray-700">
                    {new Date(data.student.dateOfBirth).toLocaleDateString('fr-FR', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })}
                  </span>
                </p>
              </div>
              <div>
                <p className="mb-2">
                  <span className="font-semibold text-blue-800">Classe :</span><br />
                  <span className="text-lg font-bold text-gray-800">{data.student.class}</span>
                </p>
                <p className="mb-2">
                  <span className="font-semibold text-blue-800">Année scolaire :</span><br />
                  <span className="text-gray-700">{data.schoolYear}</span>
                </p>
              </div>
            </div>
            <div className="mt-4">
              <p className="mb-2">
                <span className="font-semibold text-blue-800">Adresse :</span><br />
                <span className="text-gray-700">{data.student.address}</span>
              </p>
              <p>
                <span className="font-semibold text-blue-800">Parent/Tuteur :</span><br />
                <span className="text-gray-700">{data.student.parentName}</span>
              </p>
            </div>
          </div>

          <p className="text-lg">
            est <span className="font-bold">régulièrement inscrit(e)</span> et suit assidûment les cours dans notre établissement 
            pour l'année scolaire <span className="font-bold">{data.schoolYear}</span>.
          </p>

          <p className="text-lg">
            Ce certificat est délivré pour servir et valoir ce que de droit.
          </p>
        </div>

        {/* Signatures */}
        <div className="mt-12 flex justify-between items-end">
          <div className="text-center">
            <p className="text-sm text-gray-600 mb-8">L'intéressé(e)</p>
            <div className="border-t border-gray-400 w-32"></div>
            <p className="text-xs text-gray-500 mt-1">Signature</p>
          </div>
          
          <div className="text-center">
            <p className="text-sm font-semibold mb-2">Le Directeur</p>
            <div className="w-24 h-24 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center mb-2">
              <span className="text-xs text-gray-400">Cachet</span>
            </div>
            <div className="border-t border-gray-400 w-32"></div>
            <p className="text-xs text-gray-500 mt-1">Signature et cachet</p>
          </div>
        </div>

        {/* Pied de page */}
        <div className="mt-8 pt-4 border-t border-gray-200 text-center">
          <p className="text-xs text-gray-500">
            Ce document est un certificat officiel de l'École LES POUPONS - 
            Toute falsification est passible de poursuites judiciaires
          </p>
        </div>
      </div>

      {/* Bouton d'impression (masqué à l'impression) */}
      {onPrint && (
        <div className="mt-6 text-center print:hidden">
          <button
            onClick={onPrint}
            className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
            </svg>
            Imprimer le certificat
          </button>
        </div>
      )}
    </div>
  );
}