import React, { useState, useEffect } from 'react';
import { Calendar, Clock, BookOpen, Users, MapPin } from 'lucide-react';
import { useFirebaseCollection } from '../../hooks/useFirebaseCollection';
import { classesService, subjectsService, teachersService } from '../../lib/firebase/firebaseService';

interface ScheduleFormProps {
  onSubmit: (data: any) => void;
  onCancel: () => void;
  initialData?: any;
  classes?: any[];
  subjects?: any[];
  teachers?: any[];
}

export function ScheduleForm({ onSubmit, onCancel, initialData, classes = [], subjects = [], teachers = [] }: ScheduleFormProps) {
  // Hooks Firebase pour charger les données en temps réel si pas fournies
  const { data: firebaseClasses, loading: classesLoading } = useFirebaseCollection(classesService, true);
  const { data: firebaseSubjects, loading: subjectsLoading } = useFirebaseCollection(subjectsService, true);
  const { data: firebaseTeachers, loading: teachersLoading } = useFirebaseCollection(teachersService, true);

  // Utiliser les données fournies ou celles de Firebase
  const finalClasses = classes.length > 0 ? classes : firebaseClasses;
  const finalSubjects = subjects.length > 0 ? subjects : firebaseSubjects;
  const finalTeachers = teachers.length > 0 ? teachers : firebaseTeachers;

  const [formData, setFormData] = useState({
    class: initialData?.class || '',
    subject: initialData?.subject || '',
    teacher: initialData?.teacher || '',
    day: initialData?.day || '',
    startTime: initialData?.startTime || '',
    endTime: initialData?.endTime || '',
    room: initialData?.room || '',
    type: initialData?.type || 'course'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const days = [
    'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Users className="w-4 h-4 inline mr-2" />
            Classe
          </label>
          {finalClasses.length > 0 ? (
            <select
              name="class"
              value={formData.class}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Sélectionner une classe</option>
              {finalClasses.map(classItem => (
                <option key={classItem.id} value={classItem.name}>
                  {classItem.name} - {classItem.level}
                </option>
              ))}
            </select>
          ) : (
            <select
              name="class"
              value={formData.class}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">{classesLoading ? 'Chargement des classes...' : 'Aucune classe disponible'}</option>
            </select>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <BookOpen className="w-4 h-4 inline mr-2" />
            Matière
          </label>
          {finalSubjects.length > 0 ? (
            <select
              name="subject"
              value={formData.subject}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Sélectionner une matière</option>
              {finalSubjects.map(subject => (
                <option key={subject.id} value={subject.name}>
                  {subject.name} ({subject.code})
                </option>
              ))}
            </select>
          ) : (
            <select
              name="subject"
              value={formData.subject}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">{subjectsLoading ? 'Chargement des matières...' : 'Aucune matière disponible'}</option>
            </select>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Enseignant
          </label>
          {finalTeachers.length > 0 ? (
            <select
              name="teacher"
              value={formData.teacher}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Sélectionner un enseignant</option>
              {finalTeachers.map(teacher => (
                <option key={teacher.id} value={`${teacher.firstName} ${teacher.lastName}`}>
                  {teacher.firstName} {teacher.lastName} - {teacher.subject}
                </option>
              ))}
            </select>
          ) : (
            <select
              name="teacher"
              value={formData.teacher}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">{teachersLoading ? 'Chargement des enseignants...' : 'Aucun enseignant disponible'}</option>
            </select>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Calendar className="w-4 h-4 inline mr-2" />
            Jour
          </label>
          <select
            name="day"
            value={formData.day}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Sélectionner un jour</option>
            {days.map(day => (
              <option key={day} value={day}>{day}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Clock className="w-4 h-4 inline mr-2" />
            Heure de début
          </label>
          <input
            type="time"
            name="startTime"
            value={formData.startTime}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Clock className="w-4 h-4 inline mr-2" />
            Heure de fin
          </label>
          <input
            type="time"
            name="endTime"
            value={formData.endTime}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <MapPin className="w-4 h-4 inline mr-2" />
            Salle
          </label>
          <input
            type="text"
            name="room"
            value={formData.room}
            onChange={handleChange}
            placeholder="ex: Salle 101"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Type
          </label>
          <select
            name="type"
            value={formData.type}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="course">Cours</option>
            <option value="exam">Examen</option>
            <option value="tp">Travaux Pratiques</option>
            <option value="sport">Sport</option>
            <option value="break">Récréation</option>
          </select>
        </div>
      </div>

      <div className="flex space-x-3 pt-4">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
        >
          Annuler
        </button>
        <button
          type="submit"
          className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          {initialData ? 'Modifier' : 'Ajouter'}
        </button>
      </div>
    </form>
  );
}