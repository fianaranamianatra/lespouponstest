import React, { useState, useEffect } from 'react';
import { User, BookOpen, FileText, Calendar, Award } from 'lucide-react';
import { useFirebaseCollection } from '../../hooks/useFirebaseCollection';
import { studentsService, subjectsService, teachersService } from '../../lib/firebase/firebaseService';

interface GradeFormProps {
  onSubmit: (data: any) => void;
  onCancel: () => void;
  initialData?: any;
  students?: any[];
  subjects?: any[];
  teachers?: any[];
}

export function GradeForm({ onSubmit, onCancel, initialData, students = [], subjects = [], teachers = [] }: GradeFormProps) {
  // Hooks Firebase pour charger les données en temps réel si pas fournies
  const { data: firebaseStudents, loading: studentsLoading } = useFirebaseCollection(studentsService, true);
  const { data: firebaseSubjects, loading: subjectsLoading } = useFirebaseCollection(subjectsService, true);
  const { data: firebaseTeachers, loading: teachersLoading } = useFirebaseCollection(teachersService, true);

  // Utiliser les données fournies ou celles de Firebase
  const finalStudents = students.length > 0 ? students : firebaseStudents;
  const finalSubjects = subjects.length > 0 ? subjects : firebaseSubjects;
  const finalTeachers = teachers.length > 0 ? teachers : firebaseTeachers;

  const [formData, setFormData] = useState({
    studentName: initialData?.studentName || '',
    subject: initialData?.subject || '',
    assignment: initialData?.assignment || '',
    grade: initialData?.grade || '',
    maxGrade: initialData?.maxGrade || 20,
    date: initialData?.date || new Date().toISOString().split('T')[0],
    teacher: initialData?.teacher || '',
    type: initialData?.type || 'exam'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <User className="w-4 h-4 inline mr-2" />
            Élève
          </label>
          {finalStudents.length > 0 ? (
            <select
              name="studentName"
              value={formData.studentName}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="">Sélectionner un élève</option>
              {finalStudents.map(student => (
                <option key={student.id} value={`${student.firstName} ${student.lastName}`}>
                  {student.firstName} {student.lastName} - {student.class}
                </option>
              ))}
            </select>
          ) : (
            <select
              name="studentName"
              value={formData.studentName}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="">{studentsLoading ? 'Chargement des élèves...' : 'Aucun élève disponible'}</option>
            </select>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <BookOpen className="w-4 h-4 inline mr-2" />
            Matière
          </label>
          {finalSubjects.length > 0 ? (
            <select
              name="subject"
              value={formData.subject}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="">Sélectionner une matière</option>
              {finalSubjects.map(subject => (
                <option key={subject.id} value={subject.name}>
                  {subject.name} ({subject.code})
                </option>
              ))}
            </select>
          ) : (
            <select
              name="subject"
              value={formData.subject}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="">{subjectsLoading ? 'Chargement des matières...' : 'Aucune matière disponible'}</option>
              <option value="Mathématiques">Mathématiques</option>
              <option value="Français">Français</option>
              <option value="Anglais">Anglais</option>
              <option value="Sciences">Sciences</option>
              <option value="Histoire-Géographie">Histoire-Géographie</option>
            </select>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <FileText className="w-4 h-4 inline mr-2" />
            Devoir/Évaluation
          </label>
          <input
            type="text"
            name="assignment"
            value={formData.assignment}
            onChange={handleChange}
            placeholder="ex: Contrôle Chapitre 3"
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Type d'évaluation
          </label>
          <select
            name="type"
            value={formData.type}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
          >
            <option value="exam">Examen</option>
            <option value="homework">Devoir</option>
            <option value="quiz">Quiz</option>
            <option value="project">Projet</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Award className="w-4 h-4 inline mr-2" />
            Note obtenue
          </label>
          <input
            type="number"
            name="grade"
            value={formData.grade}
            onChange={handleChange}
            min="0"
            max={formData.maxGrade}
            step="0.5"
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Note maximale
          </label>
          <input
            type="number"
            name="maxGrade"
            value={formData.maxGrade}
            onChange={handleChange}
            min="1"
            max="100"
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Calendar className="w-4 h-4 inline mr-2" />
            Date
          </label>
          <input
            type="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Enseignant
          </label>
          {finalTeachers.length > 0 ? (
            <select
              name="teacher"
              value={formData.teacher}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="">Sélectionner un enseignant</option>
              {finalTeachers.map(teacher => (
                <option key={teacher.id} value={`${teacher.firstName} ${teacher.lastName}`}>
                  {teacher.firstName} {teacher.lastName} - {teacher.subject}
                </option>
              ))}
            </select>
          ) : (
            <select
              name="teacher"
              value={formData.teacher}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="">{teachersLoading ? 'Chargement des enseignants...' : 'Aucun enseignant disponible'}</option>
            </select>
          )}
        </div>
      </div>

      <div className="flex space-x-3 pt-4">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
        >
          Annuler
        </button>
        <button
          type="submit"
          className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
        >
          {initialData ? 'Modifier' : 'Ajouter'}
        </button>
      </div>
    </form>
  );
}