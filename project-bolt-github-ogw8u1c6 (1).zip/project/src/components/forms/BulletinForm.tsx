import React, { useState, useEffect } from 'react';
import { User, Calendar, BookOpen, Trash2, Plus } from 'lucide-react';
import { useFirebaseCollection } from '../../hooks/useFirebaseCollection';
import { studentsService, subjectsService, teachersService } from '../../lib/firebase/firebaseService';

interface BulletinFormProps {
  onSubmit: (data: any) => void;
  onCancel: () => void;
  initialData?: any;
  students?: any[];
  subjects?: any[];
  teachers?: any[];
}

export function BulletinForm({ onSubmit, onCancel, initialData, students = [], subjects = [], teachers = [] }: BulletinFormProps) {
  // Hooks Firebase pour charger les données en temps réel si pas fournies
  const { data: firebaseStudents, loading: studentsLoading } = useFirebaseCollection(studentsService, true);
  const { data: firebaseSubjects, loading: subjectsLoading } = useFirebaseCollection(subjectsService, true);
  const { data: firebaseTeachers, loading: teachersLoading } = useFirebaseCollection(teachersService, true);

  // Utiliser les données fournies ou celles de Firebase
  const finalStudents = students.length > 0 ? students : firebaseStudents;
  const finalSubjects = subjects.length > 0 ? subjects : firebaseSubjects;
  const finalTeachers = teachers.length > 0 ? teachers : firebaseTeachers;

  const [formData, setFormData] = useState({
    studentId: initialData?.studentId || '',
    studentName: initialData?.studentName || '',
    class: initialData?.class || '',
    trimester: initialData?.trimester || 'PREMIER TRIMESTRE',
    schoolYear: initialData?.schoolYear || `${new Date().getFullYear()}-${new Date().getFullYear() + 1}`,
    subjects: initialData?.subjects || [],
    absences: initialData?.absences || 0,
    retards: initialData?.retards || 0,
    isPassing: initialData?.isPassing !== undefined ? initialData.isPassing : true
  });

  // Initialiser les matières depuis la base de données si c'est un nouveau bulletin
  useEffect(() => {
    if (!initialData && formData.subjects.length === 0 && finalSubjects.length > 0) {
      const subjectsData = finalSubjects.map((subject, index) => ({
        name: subject.name,
        n1: 0,
        n2: 0,
        exam: 0,
        average: 0,
        coefficient: subject.hoursPerWeek > 3 ? 2 : 1, // Coefficients basés sur les heures par semaine
        weightedAverage: 0,
        rank: 0,
        appreciation: '',
        teacher: subject.teachers && subject.teachers.length > 0 ? 
                 finalTeachers.find(t => t.id === subject.teachers[0])?.firstName + ' ' + 
                 finalTeachers.find(t => t.id === subject.teachers[0])?.lastName : ''
      }));
      
      setFormData(prev => ({
        ...prev,
        subjects: subjectsData
      }));
    }
  }, [initialData, finalSubjects, finalTeachers]);

  // Mettre à jour la classe lorsque l'élève change
  useEffect(() => {
    if (formData.studentId && finalStudents.length > 0) {
      const selectedStudent = finalStudents.find(s => s.id === formData.studentId);
      if (selectedStudent) {
        setFormData(prev => ({
          ...prev,
          studentName: `${selectedStudent.firstName} ${selectedStudent.lastName}`,
          class: selectedStudent.class
        }));
      }
    }
  }, [formData.studentId, finalStudents]);

  // Calculer les moyennes automatiquement
  useEffect(() => {
    const updatedSubjects = formData.subjects.map(subject => {
      // Calculer la moyenne de la matière
      const average = (parseFloat(subject.n1) + parseFloat(subject.n2) + parseFloat(subject.exam)) / 3;
      
      // Calculer la moyenne coefficientée
      const weightedAverage = average * parseFloat(subject.coefficient);
      
      return {
        ...subject,
        average: isNaN(average) ? 0 : average,
        weightedAverage: isNaN(weightedAverage) ? 0 : weightedAverage
      };
    });
    
    setFormData(prev => ({
      ...prev,
      subjects: updatedSubjects
    }));
  }, [formData.subjects.map(s => `${s.n1}-${s.n2}-${s.exam}-${s.coefficient}`).join('|')]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    
    // Gérer les cases à cocher
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubjectChange = (index: number, field: string, value: any) => {
    const updatedSubjects = [...formData.subjects];
    updatedSubjects[index] = {
      ...updatedSubjects[index],
      [field]: field === 'name' || field === 'appreciation' || field === 'teacher' ? value : parseFloat(value)
    };
    
    setFormData(prev => ({
      ...prev,
      subjects: updatedSubjects
    }));
  };

  const handleAddSubject = () => {
    const newSubject = {
      name: '',
      n1: 0,
      n2: 0,
      exam: 0,
      average: 0,
      coefficient: 1,
      weightedAverage: 0,
      rank: 0,
      appreciation: '',
      teacher: ''
    };
    
    setFormData(prev => ({
      ...prev,
      subjects: [...prev.subjects, newSubject]
    }));
  };

  const handleRemoveSubject = (index: number) => {
    const updatedSubjects = [...formData.subjects];
    updatedSubjects.splice(index, 1);
    
    setFormData(prev => ({
      ...prev,
      subjects: updatedSubjects
    }));
  };

  // Calculer la moyenne générale
  const totalCoefficient = formData.subjects.reduce((sum, subject) => sum + parseFloat(subject.coefficient), 0);
  const totalWeightedAverage = formData.subjects.reduce((sum, subject) => sum + subject.weightedAverage, 0);
  const generalAverage = totalCoefficient > 0 ? totalWeightedAverage / totalCoefficient : 0;

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <User className="w-4 h-4 inline mr-2" />
            Élève
          </label>
          <select
            name="studentId"
            value={formData.studentId}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Sélectionner un élève</option>
            {studentsLoading ? (
              <option disabled>Chargement des élèves...</option>
            ) : (
              finalStudents.map(student => (
              <option key={student.id} value={student.id}>
                {student.firstName} {student.lastName} - {student.class}
              </option>
              ))
            )}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Calendar className="w-4 h-4 inline mr-2" />
            Trimestre
          </label>
          <select
            name="trimester"
            value={formData.trimester}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="PREMIER TRIMESTRE">PREMIER TRIMESTRE</option>
            <option value="DEUXIEME TRIMESTRE">DEUXIEME TRIMESTRE</option>
            <option value="TROISIEME TRIMESTRE">TROISIEME TRIMESTRE</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Calendar className="w-4 h-4 inline mr-2" />
            Année Scolaire
          </label>
          <input
            type="text"
            name="schoolYear"
            value={formData.schoolYear}
            onChange={handleChange}
            placeholder="ex: 2024-2025"
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Tableau des matières */}
      <div className="mt-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium text-gray-900">Notes par Matière</h3>
          <button
            type="button"
            onClick={handleAddSubject}
            className="inline-flex items-center px-3 py-1.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4 mr-1" />
            Ajouter une matière
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full border-collapse border border-gray-300">
            <thead className="bg-gray-100">
              <tr>
                <th className="border border-gray-300 px-4 py-2 text-left">Matière</th>
                <th className="border border-gray-300 px-4 py-2 text-center">N1</th>
                <th className="border border-gray-300 px-4 py-2 text-center">N2</th>
                <th className="border border-gray-300 px-4 py-2 text-center">Exam</th>
                <th className="border border-gray-300 px-4 py-2 text-center">Moy/20</th>
                <th className="border border-gray-300 px-4 py-2 text-center">Coeff</th>
                <th className="border border-gray-300 px-4 py-2 text-center">Moy. Coeff</th>
                <th className="border border-gray-300 px-4 py-2 text-center">Rang</th>
                <th className="border border-gray-300 px-4 py-2 text-left">Appréciations</th>
                <th className="border border-gray-300 px-4 py-2 text-left">Enseignant</th>
                <th className="border border-gray-300 px-4 py-2 text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              {formData.subjects.map((subject, index) => (
                <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                  <td className="border border-gray-300 px-4 py-2">
                    <input
                      type="text"
                      value={subject.name}
                      onChange={(e) => handleSubjectChange(index, 'name', e.target.value)}
                      className="w-full px-2 py-1 border border-gray-300 rounded"
                      list="available-subjects"
                    />
                    <datalist id="available-subjects">
                      {finalSubjects.map((subj, i) => (
                        <option key={i} value={subj.name} />
                      ))}
                    </datalist>
                  </td>
                  <td className="border border-gray-300 px-4 py-2">
                    <input
                      type="number"
                      min="0"
                      max="20"
                      step="0.5"
                      value={subject.n1}
                      onChange={(e) => handleSubjectChange(index, 'n1', e.target.value)}
                      className="w-16 px-2 py-1 border border-gray-300 rounded text-center"
                    />
                  </td>
                  <td className="border border-gray-300 px-4 py-2">
                    <input
                      type="number"
                      min="0"
                      max="20"
                      step="0.5"
                      value={subject.n2}
                      onChange={(e) => handleSubjectChange(index, 'n2', e.target.value)}
                      className="w-16 px-2 py-1 border border-gray-300 rounded text-center"
                    />
                  </td>
                  <td className="border border-gray-300 px-4 py-2">
                    <input
                      type="number"
                      min="0"
                      max="20"
                      step="0.5"
                      value={subject.exam}
                      onChange={(e) => handleSubjectChange(index, 'exam', e.target.value)}
                      className="w-16 px-2 py-1 border border-gray-300 rounded text-center"
                    />
                  </td>
                  <td className="border border-gray-300 px-4 py-2 text-center font-medium">
                    {subject.average.toFixed(2)}
                  </td>
                  <td className="border border-gray-300 px-4 py-2">
                    <input
                      type="number"
                      min="1"
                      max="5"
                      value={subject.coefficient}
                      onChange={(e) => handleSubjectChange(index, 'coefficient', e.target.value)}
                      className="w-16 px-2 py-1 border border-gray-300 rounded text-center"
                    />
                  </td>
                  <td className="border border-gray-300 px-4 py-2 text-center font-medium">
                    {subject.weightedAverage.toFixed(2)}
                  </td>
                  <td className="border border-gray-300 px-4 py-2">
                    <input
                      type="number"
                      min="1"
                      max="50"
                      value={subject.rank}
                      onChange={(e) => handleSubjectChange(index, 'rank', e.target.value)}
                      className="w-16 px-2 py-1 border border-gray-300 rounded text-center"
                    />
                  </td>
                  <td className="border border-gray-300 px-4 py-2">
                    <input
                      type="text"
                      value={subject.appreciation}
                      onChange={(e) => handleSubjectChange(index, 'appreciation', e.target.value)}
                      className="w-full px-2 py-1 border border-gray-300 rounded"
                      placeholder="Appréciation..."
                    />
                  </td>
                  <td className="border border-gray-300 px-4 py-2">
                    <select
                      value={subject.teacher}
                      onChange={(e) => handleSubjectChange(index, 'teacher', e.target.value)}
                      className="w-full px-2 py-1 border border-gray-300 rounded"
                    >
                      <option value="">Sélectionner</option>
                     {finalTeachers.map(teacher => (
                        <option key={teacher.id} value={`${teacher.firstName} ${teacher.lastName}`}>
                          {teacher.firstName} {teacher.lastName}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="border border-gray-300 px-4 py-2 text-center">
                    <button
                      type="button"
                      onClick={() => handleRemoveSubject(index)}
                      className="p-1 text-red-500 hover:bg-red-50 rounded-full"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
              <tr className="bg-gray-100 font-bold">
                <td className="border border-gray-300 px-4 py-2">TOTAL</td>
                <td className="border border-gray-300 px-4 py-2 text-center" colSpan={4}></td>
                <td className="border border-gray-300 px-4 py-2 text-center">{totalCoefficient}</td>
                <td className="border border-gray-300 px-4 py-2 text-center">{totalWeightedAverage.toFixed(2)}</td>
                <td className="border border-gray-300 px-4 py-2 text-center" colSpan={4}></td>
              </tr>
            </tbody>
            <tfoot>
              <tr className="bg-blue-50">
                <td className="border border-gray-300 px-4 py-2 font-bold" colSpan={2}>MOYENNE GÉNÉRALE</td>
                <td className="border border-gray-300 px-4 py-2 text-center font-bold text-lg" colSpan={9}>
                  {generalAverage.toFixed(2)}/20
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Informations complémentaires */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Absences (jours)
          </label>
          <input
            type="number"
            name="absences"
            min="0"
            value={formData.absences}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Retards
          </label>
          <input
            type="number"
            name="retards"
            min="0"
            value={formData.retards}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <div className="flex items-center">
          <input
            type="checkbox"
            id="isPassing"
            name="isPassing"
            checked={formData.isPassing}
            onChange={(e) => setFormData(prev => ({ ...prev, isPassing: e.target.checked }))}
            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
          />
          <label htmlFor="isPassing" className="ml-2 block text-sm text-gray-900">
            Passant
          </label>
        </div>
      </div>

      <div className="flex space-x-3 pt-4">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
        >
          Annuler
        </button>
        <button
          type="submit"
          className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          {initialData ? 'Mettre à jour' : 'Créer le bulletin'}
        </button>
      </div>
    </form>
  );
}