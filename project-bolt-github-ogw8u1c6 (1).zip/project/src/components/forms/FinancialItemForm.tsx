import React, { useState, useEffect } from 'react';
import { X, Save, DollarSign, User, Calendar, FileText } from 'lucide-react';
import { useFirebaseCollection } from '../../hooks/useFirebaseCollection';
import { studentsService, teachersService } from '../../lib/firebase/firebaseService';

interface FinancialItem {
  id?: string;
  type: 'salary' | 'registration' | 'extracurricular' | 'canteen' | 'transport' | 'other';
  category: string;
  amount: number;
  beneficiary: string;
  beneficiaryType: 'teacher' | 'student' | 'staff' | 'other';
  description: string;
  frequency: 'monthly' | 'quarterly' | 'annual' | 'one-time';
  dueDate: string;
  status: 'pending' | 'paid' | 'overdue';
  createdAt?: string;
  updatedAt?: string;
}

interface FinancialItemFormProps {
  item?: FinancialItem;
  onSubmit: (item: Omit<FinancialItem, 'id'>) => void;
  onCancel: () => void;
}

const typeOptions = [
  { value: 'salary', label: 'Salaire', icon: '💰' },
  { value: 'registration', label: 'Frais d\'inscription', icon: '📝' },
  { value: 'extracurricular', label: 'Activités parascolaires', icon: '🎯' },
  { value: 'canteen', label: 'Cantine', icon: '🍽️' },
  { value: 'transport', label: 'Transport', icon: '🚌' },
  { value: 'electricity', label: 'Électricité', icon: '⚡' },
  { value: 'other', label: 'Autres', icon: '📋' }
];

const categoryOptions = {
  salary: ['Enseignant', 'Personnel administratif', 'Personnel de service', 'Direction'],
  registration: ['Maternelle', 'Primaire', 'Réinscription', 'Frais de dossier'],
  extracurricular: ['Sport', 'Musique', 'Arts', 'Sciences', 'Informatique'],
  canteen: ['Repas mensuel', 'Repas quotidien', 'Goûter'],
  transport: ['Transport scolaire', 'Sortie pédagogique'],
  electricity: ['Facture mensuelle', 'Maintenance électrique', 'Installation électrique', 'Éclairage'],
  payroll: ['Salaire brut', 'Cotisations CNAPS', 'Cotisations OSTIE', 'Salaire net'],
  other: ['Fournitures', 'Maintenance', 'Assurance', 'Divers']
};

const frequencyOptions = [
  { value: 'monthly', label: 'Mensuel' },
  { value: 'quarterly', label: 'Trimestriel' },
  { value: 'annual', label: 'Annuel' },
  { value: 'one-time', label: 'Ponctuel' }
];

const monthOptions = [
  { value: 'janvier', label: 'Janvier' },
  { value: 'fevrier', label: 'Février' },
  { value: 'mars', label: 'Mars' },
  { value: 'avril', label: 'Avril' },
  { value: 'mai', label: 'Mai' },
  { value: 'juin', label: 'Juin' },
  { value: 'juillet', label: 'Juillet' },
  { value: 'aout', label: 'Août' },
  { value: 'septembre', label: 'Septembre' },
  { value: 'octobre', label: 'Octobre' },
  { value: 'novembre', label: 'Novembre' },
  { value: 'decembre', label: 'Décembre' }
];

const statusOptions = [
  { value: 'pending', label: 'En attente', color: 'bg-yellow-100 text-yellow-800' },
  { value: 'paid', label: 'Payé', color: 'bg-green-100 text-green-800' },
  { value: 'overdue', label: 'En retard', color: 'bg-red-100 text-red-800' }
];

export default function FinancialItemForm({ item, onSubmit, onCancel }: FinancialItemFormProps) {
  const [formData, setFormData] = useState<Omit<FinancialItem, 'id'>>({
    type: 'salary',
    category: '',
    amount: 0,
    beneficiary: '',
    beneficiaryType: 'teacher',
    description: '',
    month: 'janvier',
    dueDate: '',
    status: 'pending',
    ...item
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  // Load students and teachers for beneficiary selection
  const { data: students, loading: studentsLoading } = useFirebaseCollection(studentsService);
  const { data: teachers, loading: teachersLoading } = useFirebaseCollection(teachersService);

  useEffect(() => {
    if (formData.type && categoryOptions[formData.type as keyof typeof categoryOptions]) {
      const availableCategories = categoryOptions[formData.type as keyof typeof categoryOptions];
      if (!availableCategories.includes(formData.category)) {
        setFormData(prev => ({ ...prev, category: availableCategories[0] || '' }));
      }
    }
  }, [formData.type]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.type) newErrors.type = 'Le type est requis';
    if (!formData.category) newErrors.category = 'La catégorie est requise';
    if (!formData.amount || formData.amount <= 0) newErrors.amount = 'Le montant doit être supérieur à 0';
    if (!formData.beneficiary.trim()) newErrors.beneficiary = 'Le bénéficiaire est requis';
    if (!formData.description.trim()) newErrors.description = 'La description est requise';
    if (!formData.dueDate) newErrors.dueDate = 'La date d\'échéance est requise';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit({
        ...formData,
        amount: Number(formData.amount),
        createdAt: item?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
    }
  };

  const handleInputChange = (field: keyof typeof formData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const getBeneficiaryOptions = () => {
    if (formData.beneficiaryType === 'student') {
      return students?.map(student => ({
        value: student.id,
        label: `${student.firstName} ${student.lastName} - ${student.class}`
      })) || [];
    } else if (formData.beneficiaryType === 'teacher') {
      return teachers?.map(teacher => ({
        value: teacher.id,
        label: `${teacher.firstName} ${teacher.lastName} - ${teacher.subject}`
      })) || [];
    }
    return [];
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center space-x-3">
            <DollarSign className="w-6 h-6 text-green-600" />
            <h2 className="text-xl font-semibold text-gray-900">
              {item ? 'Modifier l\'élément financier' : 'Nouvel élément financier'}
            </h2>
          </div>
          <button
            onClick={onCancel}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Type and Category */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Type *
              </label>
              <select
                value={formData.type}
                onChange={(e) => handleInputChange('type', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  errors.type ? 'border-red-500' : 'border-gray-300'
                }`}
              >
                {typeOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.icon} {option.label}
                  </option>
                ))}
              </select>
              {errors.type && <p className="text-red-500 text-sm mt-1">{errors.type}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Catégorie *
              </label>
              <select
                value={formData.category}
                onChange={(e) => handleInputChange('category', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  errors.category ? 'border-red-500' : 'border-gray-300'
                }`}
              >
                <option value="">Sélectionner une catégorie</option>
                {categoryOptions[formData.type as keyof typeof categoryOptions]?.map(category => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
              {errors.category && <p className="text-red-500 text-sm mt-1">{errors.category}</p>}
            </div>
          </div>

          {/* Amount and Frequency */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Montant (Ariary) *
              </label>
              <input
                type="number"
                value={formData.amount}
                onChange={(e) => handleInputChange('amount', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  errors.amount ? 'border-red-500' : 'border-gray-300'
                }`}
                placeholder="0"
                min="0"
                step="100"
              />
              {errors.amount && <p className="text-red-500 text-sm mt-1">{errors.amount}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Mois
              </label>
              <select
                value={formData.month}
                onChange={(e) => handleInputChange('month', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {monthOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Beneficiary Type and Beneficiary */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Type de bénéficiaire
              </label>
              <select
                value={formData.beneficiaryType}
                onChange={(e) => handleInputChange('beneficiaryType', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="teacher">Enseignant</option>
                <option value="student">Élève</option>
                <option value="staff">Personnel</option>
                <option value="other">Autre</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Bénéficiaire *
              </label>
              {(formData.beneficiaryType === 'student' || formData.beneficiaryType === 'teacher') ? (
                <select
                  value={formData.beneficiary}
                  onChange={(e) => handleInputChange('beneficiary', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                    errors.beneficiary ? 'border-red-500' : 'border-gray-300'
                  }`}
                  disabled={studentsLoading || teachersLoading}
                >
                  <option value="">
                    {studentsLoading || teachersLoading 
                      ? 'Chargement...' 
                      : `Sélectionner un ${formData.beneficiaryType === 'student' ? 'élève' : 'enseignant'}`
                    }
                  </option>
                  {getBeneficiaryOptions().map(option => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  type="text"
                  value={formData.beneficiary}
                  onChange={(e) => handleInputChange('beneficiary', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                    errors.beneficiary ? 'border-red-500' : 'border-gray-300'
                  }`}
                  placeholder="Nom du bénéficiaire"
                />
              )}
              {errors.beneficiary && <p className="text-red-500 text-sm mt-1">{errors.beneficiary}</p>}
            </div>
          </div>

          {/* Due Date and Status */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Date d'échéance *
              </label>
              <input
                type="date"
                value={formData.dueDate}
                onChange={(e) => handleInputChange('dueDate', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  errors.dueDate ? 'border-red-500' : 'border-gray-300'
                }`}
              />
              {errors.dueDate && <p className="text-red-500 text-sm mt-1">{errors.dueDate}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Statut
              </label>
              <select
                value={formData.status}
                onChange={(e) => handleInputChange('status', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {statusOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Description *
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              rows={3}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                errors.description ? 'border-red-500' : 'border-gray-300'
              }`}
              placeholder="Description détaillée de l'élément financier"
            />
            {errors.description && <p className="text-red-500 text-sm mt-1">{errors.description}</p>}
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-3 pt-6 border-t">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
            >
              <Save className="w-4 h-4" />
              <span>{item ? 'Modifier' : 'Créer'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}