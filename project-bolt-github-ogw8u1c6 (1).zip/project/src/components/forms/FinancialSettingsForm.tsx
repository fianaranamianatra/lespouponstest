import React, { useState, useEffect } from 'react';
import { Settings, Percent, DollarSign, Calendar, User, FileText, Save, RotateCcw } from 'lucide-react';
import { FinancialSettingsService } from '../../lib/services/financialSettingsService';
import type { FinancialSetting } from '../../lib/firebase/collections';
import { useAuth } from '../../hooks/useAuth';

interface FinancialSettingsFormProps {
  onSubmit: (data: any) => void;
  onCancel: () => void;
  initialData?: FinancialSetting;
}

export function FinancialSettingsForm({ onSubmit, onCancel, initialData }: FinancialSettingsFormProps) {
  const { profile } = useAuth();
  
  const [formData, setFormData] = useState({
    // CNAPS
    cnapsEmployeeRate: initialData?.cnaps?.employeeRate || 1.0,
    cnapsEmployerRate: initialData?.cnaps?.employerRate || 13.0,
    cnapsCeiling: initialData?.cnaps?.ceiling || 8000000,
    cnapsIsActive: initialData?.cnaps?.isActive !== undefined ? initialData.cnaps.isActive : true,
    
    // OSTIE
    ostieEmployeeRate: initialData?.ostie?.employeeRate || 1.0,
    ostieEmployerRate: initialData?.ostie?.employerRate || 5.0,
    ostieCeiling: initialData?.ostie?.ceiling || 5000000,
    ostieIsActive: initialData?.ostie?.isActive !== undefined ? initialData.ostie.isActive : true,
    
    // Métadonnées
    effectiveDate: initialData?.effectiveDate || new Date().toISOString().split('T')[0],
    notes: initialData?.notes || ''
  });

  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [previewSalary, setPreviewSalary] = useState(1500000); // Salaire d'exemple pour la prévisualisation

  // Calculer la prévisualisation des cotisations
  const calculatePreview = () => {
    const settings: FinancialSetting = {
      cnaps: {
        employeeRate: formData.cnapsEmployeeRate,
        employerRate: formData.cnapsEmployerRate,
        ceiling: formData.cnapsCeiling,
        isActive: formData.cnapsIsActive
      },
      ostie: {
        employeeRate: formData.ostieEmployeeRate,
        employerRate: formData.ostieEmployerRate,
        ceiling: formData.ostieCeiling,
        isActive: formData.ostieIsActive
      },
      lastUpdatedBy: profile?.firstName + ' ' + profile?.lastName || 'Utilisateur',
      effectiveDate: formData.effectiveDate,
      notes: formData.notes
    };

    return FinancialSettingsService.calculateContributions(previewSalary, settings);
  };

  const preview = calculatePreview();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    const newErrors: { [key: string]: string } = {};
    
    // Validation des taux
    if (formData.cnapsEmployeeRate < 0 || formData.cnapsEmployeeRate > 100) {
      newErrors.cnapsEmployeeRate = 'Le taux doit être entre 0 et 100%';
    }
    if (formData.cnapsEmployerRate < 0 || formData.cnapsEmployerRate > 100) {
      newErrors.cnapsEmployerRate = 'Le taux doit être entre 0 et 100%';
    }
    if (formData.ostieEmployeeRate < 0 || formData.ostieEmployeeRate > 100) {
      newErrors.ostieEmployeeRate = 'Le taux doit être entre 0 et 100%';
    }
    if (formData.ostieEmployerRate < 0 || formData.ostieEmployerRate > 100) {
      newErrors.ostieEmployerRate = 'Le taux doit être entre 0 et 100%';
    }
    
    // Validation des plafonds
    if (formData.cnapsCeiling < 0) {
      newErrors.cnapsCeiling = 'Le plafond doit être positif';
    }
    if (formData.ostieCeiling < 0) {
      newErrors.ostieCeiling = 'Le plafond doit être positif';
    }
    
    // Validation de la date
    if (!formData.effectiveDate) {
      newErrors.effectiveDate = 'La date d\'entrée en vigueur est requise';
    }
    
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    
    setIsSubmitting(true);
    setErrors({});

    try {
      // Préparer les données pour Firebase
      const settingsData = {
        cnaps: {
          employeeRate: formData.cnapsEmployeeRate,
          employerRate: formData.cnapsEmployerRate,
          ceiling: formData.cnapsCeiling,
          isActive: formData.cnapsIsActive
        },
        ostie: {
          employeeRate: formData.ostieEmployeeRate,
          employerRate: formData.ostieEmployerRate,
          ceiling: formData.ostieCeiling,
          isActive: formData.ostieIsActive
        },
        lastUpdatedBy: profile?.firstName + ' ' + profile?.lastName || 'Utilisateur',
        effectiveDate: formData.effectiveDate,
        notes: formData.notes
      };
      
      await onSubmit(settingsData);
    } catch (error: any) {
      setErrors({ submit: error.message || 'Erreur lors de la sauvegarde' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else if (type === 'number') {
      setFormData(prev => ({ ...prev, [name]: parseFloat(value) || 0 }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
    
    // Effacer l'erreur du champ modifié
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleReset = () => {
    if (confirm('Voulez-vous vraiment réinitialiser aux valeurs par défaut ?')) {
      const defaultSettings = FinancialSettingsService.getDefaultSettings();
      setFormData({
        cnapsEmployeeRate: defaultSettings.cnaps.employeeRate,
        cnapsEmployerRate: defaultSettings.cnaps.employerRate,
        cnapsCeiling: defaultSettings.cnaps.ceiling,
        cnapsIsActive: defaultSettings.cnaps.isActive,
        ostieEmployeeRate: defaultSettings.ostie.employeeRate,
        ostieEmployerRate: defaultSettings.ostie.employerRate,
        ostieCeiling: defaultSettings.ostie.ceiling,
        ostieIsActive: defaultSettings.ostie.isActive,
        effectiveDate: defaultSettings.effectiveDate,
        notes: defaultSettings.notes || ''
      });
      setErrors({});
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {errors.submit && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-600 text-sm">{errors.submit}</p>
        </div>
      )}

      {/* En-tête avec informations importantes */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <div className="flex items-start space-x-3">
          <Settings className="w-6 h-6 text-blue-600 mt-1" />
          <div>
            <h3 className="font-medium text-blue-800 mb-2">Configuration des Cotisations Sociales</h3>
            <p className="text-sm text-blue-700 mb-3">
              Configurez les taux et plafonds pour les cotisations CNAPS et OSTIE selon la réglementation malgache en vigueur.
            </p>
            <div className="text-xs text-blue-600 space-y-1">
              <p>• <strong>CNAPS</strong> : Caisse Nationale de Prévoyance Sociale (retraite, prestations familiales)</p>
              <p>• <strong>OSTIE</strong> : Organisme Sanitaire Tananarivien Inter-Entreprises (santé)</p>
            </div>
          </div>
        </div>
      </div>

      {/* Paramètres CNAPS */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-900">CNAPS</h3>
              <p className="text-sm text-gray-600">Caisse Nationale de Prévoyance Sociale</p>
            </div>
          </div>
          <div className="flex items-center">
            <input
              type="checkbox"
              id="cnapsIsActive"
              name="cnapsIsActive"
              checked={formData.cnapsIsActive}
              onChange={handleChange}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
            />
            <label htmlFor="cnapsIsActive" className="ml-2 block text-sm text-gray-900">
              Activer CNAPS
            </label>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Percent className="w-4 h-4 inline mr-2" />
              Taux Salarié (%)
            </label>
            <input
              type="number"
              name="cnapsEmployeeRate"
              value={formData.cnapsEmployeeRate}
              onChange={handleChange}
              min="0"
              max="100"
              step="0.1"
              disabled={!formData.cnapsIsActive}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                errors.cnapsEmployeeRate ? 'border-red-300' : 'border-gray-300'
              } ${!formData.cnapsIsActive ? 'bg-gray-50' : ''}`}
            />
            {errors.cnapsEmployeeRate && (
              <p className="text-red-600 text-xs mt-1">{errors.cnapsEmployeeRate}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Percent className="w-4 h-4 inline mr-2" />
              Taux Employeur (%)
            </label>
            <input
              type="number"
              name="cnapsEmployerRate"
              value={formData.cnapsEmployerRate}
              onChange={handleChange}
              min="0"
              max="100"
              step="0.1"
              disabled={!formData.cnapsIsActive}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                errors.cnapsEmployerRate ? 'border-red-300' : 'border-gray-300'
              } ${!formData.cnapsIsActive ? 'bg-gray-50' : ''}`}
            />
            {errors.cnapsEmployerRate && (
              <p className="text-red-600 text-xs mt-1">{errors.cnapsEmployerRate}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <DollarSign className="w-4 h-4 inline mr-2" />
              Plafond (Ariary)
            </label>
            <input
              type="number"
              name="cnapsCeiling"
              value={formData.cnapsCeiling}
              onChange={handleChange}
              min="0"
              step="100000"
              disabled={!formData.cnapsIsActive}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                errors.cnapsCeiling ? 'border-red-300' : 'border-gray-300'
              } ${!formData.cnapsIsActive ? 'bg-gray-50' : ''}`}
            />
            {errors.cnapsCeiling && (
              <p className="text-red-600 text-xs mt-1">{errors.cnapsCeiling}</p>
            )}
          </div>
        </div>
      </div>

      {/* Paramètres OSTIE */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-900">OSTIE</h3>
              <p className="text-sm text-gray-600">Organisme Sanitaire Tananarivien Inter-Entreprises</p>
            </div>
          </div>
          <div className="flex items-center">
            <input
              type="checkbox"
              id="ostieIsActive"
              name="ostieIsActive"
              checked={formData.ostieIsActive}
              onChange={handleChange}
              className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
            />
            <label htmlFor="ostieIsActive" className="ml-2 block text-sm text-gray-900">
              Activer OSTIE
            </label>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Percent className="w-4 h-4 inline mr-2" />
              Taux Salarié (%)
            </label>
            <input
              type="number"
              name="ostieEmployeeRate"
              value={formData.ostieEmployeeRate}
              onChange={handleChange}
              min="0"
              max="100"
              step="0.1"
              disabled={!formData.ostieIsActive}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent ${
                errors.ostieEmployeeRate ? 'border-red-300' : 'border-gray-300'
              } ${!formData.ostieIsActive ? 'bg-gray-50' : ''}`}
            />
            {errors.ostieEmployeeRate && (
              <p className="text-red-600 text-xs mt-1">{errors.ostieEmployeeRate}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Percent className="w-4 h-4 inline mr-2" />
              Taux Employeur (%)
            </label>
            <input
              type="number"
              name="ostieEmployerRate"
              value={formData.ostieEmployerRate}
              onChange={handleChange}
              min="0"
              max="100"
              step="0.1"
              disabled={!formData.ostieIsActive}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent ${
                errors.ostieEmployerRate ? 'border-red-300' : 'border-gray-300'
              } ${!formData.ostieIsActive ? 'bg-gray-50' : ''}`}
            />
            {errors.ostieEmployerRate && (
              <p className="text-red-600 text-xs mt-1">{errors.ostieEmployerRate}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <DollarSign className="w-4 h-4 inline mr-2" />
              Plafond (Ariary)
            </label>
            <input
              type="number"
              name="ostieCeiling"
              value={formData.ostieCeiling}
              onChange={handleChange}
              min="0"
              step="100000"
              disabled={!formData.ostieIsActive}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent ${
                errors.ostieCeiling ? 'border-red-300' : 'border-gray-300'
              } ${!formData.ostieIsActive ? 'bg-gray-50' : ''}`}
            />
            {errors.ostieCeiling && (
              <p className="text-red-600 text-xs mt-1">{errors.ostieCeiling}</p>
            )}
          </div>
        </div>
      </div>

      {/* Métadonnées */}
      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Informations Complémentaires</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Calendar className="w-4 h-4 inline mr-2" />
              Date d'entrée en vigueur
            </label>
            <input
              type="date"
              name="effectiveDate"
              value={formData.effectiveDate}
              onChange={handleChange}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                errors.effectiveDate ? 'border-red-300' : 'border-gray-300'
              }`}
            />
            {errors.effectiveDate && (
              <p className="text-red-600 text-xs mt-1">{errors.effectiveDate}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <User className="w-4 h-4 inline mr-2" />
              Modifié par
            </label>
            <input
              type="text"
              value={profile?.firstName + ' ' + profile?.lastName || 'Utilisateur'}
              disabled
              className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <FileText className="w-4 h-4 inline mr-2" />
              Notes et commentaires
            </label>
            <textarea
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Notes sur les paramètres, références réglementaires, etc."
            />
          </div>
        </div>
      </div>

      {/* Prévisualisation des calculs */}
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-gray-900">Prévisualisation des Calculs</h3>
          <div className="flex items-center space-x-2">
            <label className="text-sm font-medium text-gray-700">Salaire d'exemple:</label>
            <input
              type="number"
              value={previewSalary}
              onChange={(e) => setPreviewSalary(parseFloat(e.target.value) || 0)}
              min="0"
              step="100000"
              className="w-32 px-2 py-1 border border-gray-300 rounded text-sm"
            />
            <span className="text-sm text-gray-500">Ar</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* CNAPS */}
          <div className="bg-blue-50 rounded-lg p-4">
            <h4 className="font-medium text-blue-800 mb-3">CNAPS</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Part salariale ({formData.cnapsEmployeeRate}%):</span>
                <span className="font-medium">{preview.cnaps.employee.toLocaleString()} Ar</span>
              </div>
              <div className="flex justify-between">
                <span>Part patronale ({formData.cnapsEmployerRate}%):</span>
                <span className="font-medium">{preview.cnaps.employer.toLocaleString()} Ar</span>
              </div>
              <div className="flex justify-between border-t border-blue-200 pt-2 font-bold">
                <span>Total CNAPS:</span>
                <span>{preview.cnaps.total.toLocaleString()} Ar</span>
              </div>
            </div>
          </div>

          {/* OSTIE */}
          <div className="bg-green-50 rounded-lg p-4">
            <h4 className="font-medium text-green-800 mb-3">OSTIE</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Part salariale ({formData.ostieEmployeeRate}%):</span>
                <span className="font-medium">{preview.ostie.employee.toLocaleString()} Ar</span>
              </div>
              <div className="flex justify-between">
                <span>Part patronale ({formData.ostieEmployerRate}%):</span>
                <span className="font-medium">{preview.ostie.employer.toLocaleString()} Ar</span>
              </div>
              <div className="flex justify-between border-t border-green-200 pt-2 font-bold">
                <span>Total OSTIE:</span>
                <span>{preview.ostie.total.toLocaleString()} Ar</span>
              </div>
            </div>
          </div>
        </div>

        {/* Résumé final */}
        <div className="mt-6 bg-white rounded-lg p-4 border border-gray-200">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
            <div>
              <p className="text-sm text-gray-600">Salaire Brut</p>
              <p className="text-xl font-bold text-gray-900">{previewSalary.toLocaleString()} Ar</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Cotisations Salarié</p>
              <p className="text-xl font-bold text-red-600">-{preview.totalEmployee.toLocaleString()} Ar</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Cotisations Employeur</p>
              <p className="text-xl font-bold text-orange-600">+{preview.totalEmployer.toLocaleString()} Ar</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Salaire Net</p>
              <p className="text-xl font-bold text-green-600">{preview.netSalary.toLocaleString()} Ar</p>
            </div>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex justify-between pt-6 border-t border-gray-200">
        <button
          type="button"
          onClick={handleReset}
          className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Réinitialiser
        </button>
        
        <div className="flex space-x-3">
          <button
            type="button"
            onClick={onCancel}
            disabled={isSubmitting}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
          >
            Annuler
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
          >
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                Sauvegarde...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Sauvegarder les Paramètres
              </>
            )}
          </button>
        </div>
      </div>
    </form>
  );
}