import React, { useState, useRef } from 'react';
import { Upload, X, FileText, AlertTriangle, CheckCircle } from 'lucide-react';

interface CSVFileUploaderProps {
  onFileLoaded: (data: string) => void;
  onError: (error: string) => void;
  maxSize?: number; // en octets
}

export function CSVFileUploader({ onFileLoaded, onError, maxSize = 5 * 1024 * 1024 }: CSVFileUploaderProps) {
  const [dragOver, setDragOver] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [fileSize, setFileSize] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateFile = (file: File): boolean => {
    // Vérifier le type de fichier
    if (!file.name.endsWith('.csv')) {
      setError('Le fichier doit être au format CSV (.csv)');
      onError('Le fichier doit être au format CSV (.csv)');
      return false;
    }

    // Vérifier la taille du fichier
    if (file.size > maxSize) {
      setError(`La taille du fichier ne doit pas dépasser ${maxSize / 1024 / 1024} Mo`);
      onError(`La taille du fichier ne doit pas dépasser ${maxSize / 1024 / 1024} Mo`);
      return false;
    }

    return true;
  };

  const handleFileSelect = (file: File) => {
    if (!validateFile(file)) return;

    setFileName(file.name);
    setFileSize(file.size);
    setError(null);

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const csvContent = e.target?.result as string;
        onFileLoaded(csvContent);
      } catch (err) {
        const errorMessage = 'Erreur lors de la lecture du fichier CSV';
        setError(errorMessage);
        onError(errorMessage);
      }
    };

    reader.onerror = () => {
      const errorMessage = 'Erreur lors de la lecture du fichier';
      setError(errorMessage);
      onError(errorMessage);
    };

    reader.readAsText(file);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(false);
    
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(false);
  };

  const handleRemoveFile = () => {
    setFileName(null);
    setFileSize(null);
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' octets';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' Ko';
    return (bytes / (1024 * 1024)).toFixed(1) + ' Mo';
  };

  return (
    <div className="w-full">
      <input
        type="file"
        ref={fileInputRef}
        accept=".csv"
        onChange={handleInputChange}
        className="hidden"
      />

      {!fileName ? (
        <div
          className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
            dragOver ? 'border-blue-400 bg-blue-50' : 'border-gray-300 hover:border-gray-400'
          }`}
          onClick={() => fileInputRef.current?.click()}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
        >
          <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
          <p className="text-sm font-medium text-gray-900 mb-1">
            Cliquez pour sélectionner ou glissez-déposez
          </p>
          <p className="text-xs text-gray-500">
            Uniquement les fichiers CSV (.csv)
          </p>
          <p className="text-xs text-gray-500 mt-1">
            Taille maximale: {maxSize / 1024 / 1024} Mo
          </p>
        </div>
      ) : (
        <div className={`border rounded-lg p-4 ${error ? 'border-red-300 bg-red-50' : 'border-green-300 bg-green-50'}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                error ? 'bg-red-100' : 'bg-green-100'
              }`}>
                {error ? (
                  <AlertTriangle className="w-5 h-5 text-red-600" />
                ) : (
                  <FileText className="w-5 h-5 text-green-600" />
                )}
              </div>
              <div>
                <p className="font-medium text-gray-900">{fileName}</p>
                <p className="text-xs text-gray-500">{fileSize && formatFileSize(fileSize)}</p>
              </div>
            </div>
            <button
              onClick={handleRemoveFile}
              className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          {error && (
            <div className="mt-2 text-sm text-red-600">
              <AlertTriangle className="w-4 h-4 inline mr-1" />
              {error}
            </div>
          )}
          {!error && (
            <div className="mt-2 text-sm text-green-600">
              <CheckCircle className="w-4 h-4 inline mr-1" />
              Fichier prêt à être importé
            </div>
          )}
        </div>
      )}
    </div>
  );
}