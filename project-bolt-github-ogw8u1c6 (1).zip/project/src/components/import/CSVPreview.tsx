import React from 'react';
import { AlertTriangle, CheckCircle, Info } from 'lucide-react';

interface CSVPreviewProps {
  headers: string[];
  data: Record<string, string>[];
  validationResult: {
    isValid: boolean;
    errors: string[];
    warnings: string[];
  };
  onImport: () => void;
  onCancel: () => void;
  isImporting: boolean;
}

export function CSVPreview({ 
  headers, 
  data, 
  validationResult, 
  onImport, 
  onCancel,
  isImporting
}: CSVPreviewProps) {
  const { isValid, errors, warnings } = validationResult;
  
  // Limiter le nombre de lignes affichées dans l'aperçu
  const previewData = data.slice(0, 5);
  const hasMoreRows = data.length > 5;
  
  return (
    <div className="space-y-6">
      {/* Résumé de l'importation */}
      <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
        <h3 className="font-medium text-gray-900 mb-2">Résumé de l'importation</h3>
        <div className="space-y-1 text-sm">
          <p><span className="font-medium">Nombre total d'enregistrements:</span> {data.length}</p>
          <p><span className="font-medium">Colonnes détectées:</span> {headers.length}</p>
          <p className="flex items-center">
            <span className="font-medium mr-2">Statut de validation:</span>
            {isValid ? (
              <span className="text-green-600 flex items-center">
                <CheckCircle className="w-4 h-4 mr-1" />
                Valide
              </span>
            ) : (
              <span className="text-red-600 flex items-center">
                <AlertTriangle className="w-4 h-4 mr-1" />
                Erreurs détectées
              </span>
            )}
          </p>
        </div>
      </div>
      
      {/* Messages d'erreur et d'avertissement */}
      {(errors.length > 0 || warnings.length > 0) && (
        <div className="space-y-3">
          {errors.length > 0 && (
            <div className="bg-red-50 rounded-lg p-4 border border-red-200">
              <h3 className="font-medium text-red-800 mb-2 flex items-center">
                <AlertTriangle className="w-4 h-4 mr-2" />
                Erreurs ({errors.length})
              </h3>
              <ul className="list-disc pl-5 space-y-1 text-sm text-red-700">
                {errors.map((error, index) => (
                  <li key={index}>{error}</li>
                ))}
              </ul>
            </div>
          )}
          
          {warnings.length > 0 && (
            <div className="bg-yellow-50 rounded-lg p-4 border border-yellow-200">
              <h3 className="font-medium text-yellow-800 mb-2 flex items-center">
                <Info className="w-4 h-4 mr-2" />
                Avertissements ({warnings.length})
              </h3>
              <ul className="list-disc pl-5 space-y-1 text-sm text-yellow-700">
                {warnings.map((warning, index) => (
                  <li key={index}>{warning}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
      
      {/* Aperçu des données */}
      <div>
        <h3 className="font-medium text-gray-900 mb-2">Aperçu des données</h3>
        <div className="overflow-x-auto border border-gray-200 rounded-lg">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                {headers.map((header, index) => (
                  <th 
                    key={index}
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    {header}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {previewData.map((row, rowIndex) => (
                <tr key={rowIndex} className={rowIndex % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                  {headers.map((header, colIndex) => (
                    <td 
                      key={colIndex}
                      className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"
                    >
                      {row[header] || ''}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {hasMoreRows && (
          <p className="text-xs text-gray-500 mt-2">
            Affichage de 5 lignes sur {data.length}. Toutes les lignes seront importées.
          </p>
        )}
      </div>
      
      {/* Actions */}
      <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
        <button
          type="button"
          onClick={onCancel}
          disabled={isImporting}
          className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
        >
          Annuler
        </button>
        <button
          type="button"
          onClick={onImport}
          disabled={!isValid || isImporting}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
        >
          {isImporting ? (
            <>
              <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></span>
              Importation...
            </>
          ) : (
            'Importer les données'
          )}
        </button>
      </div>
    </div>
  );
}