import React from 'react';
import { Download, School } from 'lucide-react';

interface Bulletin {
  studentName: string;
  class: string;
  trimester: string;
  schoolYear: string;
  subjects: {
    name: string;
    n1: number;
    n2: number;
    exam: number;
    average: number;
    coefficient: number;
    weightedAverage: number;
    rank: number;
    appreciation: string;
    teacher: string;
  }[];
  totalCoefficient: number;
  totalWeightedAverage: number;
  generalAverage: number;
  absences: number;
  retards: number;
  mention: string;
  isPassing: boolean;
}

interface BulletinPDFProps {
  bulletin: Bulletin;
}

export function BulletinPDF({ bulletin }: BulletinPDFProps) {
  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      const content = document.getElementById('bulletin-content');
      if (content) {
        printWindow.document.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <title>Bulletin de Notes - ${bulletin.studentName}</title>
              <style>
                body { 
                  margin: 0; 
                  padding: 20px; 
                  font-family: Arial, sans-serif;
                  background: white;
                }
                .print-hidden { display: none !important; }
                
                /* Styles pour le bulletin */
                .bulletin-container {
                  max-width: 210mm;
                  margin: 0 auto;
                  padding: 20px;
                  border: 1px solid #000;
                }
                .school-header {
                  text-align: center;
                  margin-bottom: 20px;
                }
                .school-name {
                  font-size: 18px;
                  font-weight: bold;
                  margin-bottom: 5px;
                }
                .school-location {
                  font-size: 14px;
                  margin-bottom: 5px;
                }
                .bulletin-title {
                  text-align: center;
                  font-size: 16px;
                  font-weight: bold;
                  margin: 15px 0;
                }
                .student-info {
                  margin-bottom: 15px;
                }
                .student-info p {
                  margin: 5px 0;
                }
                table {
                  width: 100%;
                  border-collapse: collapse;
                }
                th, td {
                  border: 1px solid #000;
                  padding: 5px;
                  text-align: center;
                }
                th {
                  background-color: #f0f0f0;
                }
                .subject-name {
                  text-align: left;
                }
                .total-row {
                  font-weight: bold;
                }
                .average-row {
                  font-weight: bold;
                  background-color: #e6f0ff;
                }
                .evaluation-grid {
                  display: grid;
                  grid-template-columns: repeat(3, 1fr);
                  gap: 10px;
                  margin: 20px 0;
                }
                .evaluation-box {
                  border: 1px solid #000;
                  padding: 10px;
                }
                .evaluation-box h4 {
                  text-align: center;
                  margin: 0 0 10px 0;
                }
                .evaluation-item {
                  display: flex;
                  align-items: center;
                  margin: 5px 0;
                }
                .checkbox {
                  width: 15px;
                  height: 15px;
                  border: 1px solid #000;
                  margin-right: 10px;
                  display: inline-block;
                }
                .signature-section {
                  display: flex;
                  justify-content: space-between;
                  margin-top: 30px;
                }
                .signature-box {
                  width: 45%;
                }
                .signature-line {
                  border-top: 1px solid #000;
                  margin-top: 50px;
                }
                .date-location {
                  text-align: right;
                  margin-top: 20px;
                }
              </style>
            </head>
            <body>
              ${content.outerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.print();
      }
    }
  };

  // Déterminer les cases à cocher pour les mentions
  const getMentionCheckbox = (mentionType: string) => {
    return bulletin.mention === mentionType ? '☑' : '☐';
  };

  return (
    <div>
      <div id="bulletin-content" className="bg-white p-8 max-w-4xl mx-auto">
        {/* En-tête */}
        <div className="text-center mb-6">
          <h1 className="text-xl font-bold">École LES POUPONS</h1>
          <p className="text-sm">MADAGASCAR</p>
          <p className="text-sm">Préscolaire - Primaire - Secondaire</p>
          <p className="text-sm">Tél: +261 32 XX XX XX / 33 XX XX XX</p>
          <div className="text-right text-sm">
            <p>Année scolaire: {bulletin.schoolYear}</p>
          </div>
        </div>

        {/* Titre du bulletin */}
        <div className="text-center mb-6">
          <h2 className="text-lg font-bold">BULLETIN DE NOTES</h2>
          <p className="font-medium">{bulletin.trimester}</p>
        </div>

        {/* Informations de l'élève */}
        <div className="mb-6">
          <p><strong>Nom et prénom(s):</strong> {bulletin.studentName}</p>
          <p><strong>Classe:</strong> {bulletin.class || ''}</p>
          <p><strong>Date de naissance:</strong> {/* À remplir avec les données réelles */}</p>
          <p><strong>Passant:</strong> {bulletin.isPassing ? 'Oui' : 'Non'}</p>
        </div>

        {/* Tableau des notes */}
        <table className="w-full border-collapse border border-gray-800 mb-6">
          <thead>
            <tr className="bg-gray-100">
              <th className="border border-gray-800 px-2 py-1 text-left">Matières</th>
              <th className="border border-gray-800 px-2 py-1">N1</th>
              <th className="border border-gray-800 px-2 py-1">N2</th>
              <th className="border border-gray-800 px-2 py-1">Exam</th>
              <th className="border border-gray-800 px-2 py-1">Moy/20</th>
              <th className="border border-gray-800 px-2 py-1">Coeff</th>
              <th className="border border-gray-800 px-2 py-1">Moy. Coeff</th>
              <th className="border border-gray-800 px-2 py-1">Rang</th>
              <th className="border border-gray-800 px-2 py-1 text-left">Appréciations</th>
              <th className="border border-gray-800 px-2 py-1 text-left">Enseignants des matières</th>
            </tr>
          </thead>
          <tbody>
            {bulletin.subjects.map((subject, index) => (
              <tr key={index}>
                <td className="border border-gray-800 px-2 py-1 text-left font-medium">{subject.name}</td>
                <td className="border border-gray-800 px-2 py-1">{subject.n1}</td>
                <td className="border border-gray-800 px-2 py-1">{subject.n2}</td>
                <td className="border border-gray-800 px-2 py-1">{subject.exam}</td>
                <td className="border border-gray-800 px-2 py-1 font-medium">{subject.average.toFixed(2)}</td>
                <td className="border border-gray-800 px-2 py-1">{subject.coefficient}</td>
                <td className="border border-gray-800 px-2 py-1 font-medium">{subject.weightedAverage.toFixed(2)}</td>
                <td className="border border-gray-800 px-2 py-1">{subject.rank}</td>
                <td className="border border-gray-800 px-2 py-1 text-left">{subject.appreciation}</td>
                <td className="border border-gray-800 px-2 py-1 text-left">{subject.teacher}</td>
              </tr>
            ))}
            <tr className="bg-gray-100 font-bold">
              <td className="border border-gray-800 px-2 py-1">TOTAL</td>
              <td className="border border-gray-800 px-2 py-1" colSpan={4}></td>
              <td className="border border-gray-800 px-2 py-1">{bulletin.totalCoefficient}</td>
              <td className="border border-gray-800 px-2 py-1">{bulletin.totalWeightedAverage.toFixed(2)}</td>
              <td className="border border-gray-800 px-2 py-1" colSpan={3}></td>
            </tr>
          </tbody>
          <tfoot>
            <tr className="bg-blue-50">
              <td className="border border-gray-800 px-2 py-1 font-bold" colSpan={2}>MOYENNE</td>
              <td className="border border-gray-800 px-2 py-1 text-center font-bold" colSpan={8}>
                {bulletin.generalAverage.toFixed(2)}/20
              </td>
            </tr>
            <tr>
              <td className="border border-gray-800 px-2 py-1" colSpan={2}>Nombre de jours d'absence: {bulletin.absences}</td>
              <td className="border border-gray-800 px-2 py-1" colSpan={8}>Retards: {bulletin.retards}</td>
            </tr>
          </tfoot>
        </table>

        {/* Grille d'évaluation */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="border border-gray-800 p-2">
            <h4 className="text-center font-bold mb-2">FÉLICITATION</h4>
            <div className="flex items-center mb-1">
              <span className="inline-block w-5 h-5 border border-gray-800 mr-2 text-center">
                {getMentionCheckbox('FÉLICITATION')}
              </span>
              <span>FÉLICITATION</span>
            </div>
            <div className="flex items-center mb-1">
              <span className="inline-block w-5 h-5 border border-gray-800 mr-2 text-center">
                {getMentionCheckbox('TABLEAU D\'HONNEUR')}
              </span>
              <span>TABLEAU D'HONNEUR</span>
            </div>
            <div className="flex items-center">
              <span className="inline-block w-5 h-5 border border-gray-800 mr-2 text-center">
                {getMentionCheckbox('BIEN')}
              </span>
              <span>BIEN</span>
            </div>
          </div>
          
          <div className="border border-gray-800 p-2">
            <h4 className="text-center font-bold mb-2">ASSEZ BIEN</h4>
            <div className="flex items-center mb-1">
              <span className="inline-block w-5 h-5 border border-gray-800 mr-2 text-center">
                {getMentionCheckbox('ASSEZ BIEN')}
              </span>
              <span>ASSEZ BIEN</span>
            </div>
            <div className="flex items-center mb-1">
              <span className="inline-block w-5 h-5 border border-gray-800 mr-2 text-center">
                {getMentionCheckbox('PASSABLE')}
              </span>
              <span>PASSABLE</span>
            </div>
            <div className="flex items-center">
              <span className="inline-block w-5 h-5 border border-gray-800 mr-2 text-center">
                {getMentionCheckbox('INSUFFISANT')}
              </span>
              <span>INSUFFISANT</span>
            </div>
          </div>
          
          <div className="border border-gray-800 p-2">
            <h4 className="text-center font-bold mb-2">FAIBLE</h4>
            <div className="flex items-center mb-1">
              <span className="inline-block w-5 h-5 border border-gray-800 mr-2 text-center">
                {getMentionCheckbox('FAIBLE')}
              </span>
              <span>FAIBLE</span>
            </div>
            <div className="flex items-center mb-1">
              <span className="inline-block w-5 h-5 border border-gray-800 mr-2 text-center">
                {getMentionCheckbox('AVERTISSEMENT EN TRAVAIL')}
              </span>
              <span>AVERTISSEMENT EN TRAVAIL</span>
            </div>
            <div className="flex items-center">
              <span className="inline-block w-5 h-5 border border-gray-800 mr-2 text-center">
                {getMentionCheckbox('AVERTISSEMENT EN CONDUITE')}
              </span>
              <span>AVERTISSEMENT EN CONDUITE</span>
            </div>
          </div>
        </div>

        {/* Signatures */}
        <div className="flex justify-between mt-12">
          <div className="w-1/3 text-center">
            <p className="mb-16">Les Parents</p>
            <div className="border-t border-gray-800"></div>
          </div>
          
          <div className="w-1/3 text-center">
            <p className="text-right mb-4">Antananarivo le, {new Date().toLocaleDateString('fr-FR')}</p>
            <p className="mb-16">La Direction</p>
            <div className="border-t border-gray-800"></div>
          </div>
        </div>
      </div>

      {/* Bouton d'impression (masqué à l'impression) */}
      <div className="mt-6 text-center print:hidden">
        <button
          onClick={handlePrint}
          className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
        >
          <Download className="w-5 h-5 mr-2" />
          Imprimer le bulletin
        </button>
      </div>
    </div>
  );
}