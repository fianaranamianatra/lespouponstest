import React, { useState } from 'react';
import { Database, Trash2, RefreshCw, AlertTriangle, CheckCircle } from 'lucide-react';
import { initializeExampleData, clearAllData } from '../../lib/firebase/initializeData';

export function DataInitializer() {
  const [loading, setLoading] = useState(false);
  const [clearing, setClearing] = useState(false);

  const handleInitializeData = async () => {
    if (confirm('⚠️ Voulez-vous initialiser les données d\'exemple ?\n\nCela ajoutera des données de test dans Firebase.')) {
      setLoading(true);
      try {
        await initializeExampleData();
      } catch (error) {
        console.error('Erreur:', error);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleClearData = async () => {
    if (confirm('⚠️ ATTENTION ! Voulez-vous vraiment supprimer TOUTES les données ?\n\nCette action est IRRÉVERSIBLE !')) {
      if (confirm('🚨 DERNIÈRE CONFIRMATION !\n\nToutes les données seront définitivement supprimées.\nÊtes-vous absolument sûr ?')) {
        setClearing(true);
        try {
          await clearAllData();
        } catch (error) {
          console.error('Erreur:', error);
        } finally {
          setClearing(false);
        }
      }
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
          <Database className="w-5 h-5 text-blue-600" />
        </div>
        <div>
          <h3 className="text-lg font-bold text-gray-900">Gestion des Données Firebase</h3>
          <p className="text-sm text-gray-600">Initialisez ou gérez les données d'exemple</p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Initialiser les données */}
        <div className="border border-green-200 rounded-lg p-4 bg-green-50">
          <div className="flex items-start space-x-3">
            <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
            <div className="flex-1">
              <h4 className="font-medium text-green-900 mb-2">Initialiser les données d'exemple</h4>
              <p className="text-sm text-green-700 mb-3">
                Ajoute des données de test réalistes pour toutes les fonctionnalités :
              </p>
              <ul className="text-xs text-green-600 space-y-1 mb-4">
                <li>• 8 élèves avec informations complètes</li>
                <li>• 5 enseignants avec matières assignées</li>
                <li>• 5 classes (CP à CM2)</li>
                <li>• 5 matières principales</li>
                <li>• Notes et évaluations</li>
                <li>• Données d'écolage et paiements</li>
                <li>• Emploi du temps</li>
                <li>• Plan hiérarchique</li>
                <li>• Communications et rapports</li>
              </ul>
              <button
                onClick={handleInitializeData}
                disabled={loading}
                className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Initialisation...
                  </>
                ) : (
                  <>
                    <Database className="w-4 h-4 mr-2" />
                    Initialiser les données
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Supprimer toutes les données */}
        <div className="border border-red-200 rounded-lg p-4 bg-red-50">
          <div className="flex items-start space-x-3">
            <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
            <div className="flex-1">
              <h4 className="font-medium text-red-900 mb-2">Supprimer toutes les données</h4>
              <p className="text-sm text-red-700 mb-3">
                ⚠️ <strong>ATTENTION :</strong> Cette action supprimera définitivement toutes les données de Firebase.
              </p>
              <button
                onClick={handleClearData}
                disabled={clearing}
                className="inline-flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50"
              >
                {clearing ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Suppression...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4 mr-2" />
                    Supprimer toutes les données
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="border border-blue-200 rounded-lg p-4 bg-blue-50">
          <h4 className="font-medium text-blue-900 mb-2">Instructions</h4>
          <div className="text-sm text-blue-700 space-y-1">
            <p>1. <strong>Première utilisation :</strong> Cliquez sur "Initialiser les données" pour ajouter des données d'exemple</p>
            <p>2. <strong>Test complet :</strong> Toutes les fonctionnalités seront immédiatement testables</p>
            <p>3. <strong>Réinitialisation :</strong> Supprimez tout puis réinitialisez pour repartir à zéro</p>
            <p>4. <strong>Production :</strong> Supprimez les données d'exemple avant la mise en production</p>
          </div>
        </div>
      </div>
    </div>
  );
}