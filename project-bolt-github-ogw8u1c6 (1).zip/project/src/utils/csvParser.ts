/**
 * Parse un fichier CSV en tableau d'objets
 * @param csvContent Contenu du fichier CSV sous forme de chaîne
 * @param delimiter Délimiteur utilisé dans le CSV (par défaut: virgule)
 * @returns Un objet contenant les en-têtes et les données
 */
export function parseCSV(csvContent: string, delimiter: string = ','): { 
  headers: string[]; 
  data: Record<string, string>[]; 
} {
  // Diviser le contenu en lignes
  const lines = csvContent.split(/\r\n|\n|\r/).filter(line => line.trim() !== '');
  
  if (lines.length === 0) {
    throw new Error('Le fichier CSV est vide');
  }
  
  // Extraire les en-têtes (première ligne)
  const headers = lines[0].split(delimiter).map(header => header.trim());
  
  // Extraire les données (lignes suivantes)
  const data = lines.slice(1).map(line => {
    const values = line.split(delimiter);
    const row: Record<string, string> = {};
    
    // Associer chaque valeur à son en-tête
    headers.forEach((header, index) => {
      row[header] = values[index]?.trim() || '';
    });
    
    return row;
  });
  
  return { headers, data };
}

/**
 * Valide les données CSV pour l'importation d'élèves
 * @param headers En-têtes du CSV
 * @param data Données du CSV
 * @returns Un objet contenant le résultat de la validation et les erreurs éventuelles
 */
export function validateStudentCSVData(
  headers: string[],
  data: Record<string, string>[]
): { 
  isValid: boolean; 
  errors: string[]; 
  warnings: string[]; 
} {
  const errors: string[] = [];
  const warnings: string[] = [];
  
  // Vérifier les en-têtes requis
  const requiredHeaders = ['Numéro', 'Nom et Prénoms'];
  const missingHeaders = requiredHeaders.filter(header => !headers.includes(header));
  
  if (missingHeaders.length > 0) {
    errors.push(`En-têtes manquants: ${missingHeaders.join(', ')}`);
  }
  
  // Vérifier les données
  data.forEach((row, index) => {
    const rowNumber = index + 2; // +2 car l'index commence à 0 et on a déjà compté la ligne d'en-tête
    
    // Vérifier les champs requis
    if (!row['Numéro']) {
      errors.push(`Ligne ${rowNumber}: Numéro manquant`);
    }
    
    if (!row['Nom et Prénoms']) {
      errors.push(`Ligne ${rowNumber}: Nom et Prénoms manquants`);
    } else if (row['Nom et Prénoms'].length < 3) {
      warnings.push(`Ligne ${rowNumber}: Nom et Prénoms trop courts (${row['Nom et Prénoms']})`);
    }
    
    if (!row['Contact']) {
      warnings.push(`Ligne ${rowNumber}: Contact manquant (optionnel)`);
    } else {
      // Vérifier le format du numéro de téléphone (format malgache)
      const phoneRegex = /^(\+261|0)(3[2-4]|32|33|34)\d{7}$/;
      if (!phoneRegex.test(row['Contact'].replace(/\s/g, ''))) {
        warnings.push(`Ligne ${rowNumber}: Format de contact invalide (${row['Contact']})`);
      }
    }
    
    // Vérifier la classe (optionnelle)
    if (!row['Classe']) {
      warnings.push(`Ligne ${rowNumber}: Classe manquante (optionnel)`);
    }
    
    // Vérifier les notes (si présentes)
    headers.forEach(header => {
      if (header.startsWith('Note') && row[header]) {
        const note = parseFloat(row[header]);
        if (isNaN(note)) {
          errors.push(`Ligne ${rowNumber}: La note "${row[header]}" pour ${header} n'est pas un nombre valide`);
        } else if (note < 0 || note > 20) {
          warnings.push(`Ligne ${rowNumber}: La note ${note} pour ${header} n'est pas dans la plage 0-20`);
        }
      }
    });
  });
  
  return {
    isValid: errors.length === 0,
    errors,
    warnings
  };
}

/**
 * Convertit les données CSV en format compatible avec l'application
 * @param data Données CSV parsées
 * @returns Données formatées pour l'application
 */
export function convertCSVToStudentData(data: Record<string, string>[]): any[] {
  return data.map(row => {
    // Extraire le nom et le prénom
    const fullName = row['Nom et Prénoms'] || '';
    const nameParts = fullName.split(' ');
    const lastName = nameParts[0] || '';
    const firstName = nameParts.slice(1).join(' ') || '';
    
    // Créer l'objet élève
    const student = {
      firstName,
      lastName,
      phone: row['Contact'] || '',
      class: row['Classe'] || 'TPSA', // Utiliser la classe du CSV ou la valeur par défaut
      // Laisser vide si non présent dans le CSV
      dateOfBirth: '',
      address: 'Antananarivo, Madagascar', // Adresse par défaut
      parentName: row['Parent/Tuteur'] || '',
      status: 'active' // Statut par défaut
    };
    
    // Ajouter les notes si présentes
    const grades: Record<string, number> = {};
    Object.keys(row).forEach(key => {
      if (key.startsWith('Note') && row[key]) {
        const note = parseFloat(row[key]);
        if (!isNaN(note)) {
          grades[key] = note;
        }
      }
    });
    
    return {
      ...student,
      grades
    };
  });
}