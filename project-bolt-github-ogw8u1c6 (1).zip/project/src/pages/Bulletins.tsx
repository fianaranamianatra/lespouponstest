import React, { useState, useEffect } from 'react';
import { Search, Plus, Filter, Download, Eye, Edit, Trash2, FileText } from 'lucide-react';
import { Modal } from '../components/Modal';
import { BulletinForm } from '../components/forms/BulletinForm';
import { BulletinPDF } from '../components/bulletins/BulletinPDF';
import { Avatar } from '../components/Avatar';
import { useFirebaseCollection } from '../hooks/useFirebaseCollection';
import { bulletinsService, studentsService, subjectsService, teachersService } from '../lib/firebase/firebaseService';

interface Bulletin {
  id?: string;
  studentId: string;
  studentName: string;
  class: string;
  trimester: 'PREMIER TRIMESTRE' | 'DEUXIEME TRIMESTRE' | 'TROISIEME TRIMESTRE';
  schoolYear: string;
  subjects: {
    name: string;
    n1: number;
    n2: number;
    exam: number;
    average: number;
    coefficient: number;
    weightedAverage: number;
    rank: number;
    appreciation: string;
    teacher: string;
  }[];
  totalCoefficient: number;
  totalWeightedAverage: number;
  generalAverage: number;
  absences: number;
  retards: number;
  mention: 'FÉLICITATION' | 'TABLEAU D\'HONNEUR' | 'BIEN' | 'ASSEZ BIEN' | 'PASSABLE' | 'INSUFFISANT' | 'FAIBLE' | 'AVERTISSEMENT EN TRAVAIL' | 'AVERTISSEMENT EN CONDUITE' | '';
  isPassing: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}

export function Bulletins() {
  const [searchTerm, setSearchTerm] = useState('');
  const [students, setStudents] = useState<any[]>([]);
  const [subjects, setSubjects] = useState<any[]>([]);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showPdfModal, setShowPdfModal] = useState(false);
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedTrimester, setSelectedTrimester] = useState('');
  const [selectedBulletin, setSelectedBulletin] = useState<Bulletin | null>(null);

  // Hook Firebase avec synchronisation temps réel
  const {
    data: bulletins,
    loading,
    error,
    creating,
    updating,
    deleting,
    create,
    update,
    remove
  } = useFirebaseCollection<Bulletin>(bulletinsService, true);

  // Charger les données liées (élèves, matières, enseignants)
  useEffect(() => {
    const fetchRelatedData = async () => {
      try {
        console.log('🔄 Chargement des données liées pour les bulletins...');
        
        // Récupérer les élèves
        const studentsData = await studentsService.getAll();
        setStudents(studentsData);
        console.log('✅ Élèves chargés:', studentsData.length);
        
        // Récupérer les matières
        const subjectsData = await subjectsService.getAll();
        setSubjects(subjectsData);
        console.log('✅ Matières chargées:', subjectsData.length);
        
        // Récupérer les enseignants
        const teachersData = await teachersService.getAll();
        setTeachers(teachersData);
        console.log('✅ Enseignants chargés:', teachersData.length);
      } catch (error) {
        console.error('❌ Erreur lors du chargement des données liées:', error);
      }
    };
    
    fetchRelatedData();
  }, []);

  const filteredBulletins = bulletins.filter(bulletin => {
    const matchesSearch = bulletin.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         bulletin.class.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClass = selectedClass === '' || bulletin.class === selectedClass;
    const matchesTrimester = selectedTrimester === '' || bulletin.trimester === selectedTrimester;
    return matchesSearch && matchesClass && matchesTrimester;
  });

  const classes = [...new Set(bulletins.map(b => b.class))];
  const trimesters = ['PREMIER TRIMESTRE', 'DEUXIEME TRIMESTRE', 'TROISIEME TRIMESTRE'];

  const handleAddBulletin = async (data: any) => {
    try {
      console.log('🚀 Ajout de bulletin - Données reçues:', data);
      
      // Vérifier que les matières sont bien définies
      if (!data.subjects || data.subjects.length === 0) {
        throw new Error('Aucune matière définie pour ce bulletin');
      }
      
      // Calculer les moyennes et totaux
      const totalCoefficient = data.subjects.reduce((sum: number, subject: any) => sum + subject.coefficient, 0);
      const totalWeightedAverage = data.subjects.reduce((sum: number, subject: any) => sum + subject.weightedAverage, 0);
      const generalAverage = totalCoefficient > 0 ? totalWeightedAverage / totalCoefficient : 0;
      
      // Déterminer la mention
      let mention = '';
      if (generalAverage >= 16) mention = 'FÉLICITATION';
      else if (generalAverage >= 14) mention = 'TABLEAU D\'HONNEUR';
      else if (generalAverage >= 12) mention = 'BIEN';
      else if (generalAverage >= 10) mention = 'ASSEZ BIEN';
      else if (generalAverage >= 8) mention = 'PASSABLE';
      else if (generalAverage >= 6) mention = 'INSUFFISANT';
      else mention = 'FAIBLE';
      
      // Préparer les données pour Firebase
      const bulletinData = {
        ...data,
        totalCoefficient,
        totalWeightedAverage,
        generalAverage,
        mention,
        isPassing: generalAverage >= 10
      };
      
      console.log('📝 Données formatées pour Firebase:', bulletinData);
      
      const bulletinId = await create(bulletinData);
      console.log('✅ Bulletin créé avec l\'ID:', bulletinId);
      
      setShowAddForm(false);
      
      // Message de succès
      alert('✅ Bulletin ajouté avec succès !');
      
    } catch (error: any) {
      console.error('❌ Erreur lors de l\'ajout du bulletin:', error);
      alert('❌ Erreur lors de l\'ajout du bulletin: ' + error.message);
    }
  };

  const handleEditBulletin = async (data: any) => {
    if (selectedBulletin?.id) {
      try {
        console.log('🔄 Modification de bulletin - Données:', data);
        
        // Recalculer les moyennes et totaux
        const totalCoefficient = data.subjects.reduce((sum: number, subject: any) => sum + subject.coefficient, 0);
        const totalWeightedAverage = data.subjects.reduce((sum: number, subject: any) => sum + subject.weightedAverage, 0);
        const generalAverage = totalCoefficient > 0 ? totalWeightedAverage / totalCoefficient : 0;
        
        // Redéterminer la mention
        let mention = '';
        if (generalAverage >= 16) mention = 'FÉLICITATION';
        else if (generalAverage >= 14) mention = 'TABLEAU D\'HONNEUR';
        else if (generalAverage >= 12) mention = 'BIEN';
        else if (generalAverage >= 10) mention = 'ASSEZ BIEN';
        else if (generalAverage >= 8) mention = 'PASSABLE';
        else if (generalAverage >= 6) mention = 'INSUFFISANT';
        else mention = 'FAIBLE';
        
        const updateData = {
          ...data,
          totalCoefficient,
          totalWeightedAverage,
          generalAverage,
          mention,
          isPassing: generalAverage >= 10
        };
        
        await update(selectedBulletin.id, updateData);
        console.log('✅ Bulletin modifié avec succès');
        
        setShowEditForm(false);
        setSelectedBulletin(null);
        
        alert('✅ Bulletin modifié avec succès !');
        
      } catch (error: any) {
        console.error('❌ Erreur lors de la modification:', error);
        alert('❌ Erreur lors de la modification: ' + error.message);
      }
    }
  };

  const handleDeleteBulletin = async (id: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce bulletin ?')) {
      try {
        console.log('🗑️ Suppression du bulletin ID:', id);
        await remove(id);
        console.log('✅ Bulletin supprimé avec succès');
        alert('✅ Bulletin supprimé avec succès !');
      } catch (error: any) {
        console.error('❌ Erreur lors de la suppression:', error);
        alert('❌ Erreur lors de la suppression: ' + error.message);
      }
    }
  };

  const handleViewBulletin = (bulletin: Bulletin) => {
    setSelectedBulletin(bulletin);
    setShowViewModal(true);
  };

  const handleEditClick = (bulletin: Bulletin) => {
    setSelectedBulletin(bulletin);
    setShowEditForm(true);
  };

  const handlePrintBulletin = (bulletin: Bulletin) => {
    setSelectedBulletin(bulletin);
    setShowPdfModal(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement des bulletins...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <p className="text-red-600">Erreur: {error}</p>
        <button 
          onClick={() => window.location.reload()} 
          className="mt-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
        >
          Réessayer
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Bulletins de Notes</h1>
          <p className="text-gray-600">Gérez les bulletins trimestriels des élèves</p>
        </div>
        
        <button
          onClick={() => {
            console.log('🔘 Ouverture du formulaire d\'ajout de bulletin');
            setShowAddForm(true);
          }}
          disabled={creating}
          className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
        >
          {creating ? (
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
          ) : (
            <Plus className="w-4 h-4 mr-2" />
          )}
          Créer un Bulletin
        </button>
      </div>

      {/* Filters and Search */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Rechercher par élève ou classe..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="flex gap-2">
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Toutes les classes</option>
              {classes.map(className => (
                <option key={className} value={className}>{className}</option>
              ))}
            </select>
            
            <select
              value={selectedTrimester}
              onChange={(e) => setSelectedTrimester(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Tous les trimestres</option>
              {trimesters.map(trimester => (
                <option key={trimester} value={trimester}>{trimester}</option>
              ))}
            </select>
            
            <button className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Filter className="w-4 h-4 mr-2" />
              Filtres
            </button>
          </div>
        </div>
      </div>

      {/* Bulletins List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        {bulletins.length === 0 ? (
          <div className="text-center py-12">
            <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun bulletin enregistré</h3>
            <p className="text-gray-500 mb-6">Commencez par créer votre premier bulletin de notes.</p>
            <button
              onClick={() => setShowAddForm(true)}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="w-4 h-4 mr-2" />
              Créer un Bulletin
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Élève</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Classe</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Trimestre</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Année Scolaire</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Moyenne Générale</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Mention</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredBulletins.map((bulletin) => (
                  <tr key={bulletin.id} className="hover:bg-gray-50 transition-colors">
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-3">
                        <Avatar 
                          firstName={bulletin.studentName?.split(' ')?.[0] || ''} 
                          lastName={bulletin.studentName?.split(' ')?.[1] || ''} 
                          size="sm" 
                          showPhoto={true}
                        />
                        <p className="font-medium text-gray-900">{bulletin.studentName}</p>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        {bulletin.class}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <p className="text-sm text-gray-600">{bulletin.trimester}</p>
                    </td>
                    <td className="py-4 px-6">
                      <p className="text-sm text-gray-600">{bulletin.schoolYear}</p>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-2">
                        <span className={`text-lg font-bold ${
                          bulletin.generalAverage >= 14 ? 'text-green-600' : 
                          bulletin.generalAverage >= 10 ? 'text-blue-600' : 
                          'text-red-600'
                        }`}>
                          {bulletin.generalAverage.toFixed(2)}/20
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        bulletin.generalAverage >= 14 ? 'bg-green-100 text-green-800' : 
                        bulletin.generalAverage >= 10 ? 'bg-blue-100 text-blue-800' : 
                        'bg-red-100 text-red-800'
                      }`}>
                        {bulletin.mention}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-2">
                        <button 
                          onClick={() => handleViewBulletin(bulletin)}
                          className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Voir les détails"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => handleEditClick(bulletin)}
                          disabled={updating}
                          className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors disabled:opacity-50"
                          title="Modifier"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => bulletin.id && handleDeleteBulletin(bulletin.id)}
                          disabled={deleting}
                          className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50"
                          title="Supprimer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => handlePrintBulletin(bulletin)}
                          className="p-1.5 text-gray-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                          title="Imprimer"
                        >
                          <Download className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add Bulletin Modal */}
      <Modal
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        title="Créer un Bulletin de Notes"
        size="xl"
      >
        <BulletinForm
          onSubmit={handleAddBulletin}
          onCancel={() => setShowAddForm(false)}
          students={students}
          subjects={subjects}
          teachers={teachers}
        />
      </Modal>

      {/* Edit Bulletin Modal */}
      <Modal
        isOpen={showEditForm}
        onClose={() => {
          setShowEditForm(false);
          setSelectedBulletin(null);
        }}
        title="Modifier le Bulletin"
        size="xl"
      >
        {selectedBulletin && (
          <BulletinForm
            onSubmit={handleEditBulletin}
            onCancel={() => {
              setShowEditForm(false);
              setSelectedBulletin(null);
            }}
            initialData={selectedBulletin}
            students={students}
            subjects={subjects}
            teachers={teachers}
          />
        )}
      </Modal>

      {/* View Bulletin Modal */}
      <Modal
        isOpen={showViewModal}
        onClose={() => {
          setShowViewModal(false);
          setSelectedBulletin(null);
        }}
        title="Détails du Bulletin"
        size="xl"
      >
        {selectedBulletin && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Avatar 
                  firstName={selectedBulletin.studentName?.split(' ')?.[0] || ''} 
                  lastName={selectedBulletin.studentName?.split(' ')?.[1] || ''} 
                  size="lg" 
                  showPhoto={true}
                />
                <div>
                  <h3 className="text-xl font-bold text-gray-900">{selectedBulletin.studentName}</h3>
                  <p className="text-gray-600">Classe: {selectedBulletin.class} - {selectedBulletin.trimester}</p>
                  <p className="text-gray-600">Année scolaire: {selectedBulletin.schoolYear}</p>
                </div>
              </div>
              <div>
                <button
                  onClick={() => handlePrintBulletin(selectedBulletin)}
                  className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Imprimer
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-gray-300">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="border border-gray-300 px-4 py-2 text-left">Matière</th>
                    <th className="border border-gray-300 px-4 py-2 text-center">N1</th>
                    <th className="border border-gray-300 px-4 py-2 text-center">N2</th>
                    <th className="border border-gray-300 px-4 py-2 text-center">Exam</th>
                    <th className="border border-gray-300 px-4 py-2 text-center">Moy/20</th>
                    <th className="border border-gray-300 px-4 py-2 text-center">Coeff</th>
                    <th className="border border-gray-300 px-4 py-2 text-center">Moy. Coeff</th>
                    <th className="border border-gray-300 px-4 py-2 text-center">Rang</th>
                    <th className="border border-gray-300 px-4 py-2 text-left">Appréciations</th>
                    <th className="border border-gray-300 px-4 py-2 text-left">Enseignant</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedBulletin.subjects.map((subject, index) => (
                    <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                      <td className="border border-gray-300 px-4 py-2 font-medium">{subject.name}</td>
                      <td className="border border-gray-300 px-4 py-2 text-center">{subject.n1}</td>
                      <td className="border border-gray-300 px-4 py-2 text-center">{subject.n2}</td>
                      <td className="border border-gray-300 px-4 py-2 text-center">{subject.exam}</td>
                      <td className="border border-gray-300 px-4 py-2 text-center font-medium">{subject.average.toFixed(2)}</td>
                      <td className="border border-gray-300 px-4 py-2 text-center">{subject.coefficient}</td>
                      <td className="border border-gray-300 px-4 py-2 text-center font-medium">{subject.weightedAverage.toFixed(2)}</td>
                      <td className="border border-gray-300 px-4 py-2 text-center">{subject.rank}</td>
                      <td className="border border-gray-300 px-4 py-2">{subject.appreciation}</td>
                      <td className="border border-gray-300 px-4 py-2">{subject.teacher}</td>
                    </tr>
                  ))}
                  <tr className="bg-gray-100 font-bold">
                    <td className="border border-gray-300 px-4 py-2">TOTAL</td>
                    <td className="border border-gray-300 px-4 py-2 text-center" colSpan={4}></td>
                    <td className="border border-gray-300 px-4 py-2 text-center">{selectedBulletin.totalCoefficient}</td>
                    <td className="border border-gray-300 px-4 py-2 text-center">{selectedBulletin.totalWeightedAverage.toFixed(2)}</td>
                    <td className="border border-gray-300 px-4 py-2 text-center" colSpan={3}></td>
                  </tr>
                </tbody>
                <tfoot>
                  <tr className="bg-blue-50">
                    <td className="border border-gray-300 px-4 py-2 font-bold" colSpan={2}>MOYENNE GÉNÉRALE</td>
                    <td className="border border-gray-300 px-4 py-2 text-center font-bold text-lg" colSpan={8}>
                      {selectedBulletin.generalAverage.toFixed(2)}/20
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
              <div className="border border-gray-300 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">Évaluation</h4>
                <p className="text-lg font-bold text-center py-2 rounded-lg bg-gray-100">
                  {selectedBulletin.mention}
                </p>
              </div>
              <div className="border border-gray-300 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">Assiduité</h4>
                <div className="space-y-2">
                  <p><span className="font-medium">Absences:</span> {selectedBulletin.absences} jour(s)</p>
                  <p><span className="font-medium">Retards:</span> {selectedBulletin.retards}</p>
                </div>
              </div>
              <div className="border border-gray-300 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">Décision</h4>
                <p className={`text-center py-2 rounded-lg ${selectedBulletin.isPassing ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                  {selectedBulletin.isPassing ? 'PASSANT' : 'NON PASSANT'}
                </p>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* PDF Preview Modal */}
      <Modal
        isOpen={showPdfModal}
        onClose={() => {
          setShowPdfModal(false);
          setSelectedBulletin(null);
        }}
        title="Aperçu du Bulletin"
        size="xl"
      >
        {selectedBulletin && (
          <BulletinPDF
            bulletin={selectedBulletin}
          />
        )}
      </Modal>
    </div>
  );
}