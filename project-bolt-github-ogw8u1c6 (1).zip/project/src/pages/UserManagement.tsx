import React, { useState, useEffect } from 'react';
import { Search, Plus, Filter, Edit, Trash2, Eye, User as UserIcon, Mail, ShieldCheck, CheckCircle, XCircle } from 'lucide-react';
import { Modal } from '../components/Modal';
import { Avatar } from '../components/Avatar';
import { usersService } from '../lib/firebase/firebaseService';
import { adminResetPassword } from '../lib/auth';
import { useFirebaseCollection } from '../hooks/useFirebaseCollection';
import { UserForm } from '../components/forms/UserForm';
import { USER_ROLES, getRoleDisplayName } from '../lib/roles';
import { PermissionWrapper } from '../components/auth/PermissionWrapper';
import type { FirebaseUserType } from '../lib/firebase/collections';

export function UserManagement() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedRole, setSelectedRole] = useState('');
  const [selectedUser, setSelectedUser] = useState<FirebaseUserType | null>(null);

  // Hook Firebase with real-time synchronization
  const {
    data: users,
    loading,
    error,
    creating,
    updating,
    deleting,
    create,
    update,
    remove
  } = useFirebaseCollection<FirebaseUserType>(usersService, true);

  const filteredUsers = users.filter(user => {
    if (!user) return false;
    
    const firstName = user.firstName || '';
    const lastName = user.lastName || '';
    const email = user.email || '';
    const role = user.role || '';
    
    const matchesSearch = firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = selectedRole === '' || role === selectedRole;
    return matchesSearch && matchesRole;
  });

  const handleAddUser = async (data: any) => {
    try {
      console.log('🚀 Ajout d\'utilisateur - Données reçues:', data);
      
      // Préparer les données pour Firebase
      const userData = {
        uid: data.uid || '',
        email: data.email,
        firstName: data.firstName,
        lastName: data.lastName,
        role: data.role,
        isActive: data.isActive || true
      };
      
      console.log('📝 Données formatées pour Firebase:', userData);
      
      const userId = await create(userData);
      console.log('✅ Utilisateur créé avec l\'ID:', userId);
      
      setShowAddForm(false);
      
      // Message de succès
      alert('✅ Utilisateur ajouté avec succès !');
      
    } catch (error: any) {
      console.error('❌ Erreur lors de l\'ajout de l\'utilisateur:', error);
      alert('❌ Erreur lors de l\'ajout de l\'utilisateur: ' + error.message);
    }
  };

  const handleEditUser = async (data: any) => {
    if (selectedUser?.id) {
      try {
        console.log('🔄 Modification d\'utilisateur - Données:', data);
        
        await update(selectedUser.id, data);
        console.log('✅ Utilisateur modifié avec succès');
        
        setShowEditForm(false);
        setSelectedUser(null);
        
        alert('✅ Utilisateur modifié avec succès !');
        
      } catch (error: any) {
        console.error('❌ Erreur lors de la modification:', error);
        alert('❌ Erreur lors de la modification: ' + error.message);
      }
    }
  };

  const handleDeleteUser = async (id: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?')) {
      try {
        console.log('🗑️ Suppression de l\'utilisateur ID:', id);
        await remove(id);
        console.log('✅ Utilisateur supprimé avec succès');
        alert('✅ Utilisateur supprimé avec succès !');
      } catch (error: any) {
        console.error('❌ Erreur lors de la suppression:', error);
        alert('❌ Erreur lors de la suppression: ' + error.message);
      }
    }
  };

  const handleViewUser = (user: FirebaseUserType) => {
    setSelectedUser(user);
    setShowViewModal(true);
  };

  const handleEditClick = (user: FirebaseUserType) => {
    setSelectedUser(user);
    setShowEditForm(true);
  };

  const handleResetPassword = async (email: string) => {
    if (!email) {
      alert('Aucune adresse email disponible pour cet utilisateur');
      return;
    }
    
    try {
      console.log('Tentative de réinitialisation du mot de passe pour:', email);
      await adminResetPassword(email);
      alert(`Email de réinitialisation du mot de passe envoyé à ${email}`);
    } catch (error: any) {
      console.error('Erreur lors de la réinitialisation du mot de passe:', error);
      alert(`Erreur: ${error.message}`);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement des utilisateurs...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <p className="text-red-600">Error: {error}</p>
        <button 
          onClick={() => window.location.reload()} 
          className="mt-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
        >
          Réessayer
        </button>
      </div>
    );
  }

  return (
    <PermissionWrapper permission="manage_users">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Gestion des Utilisateurs</h1>
            <p className="text-gray-600">Gérez les utilisateurs du système et leurs permissions</p>
          </div>
          
          <button
            onClick={() => {
              console.log('🔘 Ouverture du formulaire d\'ajout d\'utilisateur');
              setShowAddForm(true);
            }}
            disabled={creating}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
          >
            {creating ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
            ) : (
              <Plus className="w-4 h-4 mr-2" />
            )}
            Ajouter un Utilisateur
          </button>
        </div>

        {/* Filters and Search */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Rechercher par nom ou email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            
            <div className="flex gap-2">
              <select
                value={selectedRole}
                onChange={(e) => setSelectedRole(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Tous les rôles</option>
                {Object.values(USER_ROLES).map(role => (
                  <option key={role} value={role}>{getRoleDisplayName(role)}</option>
                ))}
              </select>
              
              <button className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                <Filter className="w-4 h-4 mr-2" />
                Filtres
              </button>
            </div>
          </div>
        </div>

        {/* Users Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white rounded-lg p-4 border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Utilisateurs</p>
                <p className="text-2xl font-bold text-gray-900">{users.length}</p>
              </div>
              <UserIcon className="w-8 h-8 text-blue-600" />
            </div>
          </div>
          
          <div className="bg-white rounded-lg p-4 border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Utilisateurs Actifs</p>
                <p className="text-2xl font-bold text-green-600">{users.filter(u => u && u.isActive).length}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </div>
          
          <div className="bg-white rounded-lg p-4 border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Utilisateurs Inactifs</p>
                <p className="text-2xl font-bold text-red-600">{users.filter(u => u && !u.isActive).length}</p>
              </div>
              <XCircle className="w-8 h-8 text-red-600" />
            </div>
          </div>
          
          <div className="bg-white rounded-lg p-4 border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Rôles</p>
                <p className="text-2xl font-bold text-purple-600">{Object.values(USER_ROLES).length}</p>
              </div>
              <ShieldCheck className="w-8 h-8 text-purple-600" />
            </div>
          </div>
        </div>

        {/* Users Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          {users.length === 0 ? (
            <div className="text-center py-12">
              <UserIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun utilisateur enregistré</h3>
              <p className="text-gray-500 mb-6">Commencez par ajouter votre premier utilisateur au système.</p>
              <button
                onClick={() => setShowAddForm(true)}
                className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus className="w-4 h-4 mr-2" />
                Ajouter un Utilisateur
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="text-left py-3 px-6 font-medium text-gray-900">Utilisateur</th>
                    <th className="text-left py-3 px-6 font-medium text-gray-900">Email</th>
                    <th className="text-left py-3 px-6 font-medium text-gray-900">Rôle</th>
                    <th className="text-left py-3 px-6 font-medium text-gray-900">Statut</th>
                    <th className="text-left py-3 px-6 font-medium text-gray-900">Créé le</th>
                    <th className="text-left py-3 px-6 font-medium text-gray-900">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredUsers.map((user) => (
                    <tr key={user.id} className="hover:bg-gray-50 transition-colors">
                      <td className="py-4 px-6">
                        <div className="flex items-center space-x-3">
                          <Avatar
                            firstName={user.firstName || ''} 
                            lastName={user.lastName || ''} 
                            size="md" 
                            showPhoto={true}
                          />
                          <div>
                            <p className="font-medium text-gray-900">{user.firstName || ''} {user.lastName || ''}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <div className="flex items-center text-sm text-gray-500">
                          <Mail className="w-4 h-4 mr-2 text-gray-400" />
                          {user.email || 'Pas d\'email'}
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                          {getRoleDisplayName(user.role || '')}
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          user.isActive 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {user.isActive ? 'Actif' : 'Inactif'}
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        <p className="text-sm text-gray-600">
                          {user.createdAt ? new Date(user.createdAt).toLocaleDateString('fr-FR') : 'Non disponible'}
                        </p>
                      </td>
                      <td className="py-4 px-6">
                        <div className="flex items-center space-x-2">
                          <button 
                            onClick={() => handleViewUser(user)}
                            className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="Voir les détails"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleEditClick(user)}
                            disabled={updating}
                            className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors disabled:opacity-50"
                            title="Modifier"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => user.id && handleDeleteUser(user.id)}
                            disabled={deleting}
                            className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50"
                            title="Supprimer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => user.email && handleResetPassword(user.email)}
                            className="p-1.5 text-gray-400 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition-colors"
                            title="Réinitialiser le mot de passe"
                          >
                            <Mail className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Add User Modal */}
        <Modal
          isOpen={showAddForm}
          onClose={() => setShowAddForm(false)}
          title="Ajouter un Utilisateur"
          size="lg"
        >
          <UserForm
            onSubmit={handleAddUser}
            onCancel={() => setShowAddForm(false)}
          />
        </Modal>

        {/* Edit User Modal */}
        <Modal
          isOpen={showEditForm}
          onClose={() => {
            setShowEditForm(false);
            setSelectedUser(null);
          }}
          title="Modifier l'Utilisateur"
          size="lg"
        >
          {selectedUser && (
            <UserForm
              onSubmit={handleEditUser}
              onCancel={() => {
                setShowEditForm(false);
                setSelectedUser(null);
              }}
              initialData={selectedUser}
            />
          )}
        </Modal>

        {/* View User Modal */}
        <Modal
          isOpen={showViewModal}
          onClose={() => {
            setShowViewModal(false);
            setSelectedUser(null);
          }}
          title="Détails de l'Utilisateur"
          size="lg"
        >
          {selectedUser && (
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                <Avatar 
                  firstName={selectedUser.firstName || ''} 
                  lastName={selectedUser.lastName || ''} 
                  size="lg" 
                  showPhoto={true}
                />
                <div>
                  <h3 className="text-xl font-bold text-gray-900">
                    {selectedUser.firstName || ''} {selectedUser.lastName || ''}
                  </h3>
                  <p className="text-gray-600">{selectedUser.email || 'Pas d\'email'}</p>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 mt-1">
                    {getRoleDisplayName(selectedUser.role || '')}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Informations du Compte</h4>
                  <div className="space-y-2 text-sm">
                    <p><span className="font-medium">ID Utilisateur:</span> {selectedUser.uid || 'Non disponible'}</p>
                    <p><span className="font-medium">Statut:</span> 
                      <span className={`ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                        selectedUser.isActive 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {selectedUser.isActive ? 'Actif' : 'Inactif'}
                      </span>
                    </p>
                    <p><span className="font-medium">Créé le:</span> {selectedUser.createdAt ? new Date(selectedUser.createdAt).toLocaleDateString('fr-FR') : 'Non disponible'}</p>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Permissions</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex flex-wrap gap-1 mt-1">
                      {selectedUser.permissions ? (
                        selectedUser.permissions.map((permission: string, index: number) => (
                          <span key={index} className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-purple-100 text-purple-800">
                            {permission}
                          </span>
                        ))
                      ) : (
                        <p className="text-gray-500">Permissions basées sur le rôle: {selectedUser.role || 'Non disponible'}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Quick actions */}
              <div className="mt-6 pt-4 border-t border-gray-200">
                <h4 className="font-medium text-gray-900 mb-3">Actions Rapides</h4>
                <div className="flex space-x-3">
                  <button
                    onClick={() => {
                      setShowViewModal(false);
                      handleEditClick(selectedUser);
                    }}
                    className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-sm"
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Modifier l'Utilisateur
                  </button>
                  <button
                    onClick={() => selectedUser.email && handleResetPassword(selectedUser.email)}
                    className="inline-flex items-center px-3 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors text-sm"
                  >
                    <Mail className="w-4 h-4 mr-2" />
                    Réinitialiser le Mot de Passe
                  </button>
                </div>
              </div>
            </div>
          )}
        </Modal>
      </div>
    </PermissionWrapper>
  );
}