import React, { useState, useEffect } from 'react';
import { Settings, AlertTriangle, CheckCircle, Info, History, Download } from 'lucide-react';
import { Modal } from '../components/Modal';
import { FinancialSettingsForm } from '../components/forms/FinancialSettingsForm';
import { FinancialSettingsService } from '../lib/services/financialSettingsService';
import type { FinancialSetting } from '../lib/firebase/collections';
import { useAuth } from '../hooks/useAuth';

export function FinancialSettingsFirebase() {
  const { profile } = useAuth();
  const [settings, setSettings] = useState<FinancialSetting | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showEditForm, setShowEditForm] = useState(false);
  const [saving, setSaving] = useState(false);

  // Charger les paramètres au montage du composant
  useEffect(() => {
    const loadSettings = async () => {
      try {
        console.log('🔄 Chargement des paramètres financiers...');
        const data = await FinancialSettingsService.get();
        setSettings(data);
        console.log('✅ Paramètres chargés:', data);
      } catch (error: any) {
        console.error('❌ Erreur lors du chargement des paramètres:', error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    loadSettings();
  }, []);

  const handleUpdateSettings = async (data: any) => {
    try {
      setSaving(true);
      console.log('🚀 Mise à jour des paramètres financiers:', data);
      
      await FinancialSettingsService.createOrUpdate(data);
      console.log('✅ Paramètres mis à jour avec succès');
      
      // Recharger les paramètres
      const updatedSettings = await FinancialSettingsService.get();
      setSettings(updatedSettings);
      
      setShowEditForm(false);
      alert('✅ Paramètres financiers mis à jour avec succès !');
      
    } catch (error: any) {
      console.error('❌ Erreur lors de la mise à jour:', error);
      alert('❌ Erreur lors de la mise à jour: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  const handleExportSettings = () => {
    if (settings) {
      const dataStr = JSON.stringify(settings, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `parametres-financiers-${new Date().toISOString().split('T')[0]}.json`;
      link.click();
      URL.revokeObjectURL(url);
    }
  };

  const handleInitializeDefaults = async () => {
    if (confirm('Voulez-vous initialiser les paramètres avec les valeurs par défaut pour Madagascar ?')) {
      try {
        setSaving(true);
        const defaultSettings = FinancialSettingsService.getDefaultSettings();
        
        const settingsData = {
          cnaps: defaultSettings.cnaps,
          ostie: defaultSettings.ostie,
          lastUpdatedBy: profile?.firstName + ' ' + profile?.lastName || 'Administrateur',
          effectiveDate: new Date().toISOString().split('T')[0],
          notes: 'Paramètres initialisés avec les valeurs par défaut pour Madagascar'
        };
        
        await FinancialSettingsService.createOrUpdate(settingsData);
        
        // Recharger les paramètres
        const updatedSettings = await FinancialSettingsService.get();
        setSettings(updatedSettings);
        
        alert('✅ Paramètres initialisés avec succès !');
        
      } catch (error: any) {
        console.error('❌ Erreur lors de l\'initialisation:', error);
        alert('❌ Erreur lors de l\'initialisation: ' + error.message);
      } finally {
        setSaving(false);
      }
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement des paramètres financiers...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <p className="text-red-600">Erreur: {error}</p>
        <button 
          onClick={() => window.location.reload()} 
          className="mt-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
        >
          Réessayer
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Paramètres Financiers</h1>
          <p className="text-gray-600">Configuration des cotisations sociales CNAPS et OSTIE</p>
        </div>
        
        <div className="flex gap-2">
          <button 
            onClick={handleExportSettings}
            disabled={!settings}
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
          >
            <Download className="w-4 h-4 mr-2" />
            Exporter
          </button>
          <button
            onClick={() => setShowEditForm(true)}
            disabled={saving}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
          >
            {saving ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
            ) : (
              <Settings className="w-4 h-4 mr-2" />
            )}
            Modifier les Paramètres
          </button>
        </div>
      </div>

      {/* Statut des paramètres */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-bold text-gray-900">État Actuel des Paramètres</h2>
          {settings ? (
            <div className="flex items-center space-x-2 text-green-600">
              <CheckCircle className="w-5 h-5" />
              <span className="text-sm font-medium">Configuré</span>
            </div>
          ) : (
            <div className="flex items-center space-x-2 text-orange-600">
              <AlertTriangle className="w-5 h-5" />
              <span className="text-sm font-medium">Non configuré</span>
            </div>
          )}
        </div>

        {settings ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* CNAPS */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-blue-800">CNAPS</h3>
                <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                  settings.cnaps.isActive 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-red-100 text-red-800'
                }`}>
                  {settings.cnaps.isActive ? 'Actif' : 'Inactif'}
                </span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Taux salarié:</span>
                  <span className="font-medium">{settings.cnaps.employeeRate}%</span>
                </div>
                <div className="flex justify-between">
                  <span>Taux employeur:</span>
                  <span className="font-medium">{settings.cnaps.employerRate}%</span>
                </div>
                <div className="flex justify-between">
                  <span>Plafond:</span>
                  <span className="font-medium">{settings.cnaps.ceiling.toLocaleString()} Ar</span>
                </div>
              </div>
            </div>

            {/* OSTIE */}
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-green-800">OSTIE</h3>
                <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                  settings.ostie.isActive 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-red-100 text-red-800'
                }`}>
                  {settings.ostie.isActive ? 'Actif' : 'Inactif'}
                </span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Taux salarié:</span>
                  <span className="font-medium">{settings.ostie.employeeRate}%</span>
                </div>
                <div className="flex justify-between">
                  <span>Taux employeur:</span>
                  <span className="font-medium">{settings.ostie.employerRate}%</span>
                </div>
                <div className="flex justify-between">
                  <span>Plafond:</span>
                  <span className="font-medium">{settings.ostie.ceiling.toLocaleString()} Ar</span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-8">
            <AlertTriangle className="w-16 h-16 text-orange-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Paramètres non configurés</h3>
            <p className="text-gray-600 mb-6">
              Les paramètres de cotisations sociales n'ont pas encore été configurés.
            </p>
            <button
              onClick={handleInitializeDefaults}
              disabled={saving}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              {saving ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
              ) : (
                <Settings className="w-4 h-4 mr-2" />
              )}
              Initialiser avec les valeurs par défaut
            </button>
          </div>
        )}
      </div>

      {/* Informations sur les dernières modifications */}
      {settings && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-bold text-gray-900 mb-4">Informations de Modification</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-2">Dernière modification</h4>
              <p className="text-sm text-gray-600">
                {settings.updatedAt ? settings.updatedAt.toLocaleDateString('fr-FR') : 'Non disponible'}
              </p>
              <p className="text-xs text-gray-500">
                Par: {settings.lastUpdatedBy}
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-2">Date d'entrée en vigueur</h4>
              <p className="text-sm text-gray-600">
                {settings.effectiveDate ? new Date(settings.effectiveDate).toLocaleDateString('fr-FR') : 'Non définie'}
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-2">Statut</h4>
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${settings.cnaps.isActive ? 'bg-green-500' : 'bg-red-500'}`}></div>
                  <span className="text-sm">CNAPS {settings.cnaps.isActive ? 'activé' : 'désactivé'}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${settings.ostie.isActive ? 'bg-green-500' : 'bg-red-500'}`}></div>
                  <span className="text-sm">OSTIE {settings.ostie.isActive ? 'activé' : 'désactivé'}</span>
                </div>
              </div>
            </div>
          </div>

          {settings.notes && (
            <div className="mt-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-medium text-blue-800 mb-2 flex items-center">
                <Info className="w-4 h-4 mr-2" />
                Notes
              </h4>
              <p className="text-sm text-blue-700">{settings.notes}</p>
            </div>
          )}
        </div>
      )}

      {/* Informations réglementaires */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h2 className="text-lg font-bold text-gray-900 mb-4">Informations Réglementaires</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h3 className="font-bold text-blue-800 mb-2">CNAPS - Caisse Nationale de Prévoyance Sociale</h3>
              <div className="text-sm text-blue-700 space-y-1">
                <p><strong>Objectif :</strong> Retraite et prestations familiales</p>
                <p><strong>Taux usuels :</strong> 1% salarié + 13% employeur</p>
                <p><strong>Base de calcul :</strong> Salaire brut plafonné</p>
                <p><strong>Fréquence :</strong> Déclaration et paiement mensuels</p>
              </div>
            </div>
            
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <h3 className="font-bold text-green-800 mb-2">OSTIE - Organisme Sanitaire Tananarivien</h3>
              <div className="text-sm text-green-700 space-y-1">
                <p><strong>Objectif :</strong> Couverture santé des employés</p>
                <p><strong>Taux usuels :</strong> 1% salarié + 5% employeur</p>
                <p><strong>Base de calcul :</strong> Salaire brut plafonné</p>
                <p><strong>Zone :</strong> Principalement Antananarivo</p>
              </div>
            </div>
          </div>
          
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h3 className="font-bold text-yellow-800 mb-3 flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2" />
              Important
            </h3>
            <div className="text-sm text-yellow-700 space-y-2">
              <p>
                <strong>Vérification réglementaire :</strong> Les taux et plafonds peuvent évoluer. 
                Vérifiez régulièrement auprès des organismes officiels.
              </p>
              <p>
                <strong>Responsabilité :</strong> L'école est responsable du respect des obligations 
                sociales et du paiement des cotisations dans les délais.
              </p>
              <p>
                <strong>Sanctions :</strong> Le non-paiement peut entraîner des pénalités et 
                l'exclusion des prestations.
              </p>
              <p>
                <strong>Conseil :</strong> Consultez un expert-comptable ou un conseiller social 
                pour valider ces paramètres.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Edit Settings Modal */}
      <Modal
        isOpen={showEditForm}
        onClose={() => setShowEditForm(false)}
        title="Modifier les Paramètres Financiers"
        size="xl"
      >
        <FinancialSettingsForm
          onSubmit={handleUpdateSettings}
          onCancel={() => setShowEditForm(false)}
          initialData={settings || undefined}
        />
      </Modal>
    </div>
  );
}