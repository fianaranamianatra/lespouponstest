import React, { useState } from 'react';
import { Search, Plus, Filter, Award, TrendingUp, TrendingDown, BarChart3, Download } from 'lucide-react';
import { Modal } from '../components/Modal';
import { GradeForm } from '../components/forms/GradeForm';
import { Avatar } from '../components/Avatar';

interface Grade {
  id: string;
  studentName: string;
  subject: string;
  class: string;
  assignment: string;
  grade: number;
  maxGrade: number;
  date: string;
  teacher: string;
  type: 'exam' | 'homework' | 'quiz' | 'project';
}

const mockGrades: Grade[] = [
  {
    id: '1',
    studentName: 'Marie Dubois',
    subject: 'Mathématiques',
    class: '6ème A',
    assignment: 'Contrôle Chapitre 3',
    grade: 16,
    maxGrade: 20,
    date: '2024-11-20',
    teacher: 'Catherine Moreau',
    type: 'exam'
  },
  {
    id: '2',
    studentName: 'Pierre Martin',
    subject: 'Français',
    class: '5ème B',
    assignment: 'Rédaction',
    grade: 14,
    maxGrade: 20,
    date: '2024-11-19',
    teacher: 'Jean-Pierre Durand',
    type: 'homework'
  },
  {
    id: '3',
    studentName: 'Julie Bernard',
    subject: 'Anglais',
    class: '6ème C',
    assignment: 'Quiz Vocabulaire',
    grade: 18,
    maxGrade: 20,
    date: '2024-11-18',
    teacher: 'Marie Lambert',
    type: 'quiz'
  },
  {
    id: '4',
    studentName: 'Thomas Leroy',
    subject: 'Sciences',
    class: '4ème A',
    assignment: 'Projet Sciences',
    grade: 12,
    maxGrade: 20,
    date: '2024-11-17',
    teacher: 'Patrick Rousseau',
    type: 'project'
  }
];

const typeColors = {
  exam: 'bg-red-100 text-red-800',
  homework: 'bg-blue-100 text-blue-800',
  quiz: 'bg-green-100 text-green-800',
  project: 'bg-purple-100 text-purple-800'
};

const typeLabels = {
  exam: 'Examen',
  homework: 'Devoir',
  quiz: 'Quiz',
  project: 'Projet'
};

export function Grades() {
  const [grades, setGrades] = useState<Grade[]>(mockGrades);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('');

  const filteredGrades = grades.filter(grade => {
    const matchesSearch = grade.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         grade.assignment.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClass = selectedClass === '' || grade.class === selectedClass;
    const matchesSubject = selectedSubject === '' || grade.subject === selectedSubject;
    return matchesSearch && matchesClass && matchesSubject;
  });

  const classes = [...new Set(grades.map(g => g.class))];
  const subjects = [...new Set(grades.map(g => g.subject))];

  const averageGrade = grades.reduce((acc, g) => acc + (g.grade / g.maxGrade) * 20, 0) / grades.length;
  const excellentGrades = grades.filter(g => (g.grade / g.maxGrade) >= 0.8).length;
  const improvementNeeded = grades.filter(g => (g.grade / g.maxGrade) < 0.5).length;

  const handleAddGrade = (data: any) => {
    const newGrade: Grade = {
      id: Date.now().toString(),
      class: data.class || '6ème A', // Default class, should be determined from student
      studentName: data.studentName || 'Élève inconnu',
      subject: data.subject || 'Matière inconnue',
      assignment: data.assignment || 'Évaluation',
      teacher: data.teacher || 'Enseignant inconnu',
      date: data.date || new Date().toISOString().split('T')[0],
      type: data.type || 'exam',
      ...data,
      grade: parseFloat(data.grade) || 0,
      maxGrade: parseInt(data.maxGrade) || 20
    };
    setGrades([...grades, newGrade]);
    setShowAddForm(false);
  };

  const handleExport = () => {
    // Simulate export functionality
    alert('Export des notes en cours...');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Gestion des Notes</h1>
          <p className="text-gray-600">Suivez les performances et évaluations des élèves</p>
        </div>
        
        <div className="flex gap-2">
          <button 
            onClick={handleExport}
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Download className="w-4 h-4 mr-2" />
            Exporter
          </button>
          <button
            onClick={() => setShowAddForm(true)}
            className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            Ajouter une Note
          </button>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Rechercher par élève ou devoir..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="flex gap-2">
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="">Toutes les classes</option>
              {classes.map(className => (
                <option key={className} value={className}>{className}</option>
              ))}
            </select>
            
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="">Toutes les matières</option>
              {subjects.map(subject => (
                <option key={subject} value={subject}>{subject}</option>
              ))}
            </select>
            
            <button className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Filter className="w-4 h-4 mr-2" />
              Filtres
            </button>
          </div>
        </div>
      </div>

      {/* Grades Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Moyenne Générale</p>
              <p className="text-2xl font-bold text-gray-900">{averageGrade.toFixed(1)}/20</p>
            </div>
            <BarChart3 className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Excellentes Notes</p>
              <p className="text-2xl font-bold text-green-600">{excellentGrades}</p>
            </div>
            <TrendingUp className="w-8 h-8 text-green-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">À Améliorer</p>
              <p className="text-2xl font-bold text-red-600">{improvementNeeded}</p>
            </div>
            <TrendingDown className="w-8 h-8 text-red-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Notes</p>
              <p className="text-2xl font-bold text-purple-600">{grades.length}</p>
            </div>
            <Award className="w-8 h-8 text-purple-600" />
          </div>
        </div>
      </div>

      {/* Grades Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Élève</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Matière</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Devoir</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Type</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Note</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Date</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Enseignant</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Performance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredGrades.map((grade) => {
                const percentage = (grade.grade / grade.maxGrade) * 100;
                const performanceColor = percentage >= 80 ? 'text-green-600' : 
                                       percentage >= 60 ? 'text-blue-600' : 
                                       percentage >= 40 ? 'text-orange-600' : 'text-red-600';
                
                return (
                  <tr key={grade.id} className="hover:bg-gray-50 transition-colors">
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-3">
                        <Avatar 
                          firstName={grade.studentName.split(' ')[0] || ''} 
                          lastName={grade.studentName.split(' ')[1] || ''} 
                          size="sm" 
                          showPhoto={true}
                        />
                        <div>
                          <p className="font-medium text-gray-900">{grade.studentName}</p>
                          <p className="text-sm text-gray-500">{grade.class}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        {grade.subject}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <p className="text-sm font-medium text-gray-900">{grade.assignment}</p>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${typeColors[grade.type]}`}>
                        {typeLabels[grade.type]}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-2">
                        <span className={`text-lg font-bold ${performanceColor}`}>
                          {grade.grade}/{grade.maxGrade}
                        </span>
                        <span className="text-sm text-gray-500">
                          ({percentage.toFixed(0)}%)
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <p className="text-sm text-gray-600">
                        {new Date(grade.date).toLocaleDateString('fr-FR')}
                      </p>
                    </td>
                    <td className="py-4 px-6">
                      <p className="text-sm text-gray-600">{grade.teacher}</p>
                    </td>
                    <td className="py-4 px-6">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            percentage >= 80 ? 'bg-green-500' : 
                            percentage >= 60 ? 'bg-blue-500' : 
                            percentage >= 40 ? 'bg-orange-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Grade Modal */}
      <Modal
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        title="Ajouter une Note"
        size="lg"
      >
        <GradeForm
          onSubmit={handleAddGrade}
          onCancel={() => setShowAddForm(false)}
        />
      </Modal>
    </div>
  );
}