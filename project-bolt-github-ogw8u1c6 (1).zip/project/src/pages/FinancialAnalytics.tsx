import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, TrendingDown, Download, Calendar, Users, DollarSign, PieChart, AlertTriangle, CheckCircle, Info } from 'lucide-react';
import { FinancialAnalyticsService, FinancialAnalytics, PayrollReport, DepartmentAnalytics } from '../lib/services/financialAnalyticsService';
import { FinancialChart } from '../components/charts/FinancialChart';
import { TrendChart } from '../components/charts/TrendChart';
import { Modal } from '../components/Modal';

export function FinancialAnalyticsPage() {
  const [analytics, setAnalytics] = useState<FinancialAnalytics | null>(null);
  const [payrollReport, setPayrollReport] = useState<PayrollReport[]>([]);
  const [departmentAnalytics, setDepartmentAnalytics] = useState<DepartmentAnalytics[]>([]);
  const [complianceReport, setComplianceReport] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedPeriod, setSelectedPeriod] = useState('current_month');
  const [viewMode, setViewMode] = useState<'overview' | 'payroll' | 'departments' | 'compliance'>('overview');
  const [showComplianceModal, setShowComplianceModal] = useState(false);

  // Charger les données au montage et quand la période change
  useEffect(() => {
    loadAnalytics();
  }, [selectedPeriod]);

  const loadAnalytics = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Calculer les dates selon la période sélectionnée
      const { startDate, endDate } = getPeriodDates(selectedPeriod);
      
      console.log('📊 Chargement des analyses financières...');
      
      // Charger toutes les analyses en parallèle
      const [
        analyticsData,
        payrollData,
        departmentData,
        complianceData
      ] = await Promise.all([
        FinancialAnalyticsService.analyzeFinances(startDate, endDate),
        FinancialAnalyticsService.generatePayrollReport(),
        FinancialAnalyticsService.analyzeDepartments(),
        FinancialAnalyticsService.generateComplianceReport()
      ]);
      
      setAnalytics(analyticsData);
      setPayrollReport(payrollData);
      setDepartmentAnalytics(departmentData);
      setComplianceReport(complianceData);
      
      console.log('✅ Analyses chargées avec succès');
    } catch (error: any) {
      console.error('❌ Erreur lors du chargement des analyses:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const getPeriodDates = (period: string): { startDate: string; endDate: string } => {
    const now = new Date();
    let startDate: Date;
    let endDate: Date = now;

    switch (period) {
      case 'current_month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'last_month':
        startDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        endDate = new Date(now.getFullYear(), now.getMonth(), 0);
        break;
      case 'current_quarter':
        const quarterStart = Math.floor(now.getMonth() / 3) * 3;
        startDate = new Date(now.getFullYear(), quarterStart, 1);
        break;
      case 'current_year':
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
      default:
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
    }

    return {
      startDate: startDate.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0]
    };
  };

  const handleExportPayroll = () => {
    if (payrollReport.length === 0) {
      alert('Aucune donnée de paie à exporter');
      return;
    }

    const csvContent = FinancialAnalyticsService.exportPayrollToCSV(payrollReport);
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `rapport-paie-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleExportAnalytics = () => {
    if (!analytics) {
      alert('Aucune analyse à exporter');
      return;
    }

    const jsonContent = FinancialAnalyticsService.exportAnalyticsToJSON(analytics);
    const blob = new Blob([jsonContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `analyse-financiere-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const renderOverview = () => {
    if (!analytics) return null;

    const contributionsData = [
      { label: 'CNAPS Salarié', value: analytics.contributions.cnaps.employeeTotal, color: 'bg-blue-500' },
      { label: 'CNAPS Employeur', value: analytics.contributions.cnaps.employerTotal, color: 'bg-blue-600' },
      { label: 'OSTIE Salarié', value: analytics.contributions.ostie.employeeTotal, color: 'bg-green-500' },
      { label: 'OSTIE Employeur', value: analytics.contributions.ostie.employerTotal, color: 'bg-green-600' }
    ];

    const salaryBreakdownData = [
      { label: 'Salaires Nets', value: analytics.payroll.totalNetSalaries, color: 'bg-green-500' },
      { label: 'Cotisations Salariales', value: analytics.payroll.totalEmployeeContributions, color: 'bg-red-500' },
      { label: 'Charges Patronales', value: analytics.payroll.totalEmployerContributions, color: 'bg-orange-500' }
    ];

    return (
      <div className="space-y-6">
        {/* KPIs principaux */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm font-medium">Masse Salariale Brute</p>
                <p className="text-3xl font-bold">{analytics.payroll.totalGrossSalaries.toLocaleString()} Ar</p>
                <p className="text-blue-100 text-sm mt-1">{analytics.payroll.employeeCount} employés</p>
              </div>
              <Users className="w-12 h-12 text-blue-200" />
            </div>
          </div>

          <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm font-medium">Salaires Nets</p>
                <p className="text-3xl font-bold">{analytics.payroll.totalNetSalaries.toLocaleString()} Ar</p>
                <p className="text-green-100 text-sm mt-1">Après cotisations</p>
              </div>
              <DollarSign className="w-12 h-12 text-green-200" />
            </div>
          </div>

          <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl p-6 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-100 text-sm font-medium">Total Cotisations</p>
                <p className="text-3xl font-bold">
                  {(analytics.payroll.totalEmployeeContributions + analytics.payroll.totalEmployerContributions).toLocaleString()} Ar
                </p>
                <p className="text-orange-100 text-sm mt-1">CNAPS + OSTIE</p>
              </div>
              <BarChart3 className="w-12 h-12 text-orange-200" />
            </div>
          </div>

          <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-6 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm font-medium">Coût Total Employeur</p>
                <p className="text-3xl font-bold">{analytics.payroll.totalEmployerCost.toLocaleString()} Ar</p>
                <p className="text-purple-100 text-sm mt-1">Salaires + Charges</p>
              </div>
              <TrendingUp className="w-12 h-12 text-purple-200" />
            </div>
          </div>
        </div>

        {/* Graphiques des cotisations */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <FinancialChart
            type="pie"
            data={contributionsData}
            title="Répartition des Cotisations CNAPS et OSTIE"
            height={300}
          />

          <FinancialChart
            type="donut"
            data={salaryBreakdownData}
            title="Répartition de la Masse Salariale"
            height={300}
          />
        </div>

        {/* Indicateurs clés */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-6">Indicateurs Clés de Performance</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{analytics.kpis.payrollRatio.toFixed(1)}%</div>
              <div className="text-sm text-gray-600">Ratio Masse Salariale</div>
              <div className="text-xs text-gray-500 mt-1">% du budget total</div>
            </div>
            
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">{analytics.kpis.contributionRatio.toFixed(1)}%</div>
              <div className="text-sm text-gray-600">Ratio Cotisations</div>
              <div className="text-xs text-gray-500 mt-1">% des salaires bruts</div>
            </div>
            
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{analytics.kpis.averageSalary.toLocaleString()} Ar</div>
              <div className="text-sm text-gray-600">Salaire Moyen</div>
              <div className="text-xs text-gray-500 mt-1">Médiane: {analytics.kpis.medianSalary.toLocaleString()} Ar</div>
            </div>
            
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">
                {analytics.kpis.salaryRange.min.toLocaleString()} - {analytics.kpis.salaryRange.max.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">Fourchette Salariale</div>
              <div className="text-xs text-gray-500 mt-1">Min - Max (Ar)</div>
            </div>
          </div>
        </div>

        {/* Projections annuelles */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-6">Projections Annuelles</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg p-4">
              <h4 className="font-medium text-blue-800 mb-2">Coût Salarial Annuel</h4>
              <p className="text-2xl font-bold text-blue-600">
                {analytics.projections.annualPayrollCost.toLocaleString()} Ar
              </p>
              <p className="text-sm text-blue-600 mt-1">
                Moyenne mensuelle: {analytics.projections.monthlyAverageExpenses.toLocaleString()} Ar
              </p>
            </div>
            
            <div className="bg-gradient-to-r from-orange-50 to-orange-100 rounded-lg p-4">
              <h4 className="font-medium text-orange-800 mb-2">Cotisations Annuelles</h4>
              <p className="text-2xl font-bold text-orange-600">
                {analytics.projections.annualContributions.toLocaleString()} Ar
              </p>
              <div className="text-xs text-orange-600 mt-1 space-y-1">
                <p>CNAPS: {(analytics.contributions.cnaps.total * 12).toLocaleString()} Ar</p>
                <p>OSTIE: {(analytics.contributions.ostie.total * 12).toLocaleString()} Ar</p>
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-lg p-4">
              <h4 className="font-medium text-purple-800 mb-2">Budget Total Annuel</h4>
              <p className="text-2xl font-bold text-purple-600">
                {(analytics.projections.annualPayrollCost + analytics.projections.annualContributions).toLocaleString()} Ar
              </p>
              <p className="text-sm text-purple-600 mt-1">
                Salaires + Charges patronales
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderPayrollReport = () => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
        <h3 className="text-lg font-bold text-gray-900">Rapport de Paie Détaillé</h3>
        <button
          onClick={handleExportPayroll}
          className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
        >
          <Download className="w-4 h-4 mr-2" />
          Exporter CSV
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Employé</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Département</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Salaire Brut</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">CNAPS</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">OSTIE</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Salaire Net</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Coût Employeur</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {payrollReport.map((report, index) => (
              <tr key={index} className="hover:bg-gray-50 transition-colors">
                <td className="py-4 px-6">
                  <div>
                    <p className="font-medium text-gray-900">{report.employee.name}</p>
                    <p className="text-sm text-gray-500">{report.employee.position}</p>
                  </div>
                </td>
                <td className="py-4 px-6">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                    {report.employee.department}
                  </span>
                </td>
                <td className="py-4 px-6">
                  <p className="font-bold text-gray-900">{report.salary.gross.toLocaleString()} Ar</p>
                </td>
                <td className="py-4 px-6">
                  <div className="text-sm space-y-1">
                    <div className="text-red-600">Salarié: -{report.cnaps.employee.toLocaleString()}</div>
                    <div className="text-orange-600">Employeur: +{report.cnaps.employer.toLocaleString()}</div>
                  </div>
                </td>
                <td className="py-4 px-6">
                  <div className="text-sm space-y-1">
                    <div className="text-red-600">Salarié: -{report.ostie.employee.toLocaleString()}</div>
                    <div className="text-orange-600">Employeur: +{report.ostie.employer.toLocaleString()}</div>
                  </div>
                </td>
                <td className="py-4 px-6">
                  <p className="font-bold text-green-600">{report.salary.net.toLocaleString()} Ar</p>
                </td>
                <td className="py-4 px-6">
                  <p className="font-bold text-purple-600">{report.salary.employerCost.toLocaleString()} Ar</p>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot className="bg-gray-100 font-bold">
            <tr>
              <td className="py-3 px-6" colSpan={2}>TOTAL</td>
              <td className="py-3 px-6">{payrollReport.reduce((sum, r) => sum + r.salary.gross, 0).toLocaleString()} Ar</td>
              <td className="py-3 px-6">{payrollReport.reduce((sum, r) => sum + r.cnaps.total, 0).toLocaleString()} Ar</td>
              <td className="py-3 px-6">{payrollReport.reduce((sum, r) => sum + r.ostie.total, 0).toLocaleString()} Ar</td>
              <td className="py-3 px-6">{payrollReport.reduce((sum, r) => sum + r.salary.net, 0).toLocaleString()} Ar</td>
              <td className="py-3 px-6">{payrollReport.reduce((sum, r) => sum + r.salary.employerCost, 0).toLocaleString()} Ar</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );

  const renderDepartments = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {departmentAnalytics.map((dept, index) => (
          <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900">{dept.department}</h3>
              <span className="text-sm text-gray-500">{dept.employeeCount} employés</span>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Salaires bruts:</span>
                <span className="font-medium">{dept.totalGrossSalaries.toLocaleString()} Ar</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Cotisations:</span>
                <span className="font-medium text-orange-600">{dept.totalContributions.toLocaleString()} Ar</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Coût total:</span>
                <span className="font-bold text-purple-600">{dept.totalEmployerCost.toLocaleString()} Ar</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Salaire moyen:</span>
                <span className="font-medium">{dept.averageSalary.toLocaleString()} Ar</span>
              </div>
              
              <div className="mt-4">
                <div className="flex justify-between text-sm mb-1">
                  <span>Part du budget</span>
                  <span>{dept.budgetPercentage.toFixed(1)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-500 h-2 rounded-full" 
                    style={{ width: `${Math.min(dept.budgetPercentage, 100)}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderCompliance = () => {
    if (!complianceReport) return null;

    const getComplianceColor = (compliance: string) => {
      switch (compliance) {
        case 'compliant': return 'text-green-600 bg-green-50 border-green-200';
        case 'warning': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
        case 'non_compliant': return 'text-red-600 bg-red-50 border-red-200';
        default: return 'text-gray-600 bg-gray-50 border-gray-200';
      }
    };

    const getComplianceIcon = (compliance: string) => {
      switch (compliance) {
        case 'compliant': return <CheckCircle className="w-5 h-5" />;
        case 'warning': return <AlertTriangle className="w-5 h-5" />;
        case 'non_compliant': return <AlertTriangle className="w-5 h-5" />;
        default: return <Info className="w-5 h-5" />;
      }
    };

    return (
      <div className="space-y-6">
        {/* Score global de conformité */}
        <div className={`rounded-xl p-6 border ${getComplianceColor(complianceReport.overall.compliance)}`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              {getComplianceIcon(complianceReport.overall.compliance)}
              <h3 className="text-xl font-bold">Conformité Globale</h3>
            </div>
            <div className="text-3xl font-bold">{complianceReport.overall.score}/100</div>
          </div>
          
          {complianceReport.overall.recommendations.length > 0 && (
            <div>
              <h4 className="font-medium mb-2">Recommandations:</h4>
              <ul className="list-disc pl-5 space-y-1 text-sm">
                {complianceReport.overall.recommendations.map((rec: string, index: number) => (
                  <li key={index}>{rec}</li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Détail CNAPS et OSTIE */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* CNAPS */}
          <div className={`rounded-xl p-6 border ${getComplianceColor(complianceReport.cnaps.compliance)}`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold">CNAPS</h3>
              <div className="flex items-center space-x-2">
                {getComplianceIcon(complianceReport.cnaps.compliance)}
                <span className="text-sm font-medium">
                  {complianceReport.cnaps.compliance === 'compliant' ? 'Conforme' : 
                   complianceReport.cnaps.compliance === 'warning' ? 'Attention' : 'Non conforme'}
                </span>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="font-medium">Taux Actuel:</p>
                  <p>Salarié: {complianceReport.cnaps.currentRates.employee}%</p>
                  <p>Employeur: {complianceReport.cnaps.currentRates.employer}%</p>
                </div>
                <div>
                  <p className="font-medium">Taux Recommandé:</p>
                  <p>Salarié: {complianceReport.cnaps.recommendedRates.employee}%</p>
                  <p>Employeur: {complianceReport.cnaps.recommendedRates.employer}%</p>
                </div>
              </div>
              
              {complianceReport.cnaps.issues.length > 0 && (
                <div>
                  <h5 className="font-medium mb-1">Problèmes détectés:</h5>
                  <ul className="list-disc pl-5 space-y-1 text-sm">
                    {complianceReport.cnaps.issues.map((issue: string, index: number) => (
                      <li key={index}>{issue}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* OSTIE */}
          <div className={`rounded-xl p-6 border ${getComplianceColor(complianceReport.ostie.compliance)}`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold">OSTIE</h3>
              <div className="flex items-center space-x-2">
                {getComplianceIcon(complianceReport.ostie.compliance)}
                <span className="text-sm font-medium">
                  {complianceReport.ostie.compliance === 'compliant' ? 'Conforme' : 
                   complianceReport.ostie.compliance === 'warning' ? 'Attention' : 'Non conforme'}
                </span>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="font-medium">Taux Actuel:</p>
                  <p>Salarié: {complianceReport.ostie.currentRates.employee}%</p>
                  <p>Employeur: {complianceReport.ostie.currentRates.employer}%</p>
                </div>
                <div>
                  <p className="font-medium">Taux Recommandé:</p>
                  <p>Salarié: {complianceReport.ostie.recommendedRates.employee}%</p>
                  <p>Employeur: {complianceReport.ostie.recommendedRates.employer}%</p>
                </div>
              </div>
              
              {complianceReport.ostie.issues.length > 0 && (
                <div>
                  <h5 className="font-medium mb-1">Problèmes détectés:</h5>
                  <ul className="list-disc pl-5 space-y-1 text-sm">
                    {complianceReport.ostie.issues.map((issue: string, index: number) => (
                      <li key={index}>{issue}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement des analyses financières...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <p className="text-red-600">Erreur: {error}</p>
        <button 
          onClick={loadAnalytics} 
          className="mt-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
        >
          Réessayer
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Analyses Financières</h1>
          <p className="text-gray-600">Rapports détaillés avec cotisations OSTIE et CNAPS</p>
        </div>
        
        <div className="flex gap-2">
          <button 
            onClick={() => setShowComplianceModal(true)}
            className="inline-flex items-center px-4 py-2 border border-blue-300 text-blue-700 rounded-lg hover:bg-blue-50 transition-colors"
          >
            <CheckCircle className="w-4 h-4 mr-2" />
            Conformité
          </button>
          <button 
            onClick={handleExportAnalytics}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Download className="w-4 h-4 mr-2" />
            Exporter
          </button>
        </div>
      </div>

      {/* Contrôles de période et vue */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col sm:flex-row gap-4 items-center">
          <div className="flex gap-2">
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="current_month">Ce mois</option>
              <option value="last_month">Mois dernier</option>
              <option value="current_quarter">Ce trimestre</option>
              <option value="current_year">Cette année</option>
            </select>
          </div>
          
          <div className="flex border border-gray-300 rounded-lg overflow-hidden">
            <button
              onClick={() => setViewMode('overview')}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                viewMode === 'overview' 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              Vue d'ensemble
            </button>
            <button
              onClick={() => setViewMode('payroll')}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                viewMode === 'payroll' 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              Rapport de Paie
            </button>
            <button
              onClick={() => setViewMode('departments')}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                viewMode === 'departments' 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              Par Département
            </button>
            <button
              onClick={() => setViewMode('compliance')}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                viewMode === 'compliance' 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              Conformité
            </button>
          </div>
        </div>
      </div>

      {/* Contenu selon la vue */}
      {viewMode === 'overview' && renderOverview()}
      {viewMode === 'payroll' && renderPayrollReport()}
      {viewMode === 'departments' && renderDepartments()}
      {viewMode === 'compliance' && renderCompliance()}

      {/* Modal de conformité */}
      <Modal
        isOpen={showComplianceModal}
        onClose={() => setShowComplianceModal(false)}
        title="Rapport de Conformité Détaillé"
        size="xl"
      >
        {renderCompliance()}
      </Modal>
    </div>
  );
}