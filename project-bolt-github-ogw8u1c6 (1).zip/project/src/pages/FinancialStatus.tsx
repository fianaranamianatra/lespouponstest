import React, { useState } from 'react';
import { TrendingUp, TrendingDown, DollarSign, PieChart, BarChart3, Calendar, Download, Filter, CreditCard, Wallet, Building, Target } from 'lucide-react';
import { FinancialChart } from '../components/charts/FinancialChart';
import { TrendChart } from '../components/charts/TrendChart';

interface FinancialData {
  totalRevenue: number;
  totalExpenses: number;
  currentBalance: number;
  monthlyRevenue: number;
  monthlyExpenses: number;
  yearlyRevenue: number;
  yearlyExpenses: number;
  pendingPayments: number;
  overduePayments: number;
}

interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  reference?: string;
}

interface BudgetCategory {
  name: string;
  budgeted: number;
  actual: number;
  percentage: number;
  color: string;
}

const mockFinancialData: FinancialData = {
  totalRevenue: 19500000, // 39 élèves × 500,000 Ar
  totalExpenses: 8750000,
  currentBalance: 10750000,
  monthlyRevenue: 6500000,
  monthlyExpenses: 2916667,
  yearlyRevenue: 78000000, // Projection annuelle
  yearlyExpenses: 35000000,
  pendingPayments: 2500000,
  overduePayments: 1500000
};

const mockTransactions: Transaction[] = [
  {
    id: '1',
    date: '2024-11-20',
    description: 'Écolage TPSA - Novembre',
    amount: 6500000,
    type: 'income',
    category: 'Écolage',
    reference: 'ECO-NOV-2024'
  },
  {
    id: '2',
    date: '2024-11-19',
    description: 'Salaires Enseignants',
    amount: -2500000,
    type: 'expense',
    category: 'Personnel',
    reference: 'SAL-NOV-2024'
  },
  {
    id: '3',
    date: '2024-11-18',
    description: 'Fournitures Scolaires',
    amount: -350000,
    type: 'expense',
    category: 'Matériel',
    reference: 'MAT-NOV-2024'
  },
  {
    id: '4',
    date: '2024-11-17',
    description: 'Frais d\'inscription',
    amount: 1950000,
    type: 'income',
    category: 'Inscriptions',
    reference: 'INS-NOV-2024'
  },
  {
    id: '5',
    date: '2024-11-16',
    description: 'Électricité et Eau',
    amount: -180000,
    type: 'expense',
    category: 'Utilities',
    reference: 'UTI-NOV-2024'
  }
];

const budgetCategories: BudgetCategory[] = [
  {
    name: 'Personnel',
    budgeted: 3000000,
    actual: 2500000,
    percentage: 83.3,
    color: 'bg-blue-500'
  },
  {
    name: 'Matériel',
    budgeted: 500000,
    actual: 350000,
    percentage: 70,
    color: 'bg-green-500'
  },
  {
    name: 'Utilities',
    budgeted: 250000,
    actual: 180000,
    percentage: 72,
    color: 'bg-yellow-500'
  },
  {
    name: 'Maintenance',
    budgeted: 300000,
    actual: 120000,
    percentage: 40,
    color: 'bg-purple-500'
  },
  {
    name: 'Administration',
    budgeted: 200000,
    actual: 150000,
    percentage: 75,
    color: 'bg-orange-500'
  }
];

// Données pour les graphiques
const monthlyTrendData = [
  { period: 'Jan', value: 18500000, change: 5.2 },
  { period: 'Fév', value: 19200000, change: 3.8 },
  { period: 'Mar', value: 18800000, change: -2.1 },
  { period: 'Avr', value: 19500000, change: 3.7 },
  { period: 'Mai', value: 20100000, change: 3.1 },
  { period: 'Jun', value: 19800000, change: -1.5 },
  { period: 'Jul', value: 20500000, change: 3.5 },
  { period: 'Aoû', value: 21200000, change: 3.4 },
  { period: 'Sep', value: 20800000, change: -1.9 },
  { period: 'Oct', value: 21500000, change: 3.4 },
  { period: 'Nov', value: 19500000, change: -9.3 }
];

const expensesTrendData = [
  { period: 'Jan', value: 8200000, change: 2.1 },
  { period: 'Fév', value: 8400000, change: 2.4 },
  { period: 'Mar', value: 8100000, change: -3.6 },
  { period: 'Avr', value: 8300000, change: 2.5 },
  { period: 'Mai', value: 8600000, change: 3.6 },
  { period: 'Jun', value: 8500000, change: -1.2 },
  { period: 'Jul', value: 8800000, change: 3.5 },
  { period: 'Aoû', value: 9100000, change: 3.4 },
  { period: 'Sep', value: 8900000, change: -2.2 },
  { period: 'Oct', value: 9200000, change: 3.4 },
  { period: 'Nov', value: 8750000, change: -4.9 }
];

const revenueBySourceData = [
  { label: 'Écolage TPSA', value: 19500000, color: 'bg-blue-500' },
  { label: 'Frais Inscription', value: 1950000, color: 'bg-green-500' },
  { label: 'Activités Extra', value: 780000, color: 'bg-purple-500' },
  { label: 'Cantine', value: 650000, color: 'bg-orange-500' },
  { label: 'Transport', value: 520000, color: 'bg-yellow-500' }
];

const expensesByCategoryData = [
  { label: 'Personnel', value: 2500000, color: 'bg-red-500' },
  { label: 'Fournitures', value: 350000, color: 'bg-orange-500' },
  { label: 'Utilities', value: 180000, color: 'bg-yellow-500' },
  { label: 'Maintenance', value: 120000, color: 'bg-purple-500' },
  { label: 'Administration', value: 150000, color: 'bg-blue-500' },
  { label: 'Transport', value: 200000, color: 'bg-green-500' }
];

const cashFlowData = [
  { label: 'Entrées', value: 19500000, color: 'bg-green-500' },
  { label: 'Sorties', value: 8750000, color: 'bg-red-500' },
  { label: 'Solde Net', value: 10750000, color: 'bg-blue-500' }
];

const quarterlyPerformanceData = [
  { period: 'Q1 2024', value: 85.2, change: 5.1 },
  { period: 'Q2 2024', value: 88.7, change: 4.1 },
  { period: 'Q3 2024', value: 91.3, change: 2.9 },
  { period: 'Q4 2024', value: 89.8, change: -1.6 }
];

export function FinancialStatus() {
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [viewMode, setViewMode] = useState<'overview' | 'transactions' | 'budget'>('overview');

  const filteredTransactions = mockTransactions.filter(transaction => {
    const matchesCategory = selectedCategory === '' || transaction.category === selectedCategory;
    return matchesCategory;
  });

  const categories = [...new Set(mockTransactions.map(t => t.category))];

  const handleExport = () => {
    alert('Export de l\'état financier en cours...');
  };

  const handleGenerateReport = () => {
    alert('Génération du rapport financier en cours...');
  };

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm font-medium">Solde Actuel</p>
              <p className="text-3xl font-bold">{mockFinancialData.currentBalance.toLocaleString()} Ar</p>
              <p className="text-green-100 text-sm mt-1">
                +{((mockFinancialData.currentBalance / mockFinancialData.totalRevenue) * 100).toFixed(1)}% du CA
              </p>
            </div>
            <Wallet className="w-12 h-12 text-green-200" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm font-medium">Revenus Totaux</p>
              <p className="text-3xl font-bold">{mockFinancialData.totalRevenue.toLocaleString()} Ar</p>
              <p className="text-blue-100 text-sm mt-1 flex items-center">
                <TrendingUp className="w-4 h-4 mr-1" />
                +15.2% ce mois
              </p>
            </div>
            <TrendingUp className="w-12 h-12 text-blue-200" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-red-100 text-sm font-medium">Dépenses Totales</p>
              <p className="text-3xl font-bold">{mockFinancialData.totalExpenses.toLocaleString()} Ar</p>
              <p className="text-red-100 text-sm mt-1 flex items-center">
                <TrendingDown className="w-4 h-4 mr-1" />
                -8.5% ce mois
              </p>
            </div>
            <TrendingDown className="w-12 h-12 text-red-200" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm font-medium">Marge Bénéficiaire</p>
              <p className="text-3xl font-bold">
                {((mockFinancialData.currentBalance / mockFinancialData.totalRevenue) * 100).toFixed(1)}%
              </p>
              <p className="text-purple-100 text-sm mt-1">Très bonne santé</p>
            </div>
            <Target className="w-12 h-12 text-purple-200" />
          </div>
        </div>
      </div>

      {/* Charts and Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenus vs Dépenses - Graphique en barres */}
        <FinancialChart
          type="bar"
          data={cashFlowData}
          title="Flux de Trésorerie"
          height={250}
        />

        {/* Répartition des Revenus - Graphique en secteurs */}
        <FinancialChart
          type="pie"
          data={revenueBySourceData}
          title="Répartition des Revenus"
          height={250}
        />
      </div>

      {/* Graphiques de Tendances */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Évolution des Revenus */}
        <TrendChart
          data={monthlyTrendData}
          title="Évolution des Revenus Mensuels"
          color="green"
          format="currency"
          height={250}
        />

        {/* Évolution des Dépenses */}
        <TrendChart
          data={expensesTrendData}
          title="Évolution des Dépenses Mensuels"
          color="red"
          format="currency"
          height={250}
        />
      </div>

      {/* Graphiques Détaillés */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Dépenses par Catégorie - Donut */}
        <FinancialChart
          type="donut"
          data={expensesByCategoryData}
          title="Dépenses par Catégorie"
          height={300}
        />

        {/* Performance Trimestrielle */}
        <TrendChart
          data={quarterlyPerformanceData}
          title="Performance Trimestrielle"
          color="purple"
          format="percentage"
          height={300}
        />

        {/* Évolution du Solde */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-gray-900">Indicateurs Clés</h3>
            <Target className="w-5 h-5 text-gray-400" />
          </div>
          
          <div className="space-y-6">
            {/* Ratio de Liquidité */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-600">Ratio de Liquidité</span>
                <span className="text-sm font-bold text-blue-600">2.23</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-500 h-2 rounded-full" style={{ width: '89%' }}></div>
              </div>
              <p className="text-xs text-gray-500 mt-1">Excellent (&gt;2.0)</p>
              <p className="text-xs text-gray-500 mt-1">{"Excellent (>2.0)"}</p>
            </div>

            {/* Marge Bénéficiaire */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-600">Marge Bénéficiaire</span>
                <span className="text-sm font-bold text-green-600">55.1%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-green-500 h-2 rounded-full" style={{ width: '55%' }}></div>
              </div>
              <p className="text-xs text-gray-500 mt-1">Très bon (&gt;50%)</p>
              <p className="text-xs text-gray-500 mt-1">{"Très bon (>50%)"}</p>
            </div>

            {/* Croissance Annuelle */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-600">Croissance Annuelle</span>
                <span className="text-sm font-bold text-purple-600">+12.5%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-purple-500 h-2 rounded-full" style={{ width: '62%' }}></div>
              </div>
              <p className="text-xs text-gray-500 mt-1">Objectif: +20%</p>
            </div>

            {/* Efficacité Opérationnelle */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-600">Efficacité Opérationnelle</span>
                <span className="text-sm font-bold text-orange-600">87.3%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-orange-500 h-2 rounded-full" style={{ width: '87%' }}></div>
              </div>
              <p className="text-xs text-gray-500 mt-1">Bon (&gt;80%)</p>
              <p className="text-xs text-gray-500 mt-1">{"Bon (>80%)"}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Status */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-6">État des Paiements</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center p-4 bg-yellow-50 rounded-lg">
            <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <CreditCard className="w-6 h-6 text-yellow-600" />
            </div>
            <p className="text-sm font-medium text-gray-600">Paiements en Attente</p>
            <p className="text-2xl font-bold text-yellow-600">
              {mockFinancialData.pendingPayments.toLocaleString()} Ar
            </p>
            <p className="text-xs text-gray-500 mt-1">5 élèves</p>
          </div>
          
          <div className="text-center p-4 bg-red-50 rounded-lg">
            <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <Building className="w-6 h-6 text-red-600" />
            </div>
            <p className="text-sm font-medium text-gray-600">Paiements en Retard</p>
            <p className="text-2xl font-bold text-red-600">
              {mockFinancialData.overduePayments.toLocaleString()} Ar
            </p>
            <p className="text-xs text-gray-500 mt-1">3 élèves</p>
          </div>
          
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
            <p className="text-sm font-medium text-gray-600">Taux de Collecte</p>
            <p className="text-2xl font-bold text-green-600">
              {mockFinancialData.totalRevenue > 0 ? 
                ((mockFinancialData.totalRevenue / (mockFinancialData.totalRevenue + mockFinancialData.pendingPayments + mockFinancialData.overduePayments)) * 100).toFixed(1) 
                : '0.0'}%
            </p>
            <p className="text-xs text-gray-500 mt-1">Excellent</p>
          </div>
        </div>
      </div>
    </div>
  );

  const renderTransactions = () => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200">
        <h3 className="text-lg font-bold text-gray-900">Transactions Récentes</h3>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Date</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Description</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Catégorie</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Montant</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Référence</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredTransactions.map((transaction) => (
              <tr key={transaction.id} className="hover:bg-gray-50 transition-colors">
                <td className="py-4 px-6">
                  <div className="flex items-center text-sm text-gray-900">
                    <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                    {new Date(transaction.date).toLocaleDateString('fr-FR')}
                  </div>
                </td>
                <td className="py-4 px-6">
                  <p className="font-medium text-gray-900">{transaction.description}</p>
                </td>
                <td className="py-4 px-6">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    transaction.type === 'income' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {transaction.category}
                  </span>
                </td>
                <td className="py-4 px-6">
                  <span className={`font-bold ${
                    transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {transaction.type === 'income' ? '+' : ''}{transaction.amount.toLocaleString()} Ar
                  </span>
                </td>
                <td className="py-4 px-6">
                  <span className="text-sm text-gray-500">{transaction.reference}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderBudget = () => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-bold text-gray-900">Suivi Budgétaire</h3>
        <PieChart className="w-5 h-5 text-gray-400" />
      </div>
      
      <div className="space-y-6">
        {budgetCategories.map((category, index) => (
          <div key={index} className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-medium text-gray-900">{category.name}</span>
              <span className="text-sm text-gray-600">
                {category.actual.toLocaleString()} / {category.budgeted.toLocaleString()} Ar
              </span>
            </div>
            
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div 
                className={`h-3 rounded-full ${category.color}`}
                style={{ width: `${Math.min(category.percentage, 100)}%` }}
              ></div>
            </div>
            
            <div className="flex items-center justify-between text-xs">
              <span className={`font-medium ${
                category.percentage > 100 ? 'text-red-600' : 
                category.percentage > 80 ? 'text-yellow-600' : 'text-green-600'
              }`}>
                {category.percentage.toFixed(1)}% utilisé
              </span>
              <span className="text-gray-500">
                Reste: {(category.budgeted - category.actual).toLocaleString()} Ar
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">État Financier</h1>
          <p className="text-gray-600">Suivi de la santé financière de l'école</p>
        </div>
        
        <div className="flex gap-2">
          <button 
            onClick={handleGenerateReport}
            className="inline-flex items-center px-4 py-2 border border-blue-300 text-blue-700 rounded-lg hover:bg-blue-50 transition-colors"
          >
            <BarChart3 className="w-4 h-4 mr-2" />
            Rapport
          </button>
          <button 
            onClick={handleExport}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Download className="w-4 h-4 mr-2" />
            Exporter
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col sm:flex-row gap-4 items-center">
          <div className="flex border border-gray-300 rounded-lg overflow-hidden">
            <button
              onClick={() => setViewMode('overview')}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                viewMode === 'overview' 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              Vue d'ensemble
            </button>
            <button
              onClick={() => setViewMode('transactions')}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                viewMode === 'transactions' 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              Transactions
            </button>
            <button
              onClick={() => setViewMode('budget')}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                viewMode === 'budget' 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              Budget
            </button>
          </div>
          
          <div className="flex gap-2">
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="week">Cette semaine</option>
              <option value="month">Ce mois</option>
              <option value="quarter">Ce trimestre</option>
              <option value="year">Cette année</option>
            </select>
            
            {viewMode === 'transactions' && (
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Toutes les catégories</option>
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            )}
            
            <button className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Filter className="w-4 h-4 mr-2" />
              Filtres
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      {viewMode === 'overview' && renderOverview()}
      {viewMode === 'transactions' && renderTransactions()}
      {viewMode === 'budget' && renderBudget()}
    </div>
  );
}