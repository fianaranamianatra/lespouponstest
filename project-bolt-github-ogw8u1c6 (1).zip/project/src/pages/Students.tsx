import React, { useState } from 'react';
import { Search, Plus, Filter, Edit, Trash2, Eye, Users, Calendar, MapPin, Phone, FileText } from 'lucide-react';
import { Modal } from '../components/Modal';
import { StudentForm } from '../components/forms/StudentForm';
import { CertificateModal } from '../components/certificates/CertificateModal';
import { Avatar } from '../components/Avatar';

interface Student {
  id: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  class: string;
  address: string;
  phone: string;
  parentName: string;
  status: 'active' | 'inactive';
  avatar?: string;
}

// Données vides - prêt pour l'ajout de nouveaux élèves
const mockStudents: Student[] = [
  // Élèves de la classe TPSA
  {
    id: '1',
    firstName: 'Djannel',
    lastName: 'ANDRIASOLOMALALA',
    dateOfBirth: '2021-03-15',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 12 345 67',
    parentName: 'M. ANDRIASOLOMALALA',
    parentEmail: 'andriasolomalala@email.mg',
    status: 'active'
  },
  {
    id: '2',
    firstName: 'Fitahiana Alma',
    lastName: 'ANDRIANARISON',
    dateOfBirth: '2021-05-20',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 23 456 78',
    parentName: 'Mme ANDRIANARISON',
    parentEmail: 'andrianarison@email.mg',
    status: 'active'
  },
  {
    id: '3',
    firstName: 'Venot Brivael',
    lastName: 'RANANDRIARIJAONA',
    dateOfBirth: '2021-07-10',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 34 567 89',
    parentName: 'M. RANANDRIARIJAONA',
    parentEmail: 'ranandriarijaona@email.mg',
    status: 'active'
  },
  {
    id: '4',
    firstName: 'Ange Chloé',
    lastName: 'RAKOTOHARISON',
    dateOfBirth: '2021-04-25',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 45 678 90',
    parentName: 'Mme RAKOTOHARISON',
    parentEmail: 'rakotoharison@email.mg',
    status: 'active'
  },
  {
    id: '5',
    firstName: 'Eunice',
    lastName: 'TIVERNE',
    dateOfBirth: '2021-06-12',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 56 789 01',
    parentName: 'M. TIVERNE',
    parentEmail: 'tiverne@email.mg',
    status: 'active'
  },
  {
    id: '6',
    firstName: 'Jordi',
    lastName: 'MAMINIAINA',
    dateOfBirth: '2021-08-03',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 67 890 12',
    parentName: 'Mme MAMINIAINA',
    parentEmail: 'maminiaina@email.mg',
    status: 'active'
  },
  {
    id: '7',
    firstName: 'Nayaar Désiré',
    lastName: 'NARIVONY',
    dateOfBirth: '2021-02-18',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 78 901 23',
    parentName: 'M. NARIVONY',
    parentEmail: 'narivony@email.mg',
    status: 'active'
  },
  {
    id: '8',
    firstName: 'Fatema',
    lastName: 'KYARA',
    dateOfBirth: '2021-09-07',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 89 012 34',
    parentName: 'Mme KYARA',
    parentEmail: 'kyara@email.mg',
    status: 'active'
  },
  {
    id: '9',
    firstName: 'Nomentsoa Tiavina Landry',
    lastName: 'RALANTONIAINA',
    dateOfBirth: '2021-01-30',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 90 123 45',
    parentName: 'M. RALANTONIAINA',
    parentEmail: 'ralantoniaina@email.mg',
    status: 'active'
  },
  {
    id: '10',
    firstName: 'Laureine Djillarsy',
    lastName: 'SOANOMENY',
    dateOfBirth: '2021-11-14',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 01 234 56',
    parentName: 'Mme SOANOMENY',
    parentEmail: 'soanomeny@email.mg',
    status: 'active'
  },
  {
    id: '11',
    firstName: 'Kanto Juvin',
    lastName: 'SOAFALY',
    dateOfBirth: '2021-12-05',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 12 345 67',
    parentName: 'M. SOAFALY',
    parentEmail: 'soafaly@email.mg',
    status: 'active'
  },
  {
    id: '12',
    firstName: 'Gomez Mahafalindrainy',
    lastName: 'ELENA',
    dateOfBirth: '2021-10-22',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 23 456 78',
    parentName: 'Mme ELENA',
    parentEmail: 'elena@email.mg',
    status: 'active'
  },
  {
    id: '13',
    firstName: 'Janne Crystal Miadantsoa',
    lastName: 'MONJA FLORES',
    dateOfBirth: '2021-04-08',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 34 567 89',
    parentName: 'M. MONJA FLORES',
    parentEmail: 'monjaflores@email.mg',
    status: 'active'
  },
  {
    id: '14',
    firstName: 'Florence Abbigael Abil',
    lastName: 'TANTELY',
    dateOfBirth: '2021-06-16',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 45 678 90',
    parentName: 'Mme TANTELY (Institutrice)',
    parentEmail: 'tantely@email.mg',
    status: 'active'
  },
  {
    id: '15',
    firstName: 'Théoden Rubis',
    lastName: 'FANOMEZANTSOA',
    dateOfBirth: '2021-08-11',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 56 789 01',
    parentName: 'M. FANOMEZANTSOA',
    parentEmail: 'fanomezantsoa@email.mg',
    status: 'active'
  },
  {
    id: '16',
    firstName: 'Quirao Solaya Volatiana',
    lastName: 'TAMASY',
    dateOfBirth: '2021-03-28',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 67 890 12',
    parentName: 'Mme TAMASY',
    parentEmail: 'tamasy@email.mg',
    status: 'active'
  },
  {
    id: '17',
    firstName: 'Marie Yoline',
    lastName: 'MAMELOMANA',
    dateOfBirth: '2021-07-19',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 78 901 23',
    parentName: 'M. MAMELOMANA',
    parentEmail: 'mamelomana@email.mg',
    status: 'active'
  },
  {
    id: '18',
    firstName: 'Marie Sylvana',
    lastName: 'NOMENJANAHARY',
    dateOfBirth: '2021-05-04',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 89 012 34',
    parentName: 'Mme NOMENJANAHARY',
    parentEmail: 'nomenjanahary@email.mg',
    status: 'active'
  },
  {
    id: '19',
    firstName: 'Ileriche Freddy',
    lastName: 'RASOLOARIJAONA',
    dateOfBirth: '2021-09-13',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 90 123 45',
    parentName: 'M. RASOLOARIJAONA',
    parentEmail: 'rasoloarijaona@email.mg',
    status: 'active'
  },
  {
    id: '20',
    firstName: 'Mandresy Elu',
    lastName: 'THEODOLINE',
    dateOfBirth: '2021-11-26',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 01 234 56',
    parentName: 'Mme THEODOLINE',
    parentEmail: 'theodoline@email.mg',
    status: 'active'
  },
  {
    id: '21',
    firstName: 'Arse-Sunni Ismael',
    lastName: 'RAVELOMIHAJA',
    dateOfBirth: '2021-02-09',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 12 345 67',
    parentName: 'M. RAVELOMIHAJA',
    parentEmail: 'ravelomihaja@email.mg',
    status: 'active'
  },
  {
    id: '22',
    firstName: 'Ilyan Raphael',
    lastName: 'RAZAFINDRAZAKA',
    dateOfBirth: '2021-12-17',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 23 456 78',
    parentName: 'Mme RAZAFINDRAZAKA',
    parentEmail: 'razafindrazaka@email.mg',
    status: 'active'
  },
  {
    id: '23',
    firstName: 'Anjaratiana Florentina',
    lastName: 'HENDRY',
    dateOfBirth: '2021-04-01',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 34 567 89',
    parentName: 'M. HENDRY',
    parentEmail: 'hendry@email.mg',
    status: 'active'
  },
  {
    id: '24',
    firstName: 'Nathan',
    lastName: 'RAZAFINDRAINIBE',
    dateOfBirth: '2021-06-23',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 45 678 90',
    parentName: 'Mme RAZAFINDRAINIBE',
    parentEmail: 'razafindrainibe@email.mg',
    status: 'active'
  },
  {
    id: '25',
    firstName: 'Nirina Divalciah',
    lastName: 'SANTATRA',
    dateOfBirth: '2021-08-06',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 56 789 01',
    parentName: 'M. SANTATRA',
    parentEmail: 'santatra@email.mg',
    status: 'active'
  },
  {
    id: '26',
    firstName: 'Ratianjanahary Velomamy',
    lastName: 'MASINA',
    dateOfBirth: '2021-10-14',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 67 890 12',
    parentName: 'Mme MASINA',
    parentEmail: 'masina@email.mg',
    status: 'active'
  },
  {
    id: '27',
    firstName: 'Chrishina Jeannine Hayeckel',
    lastName: 'SOAVINIRINA',
    dateOfBirth: '2021-01-21',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 78 901 23',
    parentName: 'M. SOAVINIRINA',
    parentEmail: 'soavinirina@email.mg',
    status: 'active'
  },
  {
    id: '28',
    firstName: 'Rerifio Le Bravo',
    lastName: 'MAHAVITA',
    dateOfBirth: '2021-03-07',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 89 012 34',
    parentName: 'Mme MAHAVITA',
    parentEmail: 'mahavita@email.mg',
    status: 'active'
  },
  {
    id: '29',
    firstName: 'Ny Aina Fitia',
    lastName: 'RAMBALO',
    dateOfBirth: '2021-05-15',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 90 123 45',
    parentName: 'M. RAMBALO',
    parentEmail: 'rambalo@email.mg',
    status: 'active'
  },
  {
    id: '30',
    firstName: 'Princy Gregory',
    lastName: 'ANDRIANANTENAINA',
    dateOfBirth: '2021-07-02',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 01 234 56',
    parentName: 'Mme ANDRIANANTENAINA',
    parentEmail: 'andrianantenaina@email.mg',
    status: 'active'
  },
  {
    id: '31',
    firstName: 'Matthieu Gilbor',
    lastName: 'RAFIRINGA',
    dateOfBirth: '2021-09-18',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 12 345 67',
    parentName: 'M. RAFIRINGA',
    parentEmail: 'rafiringa@email.mg',
    status: 'active'
  },
  {
    id: '32',
    firstName: 'Fitiavana Rhéane',
    lastName: 'RAKOTONDRABE',
    dateOfBirth: '2021-11-03',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 23 456 78',
    parentName: 'Mme RAKOTONDRABE',
    parentEmail: 'rakotondrabe@email.mg',
    status: 'active'
  },
  {
    id: '33',
    firstName: 'Valérie Pépin',
    lastName: 'RAKOTOARISON',
    dateOfBirth: '2021-12-20',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 34 567 89',
    parentName: 'M. RAKOTOARISON',
    parentEmail: 'rakotoarison@email.mg',
    status: 'active'
  },
  {
    id: '34',
    firstName: 'Jade Martina',
    lastName: 'RICHARD',
    dateOfBirth: '2021-02-25',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 45 678 90',
    parentName: 'Mme RICHARD',
    parentEmail: 'richard@email.mg',
    status: 'active'
  },
  {
    id: '35',
    firstName: 'Avo Juliardhino',
    lastName: 'RAZAFITSAGNILO',
    dateOfBirth: '2021-04-12',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 56 789 01',
    parentName: 'M. RAZAFITSAGNILO',
    parentEmail: 'razafitsagnilo@email.mg',
    status: 'active'
  },
  {
    id: '36',
    firstName: 'Ribervol Enzo Lyvanot',
    lastName: 'AH BAKAR',
    dateOfBirth: '2021-06-29',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 67 890 12',
    parentName: 'Mme AH BAKAR',
    parentEmail: 'ahbakar@email.mg',
    status: 'active'
  },
  {
    id: '37',
    firstName: 'Melissa Anna',
    lastName: 'TOURNIER',
    dateOfBirth: '2021-08-16',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 78 901 23',
    parentName: 'M. TOURNIER',
    parentEmail: 'tournier@email.mg',
    status: 'active'
  },
  {
    id: '38',
    firstName: 'Myryam',
    lastName: 'MANSOUR',
    dateOfBirth: '2021-10-04',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 89 012 34',
    parentName: 'Mme MANSOUR',
    parentEmail: 'mansour@email.mg',
    status: 'active'
  },
  {
    id: '39',
    firstName: 'Lucienne Rossia',
    lastName: 'HINOATSY',
    dateOfBirth: '2021-01-11',
    class: 'TPSA',
    address: 'Antananarivo, Madagascar',
    phone: '+261 34 90 123 45',
    parentName: 'M. HINOATSY',
    parentEmail: 'hinoatsy@email.mg',
    status: 'active'
  }
];

export function Students() {
  const [students, setStudents] = useState<Student[]>(mockStudents);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showCertificateModal, setShowCertificateModal] = useState(false);
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);

  const filteredStudents = students.filter(student => {
    const matchesSearch = student.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         student.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         student.class.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClass = selectedClass === '' || student.class === selectedClass;
    return matchesSearch && matchesClass;
  });

  const classes = [...new Set(students.map(s => s.class))];

  const handleAddStudent = (data: any) => {
    const newStudent: Student = {
      id: Date.now().toString(),
      firstName: data.firstName || 'Prénom',
      lastName: data.lastName || 'Nom',
      dateOfBirth: data.dateOfBirth || new Date().toISOString().split('T')[0],
      class: data.class || 'TPSA',
      address: data.address || 'Adresse inconnue',
      phone: data.phone || '+261 34 00 000 00',
      parentName: data.parentName || 'Parent inconnu',
      parentEmail: data.parentEmail || 'email@exemple.mg',
      status: data.status || 'active',
      ...data
    };
    setStudents([...students, newStudent]);
    setShowAddForm(false);
  };

  const handleEditStudent = (data: any) => {
    if (selectedStudent) {
      setStudents(students.map(s => 
        s.id === selectedStudent.id ? { ...s, ...data } : s
      ));
      setShowEditForm(false);
      setSelectedStudent(null);
    }
  };

  const handleDeleteStudent = (id: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet élève ?')) {
      setStudents(students.filter(s => s.id !== id));
    }
  };

  const handleViewStudent = (student: Student) => {
    setSelectedStudent(student);
    setShowViewModal(true);
  };

  const handleEditClick = (student: Student) => {
    setSelectedStudent(student);
    setShowEditForm(true);
  };

  const handleGenerateCertificate = (student: Student) => {
    setSelectedStudent(student);
    setShowCertificateModal(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Gestion des Élèves</h1>
          <p className="text-gray-600">Gérez les informations des élèves de l'école</p>
        </div>
        
        <button
          onClick={() => setShowAddForm(true)}
          className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4 mr-2" />
          Ajouter un Élève
        </button>
      </div>

      {/* Filters and Search */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Rechercher un élève..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="flex gap-2">
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Toutes les classes</option>
              {classes.map(className => (
                <option key={className} value={className}>{className}</option>
              ))}
            </select>
            
            <button className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Filter className="w-4 h-4 mr-2" />
              Filtres
            </button>
          </div>
        </div>
      </div>

      {/* Students Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Élèves</p>
              <p className="text-2xl font-bold text-gray-900">{students.length}</p>
            </div>
            <Users className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Actifs</p>
              <p className="text-2xl font-bold text-green-600">{students.filter(s => s.status === 'active').length}</p>
            </div>
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              <div className="w-3 h-3 bg-green-600 rounded-full"></div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Inactifs</p>
              <p className="text-2xl font-bold text-orange-600">{students.filter(s => s.status === 'inactive').length}</p>
            </div>
            <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
              <div className="w-3 h-3 bg-orange-600 rounded-full"></div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Classes</p>
              <p className="text-2xl font-bold text-purple-600">{classes.length}</p>
            </div>
            <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
              <div className="w-3 h-3 bg-purple-600 rounded-full"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Students Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        {students.length === 0 ? (
          <div className="text-center py-12">
            <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun élève enregistré</h3>
            <p className="text-gray-500 mb-6">Commencez par ajouter votre premier élève à l'école.</p>
            <button
              onClick={() => setShowAddForm(true)}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="w-4 h-4 mr-2" />
              Ajouter un Élève
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Élève</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Classe</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Date de Naissance</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Parent/Tuteur</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Contact</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Statut</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredStudents.map((student) => (
                  <tr key={student.id} className="hover:bg-gray-50 transition-colors">
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-3">
                        <Avatar 
                          firstName={student.firstName} 
                          lastName={student.lastName} 
                          size="md" 
                          showPhoto={true}
                        />
                        <div>
                          <p className="font-medium text-gray-900">{student.firstName} {student.lastName}</p>
                          <div className="flex items-center text-sm text-gray-500">
                            <MapPin className="w-3 h-3 mr-1" />
                            {student.address.split(',')[0]}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        {student.class}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center text-sm text-gray-900">
                        <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                        {new Date(student.dateOfBirth).toLocaleDateString('fr-FR')}
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <p className="text-sm font-medium text-gray-900">{student.parentName}</p>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center text-sm text-gray-600">
                        <Phone className="w-4 h-4 mr-2 text-gray-400" />
                        {student.phone}
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        student.status === 'active' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {student.status === 'active' ? 'Actif' : 'Inactif'}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-2">
                        <button 
                          onClick={() => handleViewStudent(student)}
                          className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Voir les détails"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => handleEditClick(student)}
                          className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                          title="Modifier"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => handleDeleteStudent(student.id)}
                          className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Supprimer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => handleGenerateCertificate(student)}
                          className="p-1.5 text-gray-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                          title="Certificat de scolarité"
                        >
                          <FileText className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add Student Modal */}
      <Modal
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        title="Ajouter un Élève"
        size="lg"
      >
        <StudentForm
          onSubmit={handleAddStudent}
          onCancel={() => setShowAddForm(false)}
        />
      </Modal>

      {/* Edit Student Modal */}
      <Modal
        isOpen={showEditForm}
        onClose={() => {
          setShowEditForm(false);
          setSelectedStudent(null);
        }}
        title="Modifier l'Élève"
        size="lg"
      >
        {selectedStudent && (
          <StudentForm
            onSubmit={handleEditStudent}
            onCancel={() => {
              setShowEditForm(false);
              setSelectedStudent(null);
            }}
            initialData={selectedStudent}
          />
        )}
      </Modal>

      {/* View Student Modal */}
      <Modal
        isOpen={showViewModal}
        onClose={() => {
          setShowViewModal(false);
          setSelectedStudent(null);
        }}
        title="Détails de l'Élève"
        size="lg"
      >
        {selectedStudent && (
          <div className="space-y-6">
            <div className="flex items-center space-x-4">
              <Avatar 
                firstName={selectedStudent.firstName} 
                lastName={selectedStudent.lastName} 
                size="lg" 
                showPhoto={true}
              />
              <div>
                <h3 className="text-xl font-bold text-gray-900">
                  {selectedStudent.firstName} {selectedStudent.lastName}
                </h3>
                <p className="text-gray-600">{selectedStudent.class}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Informations personnelles</h4>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Date de naissance:</span> {new Date(selectedStudent.dateOfBirth).toLocaleDateString('fr-FR')}</p>
                  <p><span className="font-medium">Adresse:</span> {selectedStudent.address}</p>
                  <p><span className="font-medium">Téléphone:</span> {selectedStudent.phone}</p>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Informations scolaires</h4>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Classe:</span> {selectedStudent.class}</p>
                  <p><span className="font-medium">Parent/Tuteur:</span> {selectedStudent.parentName}</p>
                  <p><span className="font-medium">Statut:</span> 
                    <span className={`ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                      selectedStudent.status === 'active' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {selectedStudent.status === 'active' ? 'Actif' : 'Inactif'}
                    </span>
                  </p>
                </div>
              </div>
            </div>
            
            {/* Actions rapides */}
            <div className="mt-6 pt-4 border-t border-gray-200">
              <h4 className="font-medium text-gray-900 mb-3">Actions rapides</h4>
              <div className="flex space-x-3">
                <button
                  onClick={() => {
                    setShowViewModal(false);
                    handleGenerateCertificate(selectedStudent);
                  }}
                  className="inline-flex items-center px-3 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Certificat de scolarité
                </button>
                <button
                  onClick={() => {
                    setShowViewModal(false);
                    handleEditClick(selectedStudent);
                  }}
                  className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors text-sm"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Modifier
                </button>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* Certificate Modal */}
      {selectedStudent && (
        <CertificateModal
          isOpen={showCertificateModal}
          onClose={() => {
            setShowCertificateModal(false);
            setSelectedStudent(null);
          }}
          student={selectedStudent}
        />
      )}
    </div>
  );
}