import React, { useState } from 'react';
import { Search, Plus, BookOpen, Clock, Users, Edit, Trash2, Eye } from 'lucide-react';
import { Modal } from '../components/Modal';
import { SubjectForm } from '../components/forms/SubjectForm';

interface Subject {
  id: string;
  name: string;
  code: string;
  description: string;
  hoursPerWeek: number;
  teachers: string[];
  classes: string[];
  color: string;
  status: 'active' | 'inactive';
}

const mockSubjects: Subject[] = [
  {
    id: '1',
    name: 'Mathématiques',
    code: 'MATH',
    description: 'Mathématiques générales et appliquées',
    hoursPerWeek: 5,
    teachers: ['Catherine Moreau', 'Jean Dubois'],
    classes: ['6ème A', '6ème B', '5ème A'],
    color: 'blue',
    status: 'active'
  },
  {
    id: '2',
    name: 'Français',
    code: 'FR',
    description: 'Langue française et littérature',
    hoursPerWeek: 4,
    teachers: ['Jean-Pierre Durand'],
    classes: ['5ème A', '5ème B', '4ème A'],
    color: 'green',
    status: 'active'
  },
  {
    id: '3',
    name: 'Anglais',
    code: 'ANG',
    description: 'Langue anglaise',
    hoursPerWeek: 3,
    teachers: ['Marie Lambert'],
    classes: ['6ème C', '5ème C', '4ème B'],
    color: 'purple',
    status: 'active'
  },
  {
    id: '4',
    name: 'Sciences',
    code: 'SCI',
    description: 'Sciences physiques et naturelles',
    hoursPerWeek: 3,
    teachers: ['Patrick Rousseau'],
    classes: ['6ème A', '5ème B'],
    color: 'orange',
    status: 'active'
  },
  {
    id: '5',
    name: 'Histoire-Géographie',
    code: 'HG',
    description: 'Histoire et géographie',
    hoursPerWeek: 3,
    teachers: ['Sophie Martin'],
    classes: ['6ème A', '6ème B'],
    color: 'red',
    status: 'inactive'
  }
];

const colorClasses = {
  blue: 'bg-blue-100 text-blue-800 border-blue-200',
  green: 'bg-green-100 text-green-800 border-green-200',
  purple: 'bg-purple-100 text-purple-800 border-purple-200',
  orange: 'bg-orange-100 text-orange-800 border-orange-200',
  red: 'bg-red-100 text-red-800 border-red-200'
};

export function Subjects() {
  const [subjects, setSubjects] = useState<Subject[]>(mockSubjects);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);

  const filteredSubjects = subjects.filter(subject => {
    return subject.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
           subject.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
           subject.description.toLowerCase().includes(searchTerm.toLowerCase());
  });

  const handleAddSubject = (data: any) => {
    const newSubject: Subject = {
      id: Date.now().toString(),
      name: data.name || 'Nouvelle matière',
      code: data.code || 'NM',
      description: data.description || 'Description de la matière',
      color: data.color || 'blue',
      status: data.status || 'active',
      teachers: [],
      classes: [],
      ...data,
      hoursPerWeek: parseInt(data.hoursPerWeek) || 3
    };
    setSubjects([...subjects, newSubject]);
    setShowAddForm(false);
  };

  const handleEditSubject = (data: any) => {
    if (selectedSubject) {
      setSubjects(subjects.map(s => 
        s.id === selectedSubject.id ? { ...s, ...data, hoursPerWeek: parseInt(data.hoursPerWeek) } : s
      ));
      setShowEditForm(false);
      setSelectedSubject(null);
    }
  };

  const handleDeleteSubject = (id: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette matière ?')) {
      setSubjects(subjects.filter(s => s.id !== id));
    }
  };

  const handleViewSubject = (subject: Subject) => {
    setSelectedSubject(subject);
    setShowViewModal(true);
  };

  const handleEditClick = (subject: Subject) => {
    setSelectedSubject(subject);
    setShowEditForm(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Gestion des Matières</h1>
          <p className="text-gray-600">Gérez le programme pédagogique de l'école</p>
        </div>
        
        <button
          onClick={() => setShowAddForm(true)}
          className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
        >
          <Plus className="w-4 h-4 mr-2" />
          Ajouter une Matière
        </button>
      </div>

      {/* Search */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Rechercher une matière..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Subjects Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Matières</p>
              <p className="text-2xl font-bold text-gray-900">{subjects.length}</p>
            </div>
            <BookOpen className="w-8 h-8 text-purple-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Actives</p>
              <p className="text-2xl font-bold text-green-600">{subjects.filter(s => s.status === 'active').length}</p>
            </div>
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              <div className="w-3 h-3 bg-green-600 rounded-full"></div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Heures/Semaine</p>
              <p className="text-2xl font-bold text-blue-600">{subjects.reduce((acc, s) => acc + s.hoursPerWeek, 0)}h</p>
            </div>
            <Clock className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Enseignants</p>
              <p className="text-2xl font-bold text-orange-600">
                {[...new Set(subjects.flatMap(s => s.teachers))].length}
              </p>
            </div>
            <Users className="w-8 h-8 text-orange-600" />
          </div>
        </div>
      </div>

      {/* Subjects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSubjects.map((subject) => (
          <div key={subject.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${colorClasses[subject.color as keyof typeof colorClasses]}`}>
                    {subject.code}
                  </span>
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    subject.status === 'active' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {subject.status === 'active' ? 'Active' : 'Inactive'}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-1">{subject.name}</h3>
                <p className="text-sm text-gray-600">{subject.description}</p>
              </div>
            </div>

            <div className="space-y-3">
              {/* Hours per week */}
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-600">{subject.hoursPerWeek}h par semaine</span>
              </div>

              {/* Teachers */}
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <Users className="w-4 h-4 text-gray-400" />
                  <span className="text-sm text-gray-500 font-medium">Enseignants:</span>
                </div>
                <div className="ml-6">
                  {subject.teachers.map((teacher, index) => (
                    <p key={index} className="text-sm text-gray-600">{teacher}</p>
                  ))}
                </div>
              </div>

              {/* Classes */}
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <BookOpen className="w-4 h-4 text-gray-400" />
                  <span className="text-sm text-gray-500 font-medium">Classes:</span>
                </div>
                <div className="ml-6 flex flex-wrap gap-1">
                  {subject.classes.slice(0, 3).map((className, index) => (
                    <span key={index} className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-gray-100 text-gray-700">
                      {className}
                    </span>
                  ))}
                  {subject.classes.length > 3 && (
                    <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-gray-100 text-gray-600">
                      +{subject.classes.length - 3}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between mt-6 pt-4 border-t border-gray-100">
              <div className="flex items-center space-x-2">
                <button 
                  onClick={() => handleViewSubject(subject)}
                  className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                >
                  <Eye className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => handleEditClick(subject)}
                  className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => handleDeleteSubject(subject.id)}
                  className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              
              <button 
                onClick={() => handleViewSubject(subject)}
                className="text-xs text-purple-600 hover:text-purple-700 font-medium"
              >
                Emploi du temps
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Subject Modal */}
      <Modal
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        title="Ajouter une Matière"
        size="lg"
      >
        <SubjectForm
          onSubmit={handleAddSubject}
          onCancel={() => setShowAddForm(false)}
        />
      </Modal>

      {/* Edit Subject Modal */}
      <Modal
        isOpen={showEditForm}
        onClose={() => {
          setShowEditForm(false);
          setSelectedSubject(null);
        }}
        title="Modifier la Matière"
        size="lg"
      >
        {selectedSubject && (
          <SubjectForm
            onSubmit={handleEditSubject}
            onCancel={() => {
              setShowEditForm(false);
              setSelectedSubject(null);
            }}
            initialData={selectedSubject}
          />
        )}
      </Modal>

      {/* View Subject Modal */}
      <Modal
        isOpen={showViewModal}
        onClose={() => {
          setShowViewModal(false);
          setSelectedSubject(null);
        }}
        title="Détails de la Matière"
        size="lg"
      >
        {selectedSubject && (
          <div className="space-y-6">
            <div className="flex items-center space-x-4">
              <div className={`w-16 h-16 rounded-full flex items-center justify-center ${colorClasses[selectedSubject.color as keyof typeof colorClasses]}`}>
                <span className="font-bold text-xl">
                  {selectedSubject.code}
                </span>
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">{selectedSubject.name}</h3>
                <p className="text-gray-600">{selectedSubject.description}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Informations générales</h4>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Code:</span> {selectedSubject.code}</p>
                  <p><span className="font-medium">Heures par semaine:</span> {selectedSubject.hoursPerWeek}h</p>
                  <p><span className="font-medium">Statut:</span> 
                    <span className={`ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                      selectedSubject.status === 'active' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {selectedSubject.status === 'active' ? 'Active' : 'Inactive'}
                    </span>
                  </p>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Enseignants et Classes</h4>
                <div className="space-y-2 text-sm">
                  <div>
                    <p className="font-medium">Enseignants:</p>
                    {selectedSubject.teachers.map((teacher, index) => (
                      <p key={index} className="ml-2 text-gray-600">• {teacher}</p>
                    ))}
                  </div>
                  <div>
                    <p className="font-medium">Classes:</p>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {selectedSubject.classes.map((className, index) => (
                        <span key={index} className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-gray-100 text-gray-700">
                          {className}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}