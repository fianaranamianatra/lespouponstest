import React, { useState } from 'react';
import { Upload, FileText, AlertTriangle, CheckCircle, Users } from 'lucide-react';
import { CSVFileUploader } from '../components/import/CSVFileUploader';
import { CSVPreview } from '../components/import/CSVPreview';
import { parseCSV, validateStudentCSVData, convertCSVToStudentData } from '../utils/csvParser';
import { useFirebaseCollection } from '../hooks/useFirebaseCollection';
import { studentsService } from '../lib/firebase/firebaseService';

export function ImportStudents() {
  const [step, setStep] = useState<'upload' | 'preview' | 'result'>('upload');
  const [csvContent, setCsvContent] = useState<string | null>(null);
  const [parsedData, setParsedData] = useState<{ headers: string[]; data: Record<string, string>[] } | null>(null);
  const [validationResult, setValidationResult] = useState<{ isValid: boolean; errors: string[]; warnings: string[] } | null>(null);
  const [importResult, setImportResult] = useState<{ success: number; failed: number; errors: string[] } | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  
  // Hook Firebase pour l'ajout d'élèves
  const { create, creating, error } = useFirebaseCollection(studentsService);

  const handleFileLoaded = (content: string) => {
    setCsvContent(content);
    
    try {
      // Parser le CSV
      const parsed = parseCSV(content);
      setParsedData(parsed);
      
      // Valider les données
      const validation = validateStudentCSVData(parsed.headers, parsed.data);
      setValidationResult(validation);
      
      // Passer à l'étape de prévisualisation
      setStep('preview');
    } catch (error: any) {
      alert(`Erreur lors de l'analyse du fichier CSV: ${error.message}`);
    }
  };

  const handleFileError = (errorMessage: string) => {
    alert(errorMessage);
  };

  const handleImport = async () => {
    if (!parsedData || !validationResult) return;
    
    setIsImporting(true);
    
    try {
      // Convertir les données CSV en format compatible avec l'application
      const studentsData = convertCSVToStudentData(parsedData.data);
      
      // Compteurs pour le résultat
      let successCount = 0;
      let failedCount = 0;
      const importErrors: string[] = [];
      
      // Importer chaque élève
      for (const studentData of studentsData) {
        try {
          await create(studentData);
          successCount++;
        } catch (error: any) {
          failedCount++;
          importErrors.push(`Erreur pour ${studentData.firstName} ${studentData.lastName}: ${error.message}`);
        }
      }
      
      // Mettre à jour le résultat
      setImportResult({
        success: successCount,
        failed: failedCount,
        errors: importErrors
      });
      
      // Passer à l'étape de résultat
      setStep('result');
    } catch (error: any) {
      alert(`Erreur lors de l'importation: ${error.message}`);
    } finally {
      setIsImporting(false);
    }
  };

  const handleCancel = () => {
    // Réinitialiser l'état et revenir à l'étape d'upload
    setCsvContent(null);
    setParsedData(null);
    setValidationResult(null);
    setImportResult(null);
    setStep('upload');
  };

  const handleNewImport = () => {
    // Réinitialiser l'état et revenir à l'étape d'upload
    setCsvContent(null);
    setParsedData(null);
    setValidationResult(null);
    setImportResult(null);
    setStep('upload');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Importation d'Élèves</h1>
          <p className="text-gray-600">Importez des élèves à partir d'un fichier CSV</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        {/* Étape 1: Upload */}
        {step === 'upload' && (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <Upload className="w-16 h-16 text-blue-500 mx-auto mb-4" />
              <h2 className="text-xl font-bold text-gray-900 mb-2">Importer un fichier CSV</h2>
              <p className="text-gray-600 max-w-md mx-auto">
                Sélectionnez un fichier CSV contenant les informations des élèves à importer.
                Assurez-vous que le fichier respecte le format attendu.
              </p>
            </div>
            
            <div className="max-w-md mx-auto">
              <CSVFileUploader 
                onFileLoaded={handleFileLoaded}
                onError={handleFileError}
              />
            </div>
            
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 max-w-md mx-auto">
              <h3 className="font-medium text-blue-800 mb-2 flex items-center">
                <FileText className="w-4 h-4 mr-2" />
                Format attendu
              </h3>
              <p className="text-sm text-blue-700 mb-2">
                Le fichier CSV doit contenir les colonnes suivantes:
              </p>
              <ul className="list-disc pl-5 space-y-1 text-sm text-blue-700">
                <li>Numéro (obligatoire)</li>
                <li>Nom et Prénoms (obligatoire)</li>
                <li>Contact (optionnel)</li>
                <li>Classe (optionnel)</li>
                <li>Parent/Tuteur (optionnel)</li>
                <li>Notes (Sept, Oct, Nov, etc.) (optionnel)</li>
              </ul>
              <p className="text-sm text-blue-700 mt-2">
                La première ligne doit contenir les en-têtes des colonnes.
              </p>
            </div>
          </div>
        )}
        
        {/* Étape 2: Prévisualisation */}
        {step === 'preview' && parsedData && validationResult && (
          <CSVPreview 
            headers={parsedData.headers}
            data={parsedData.data}
            validationResult={validationResult}
            onImport={handleImport}
            onCancel={handleCancel}
            isImporting={isImporting}
          />
        )}
        
        {/* Étape 3: Résultat */}
        {step === 'result' && importResult && (
          <div className="space-y-6">
            <div className="text-center mb-6">
              {importResult.failed === 0 ? (
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
              ) : importResult.success === 0 ? (
                <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4" />
              ) : (
                <Users className="w-16 h-16 text-blue-500 mx-auto mb-4" />
              )}
              
              <h2 className="text-xl font-bold text-gray-900 mb-2">
                Importation terminée
              </h2>
              
              <p className="text-gray-600">
                {importResult.success} élève(s) importé(s) avec succès.
                {importResult.failed > 0 && ` ${importResult.failed} échec(s).`}
              </p>
            </div>
            
            {importResult.errors.length > 0 && (
              <div className="bg-red-50 rounded-lg p-4 border border-red-200 mb-6">
                <h3 className="font-medium text-red-800 mb-2 flex items-center">
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Erreurs d'importation ({importResult.errors.length})
                </h3>
                <ul className="list-disc pl-5 space-y-1 text-sm text-red-700 max-h-40 overflow-y-auto">
                  {importResult.errors.map((error, index) => (
                    <li key={index}>{error}</li>
                  ))}
                </ul>
              </div>
            )}
            
            <div className="flex justify-center">
              <button
                onClick={handleNewImport}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Nouvelle importation
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}