import React, { useState } from 'react';
import { Search, Plus, Send, MessageCircle, Users, Phone, Mail, Filter, Clock } from 'lucide-react';
import { Modal } from '../components/Modal';
import { MessageForm } from '../components/forms/MessageForm';
import { Avatar } from '../components/Avatar';

interface Message {
  id: string;
  sender: string;
  recipient: string;
  subject: string;
  content: string;
  date: string;
  type: 'parent' | 'teacher' | 'admin';
  status: 'sent' | 'read' | 'replied';
  priority: 'low' | 'medium' | 'high';
}

const mockMessages: Message[] = [
  {
    id: '1',
    sender: 'Sophie Martin',
    recipient: 'Catherine Moreau',
    subject: 'Question sur les devoirs de Marie',
    content: 'Bonjour, j\'aimerais savoir si Marie peut avoir un délai supplémentaire pour son devoir de mathématiques...',
    date: '2024-11-20T10:30:00',
    type: 'parent',
    status: 'read',
    priority: 'medium'
  },
  {
    id: '2',
    sender: 'Jean-Pierre Durand',
    recipient: 'Tous les parents 5ème B',
    subject: 'Sortie scolaire - Musée d\'Histoire',
    content: 'Chers parents, nous organisons une sortie éducative au Musée d\'Histoire le 25 novembre...',
    date: '2024-11-19T14:15:00',
    type: 'teacher',
    status: 'sent',
    priority: 'high'
  },
  {
    id: '3',
    sender: 'Administration',
    recipient: 'Tous les parents',
    subject: 'Réunion parents-professeurs',
    content: 'La réunion parents-professeurs du trimestre aura lieu le 28 novembre de 14h à 17h...',
    date: '2024-11-18T09:00:00',
    type: 'admin',
    status: 'sent',
    priority: 'high'
  },
  {
    id: '4',
    sender: 'Michel Bernard',
    recipient: 'Marie Lambert',
    subject: 'Absence de Julie',
    content: 'Madame Lambert, Julie sera absente demain pour un rendez-vous médical...',
    date: '2024-11-17T16:45:00',
    type: 'parent',
    status: 'replied',
    priority: 'low'
  }
];

const typeColors = {
  parent: 'bg-blue-100 text-blue-800',
  teacher: 'bg-green-100 text-green-800',
  admin: 'bg-purple-100 text-purple-800'
};

const statusColors = {
  sent: 'bg-gray-100 text-gray-800',
  read: 'bg-yellow-100 text-yellow-800',
  replied: 'bg-green-100 text-green-800'
};

const priorityColors = {
  low: 'bg-gray-100 text-gray-800',
  medium: 'bg-orange-100 text-orange-800',
  high: 'bg-red-100 text-red-800'
};

export function Communication() {
  const [messages, setMessages] = useState<Message[]>(mockMessages);
  const [searchTerm, setSearchTerm] = useState('');
  const [showComposeForm, setShowComposeForm] = useState(false);
  const [selectedType, setSelectedType] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');

  const filteredMessages = messages.filter(message => {
    const matchesSearch = message.sender.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         message.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         message.recipient.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === '' || message.type === selectedType;
    const matchesStatus = selectedStatus === '' || message.status === selectedStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  const totalMessages = messages.length;
  const unreadMessages = messages.filter(m => m.status === 'sent').length;
  const highPriorityMessages = messages.filter(m => m.priority === 'high').length;

  const handleSendMessage = (data: any) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      sender: 'Administration',
      recipient: data.recipient || 'Destinataire inconnu',
      subject: data.subject || 'Sans objet',
      content: data.content || '',
      date: new Date().toISOString(),
      status: 'sent',
      type: data.type || 'admin',
      priority: data.priority || 'medium',
      ...data
    };
    setMessages([newMessage, ...messages]);
    setShowComposeForm(false);
  };

  const handleQuickAction = (action: string) => {
    switch (action) {
      case 'group':
        setShowComposeForm(true);
        break;
      case 'emergency':
        alert('Fonction d\'appel d\'urgence activée');
        break;
      case 'newsletter':
        alert('Création de newsletter en cours...');
        break;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Communication</h1>
          <p className="text-gray-600">Gérez la communication entre l'école, les enseignants et les parents</p>
        </div>
        
        <button
          onClick={() => setShowComposeForm(true)}
          className="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nouveau Message
        </button>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button 
          onClick={() => handleQuickAction('group')}
          className="bg-white rounded-lg p-4 border border-gray-100 hover:border-blue-300 hover:bg-blue-50 transition-all text-left group"
        >
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200">
              <MessageCircle className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h3 className="font-medium text-gray-900">Message Groupé</h3>
              <p className="text-sm text-gray-600">Envoyer à une classe entière</p>
            </div>
          </div>
        </button>
        
        <button 
          onClick={() => handleQuickAction('emergency')}
          className="bg-white rounded-lg p-4 border border-gray-100 hover:border-green-300 hover:bg-green-50 transition-all text-left group"
        >
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center group-hover:bg-green-200">
              <Phone className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <h3 className="font-medium text-gray-900">Appel d'Urgence</h3>
              <p className="text-sm text-gray-600">Contacter les parents</p>
            </div>
          </div>
        </button>
        
        <button 
          onClick={() => handleQuickAction('newsletter')}
          className="bg-white rounded-lg p-4 border border-gray-100 hover:border-purple-300 hover:bg-purple-50 transition-all text-left group"
        >
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center group-hover:bg-purple-200">
              <Mail className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <h3 className="font-medium text-gray-900">Newsletter</h3>
              <p className="text-sm text-gray-600">Bulletin d'information</p>
            </div>
          </div>
        </button>
      </div>

      {/* Filters and Search */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Rechercher dans les messages..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="flex gap-2">
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            >
              <option value="">Tous les types</option>
              <option value="parent">Parents</option>
              <option value="teacher">Enseignants</option>
              <option value="admin">Administration</option>
            </select>
            
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            >
              <option value="">Tous les statuts</option>
              <option value="sent">Envoyé</option>
              <option value="read">Lu</option>
              <option value="replied">Répondu</option>
            </select>
            
            <button className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Filter className="w-4 h-4 mr-2" />
              Filtres
            </button>
          </div>
        </div>
      </div>

      {/* Communication Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Messages</p>
              <p className="text-2xl font-bold text-gray-900">{totalMessages}</p>
            </div>
            <MessageCircle className="w-8 h-8 text-indigo-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Non Lus</p>
              <p className="text-2xl font-bold text-orange-600">{unreadMessages}</p>
            </div>
            <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
              <div className="w-3 h-3 bg-orange-600 rounded-full"></div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Priorité Haute</p>
              <p className="text-2xl font-bold text-red-600">{highPriorityMessages}</p>
            </div>
            <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
              <div className="w-3 h-3 bg-red-600 rounded-full"></div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Taux Réponse</p>
              <p className="text-2xl font-bold text-green-600">
                {Math.round((messages.filter(m => m.status === 'replied').length / totalMessages) * 100)}%
              </p>
            </div>
            <Send className="w-8 h-8 text-green-600" />
          </div>
        </div>
      </div>

      {/* Messages List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Expéditeur</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Destinataire</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Sujet</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Type</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Priorité</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Date</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Statut</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredMessages.map((message) => (
                <tr key={message.id} className="hover:bg-gray-50 transition-colors">
                  <td className="py-4 px-6">
                    <div className="flex items-center space-x-3">
                      <Avatar 
                        firstName={message.sender.split(' ')[0] || ''} 
                        lastName={message.sender.split(' ')[1] || ''} 
                        size="sm" 
                        showPhoto={true}
                      />
                      <p className="font-medium text-gray-900">{message.sender}</p>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <p className="text-sm text-gray-600">{message.recipient}</p>
                  </td>
                  <td className="py-4 px-6">
                    <div>
                      <p className="font-medium text-gray-900">{message.subject}</p>
                      <p className="text-sm text-gray-500 truncate max-w-xs">
                        {message.content}
                      </p>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${typeColors[message.type]}`}>
                      {message.type === 'parent' ? 'Parent' : message.type === 'teacher' ? 'Enseignant' : 'Administration'}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${priorityColors[message.priority]}`}>
                      {message.priority === 'low' ? 'Basse' : message.priority === 'medium' ? 'Moyenne' : 'Haute'}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center text-sm text-gray-600">
                      <Clock className="w-4 h-4 mr-2 text-gray-400" />
                      {new Date(message.date).toLocaleDateString('fr-FR')}
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusColors[message.status]}`}>
                      {message.status === 'sent' ? 'Envoyé' : message.status === 'read' ? 'Lu' : 'Répondu'}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center space-x-2">
                      <button className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                        <MessageCircle className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors">
                        <Send className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Compose Message Modal */}
      <Modal
        isOpen={showComposeForm}
        onClose={() => setShowComposeForm(false)}
        title="Nouveau Message"
        size="lg"
      >
        <MessageForm
          onSubmit={handleSendMessage}
          onCancel={() => setShowComposeForm(false)}
        />
      </Modal>
    </div>
  );
}