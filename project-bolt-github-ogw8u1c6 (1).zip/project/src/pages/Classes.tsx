import React, { useState } from 'react';
import { Search, Plus, Users, GraduationCap, BookOpen, Edit, Trash2, Eye } from 'lucide-react';
import { Modal } from '../components/Modal';
import { ClassForm } from '../components/forms/ClassForm';

interface Class {
  id: string;
  name: string;
  level: string;
  teacher: string;
  studentCount: number;
  maxCapacity: number;
  room: string;
  schedule: string[];
  status: 'active' | 'inactive';
}

// Classes prédéfinies pour l'école LES POUPONS
const mockClasses: Class[] = [
  // Très Petite Section
  {
    id: '1',
    name: 'TPSA',
    level: 'Très Petite Section',
    teacher: '',
    studentCount: 0,
    maxCapacity: 15,
    room: 'Salle TPS A',
    schedule: [],
    status: 'active'
  },
  {
    id: '2',
    name: 'TPSB',
    level: 'Très Petite Section',
    teacher: '',
    studentCount: 0,
    maxCapacity: 15,
    room: 'Salle TPS B',
    schedule: [],
    status: 'active'
  },
  // Petite Section
  {
    id: '3',
    name: 'PSA',
    level: 'Petite Section',
    teacher: '',
    studentCount: 0,
    maxCapacity: 18,
    room: 'Salle PS A',
    schedule: [],
    status: 'active'
  },
  {
    id: '4',
    name: 'PSB',
    level: 'Petite Section',
    teacher: '',
    studentCount: 0,
    maxCapacity: 18,
    room: 'Salle PS B',
    schedule: [],
    status: 'active'
  },
  {
    id: '5',
    name: 'PSC',
    level: 'Petite Section',
    teacher: '',
    studentCount: 0,
    maxCapacity: 18,
    room: 'Salle PS C',
    schedule: [],
    status: 'active'
  },
  // Moyenne Section
  {
    id: '6',
    name: 'MS_A',
    level: 'Moyenne Section',
    teacher: '',
    studentCount: 0,
    maxCapacity: 20,
    room: 'Salle MS A',
    schedule: [],
    status: 'active'
  },
  {
    id: '7',
    name: 'MSB',
    level: 'Moyenne Section',
    teacher: '',
    studentCount: 0,
    maxCapacity: 20,
    room: 'Salle MS B',
    schedule: [],
    status: 'active'
  },
  // Grande Section
  {
    id: '8',
    name: 'GSA',
    level: 'Grande Section',
    teacher: '',
    studentCount: 0,
    maxCapacity: 22,
    room: 'Salle GS A',
    schedule: [],
    status: 'active'
  },
  {
    id: '9',
    name: 'GSB',
    level: 'Grande Section',
    teacher: '',
    studentCount: 0,
    maxCapacity: 22,
    room: 'Salle GS B',
    schedule: [],
    status: 'active'
  },
  {
    id: '10',
    name: 'GSC',
    level: 'Grande Section',
    teacher: '',
    studentCount: 0,
    maxCapacity: 22,
    room: 'Salle GS C',
    schedule: [],
    status: 'active'
  },
  // Classes Primaires
  {
    id: '11',
    name: '11_A',
    level: 'CP',
    teacher: '',
    studentCount: 0,
    maxCapacity: 25,
    room: 'Salle 11A',
    schedule: [],
    status: 'active'
  },
  {
    id: '12',
    name: '11B',
    level: 'CP',
    teacher: '',
    studentCount: 0,
    maxCapacity: 25,
    room: 'Salle 11B',
    schedule: [],
    status: 'active'
  },
  {
    id: '13',
    name: '10_A',
    level: 'CE1',
    teacher: '',
    studentCount: 0,
    maxCapacity: 25,
    room: 'Salle 10A',
    schedule: [],
    status: 'active'
  },
  {
    id: '14',
    name: '10_B',
    level: 'CE1',
    teacher: '',
    studentCount: 0,
    maxCapacity: 25,
    room: 'Salle 10B',
    schedule: [],
    status: 'active'
  },
  {
    id: '15',
    name: '9A',
    level: 'CE2',
    teacher: '',
    studentCount: 0,
    maxCapacity: 28,
    room: 'Salle 9A',
    schedule: [],
    status: 'active'
  },
  {
    id: '16',
    name: '9_B',
    level: 'CE2',
    teacher: '',
    studentCount: 0,
    maxCapacity: 28,
    room: 'Salle 9B',
    schedule: [],
    status: 'active'
  },
  {
    id: '17',
    name: '8',
    level: 'CM1',
    teacher: '',
    studentCount: 0,
    maxCapacity: 30,
    room: 'Salle 8',
    schedule: [],
    status: 'active'
  },
  {
    id: '18',
    name: '7',
    level: 'CM2',
    teacher: '',
    studentCount: 0,
    maxCapacity: 30,
    room: 'Salle 7',
    schedule: [],
    status: 'active'
  },
  // Classes Spécialisées
  {
    id: '19',
    name: 'CS',
    level: 'Classe Spécialisée',
    teacher: '',
    studentCount: 0,
    maxCapacity: 12,
    room: 'Salle CS',
    schedule: [],
    status: 'active'
  },
  {
    id: '20',
    name: 'GARDERIE',
    level: 'Garderie',
    teacher: '',
    studentCount: 0,
    maxCapacity: 20,
    room: 'Salle Garderie',
    schedule: [],
    status: 'active'
  }
];

export function Classes() {
  const [classes, setClasses] = useState<Class[]>(mockClasses);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedLevel, setSelectedLevel] = useState('');
  const [selectedClass, setSelectedClass] = useState<Class | null>(null);

  const filteredClasses = classes.filter(classItem => {
    const matchesSearch = classItem.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         classItem.teacher.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         classItem.room.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesLevel = selectedLevel === '' || classItem.level === selectedLevel;
    return matchesSearch && matchesLevel;
  });

  const levels = [...new Set(classes.map(c => c.level))];

  const handleAddClass = (data: any) => {
    const newClass: Class = {
      id: Date.now().toString(),
      name: data.name || 'Nouvelle classe',
      level: data.level || 'Niveau inconnu',
      teacher: data.teacher || '',
      room: data.room || 'Salle inconnue',
      status: data.status || 'active',
      studentCount: 0,
      schedule: [],
      ...data,
      maxCapacity: parseInt(data.maxCapacity) || 20
    };
    setClasses([...classes, newClass]);
    setShowAddForm(false);
  };

  const handleEditClass = (data: any) => {
    if (selectedClass) {
      setClasses(classes.map(c => 
        c.id === selectedClass.id ? { ...c, ...data, maxCapacity: parseInt(data.maxCapacity) } : c
      ));
      setShowEditForm(false);
      setSelectedClass(null);
    }
  };

  const handleDeleteClass = (id: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette classe ?')) {
      setClasses(classes.filter(c => c.id !== id));
    }
  };

  const handleViewClass = (classItem: Class) => {
    setSelectedClass(classItem);
    setShowViewModal(true);
  };

  const handleEditClick = (classItem: Class) => {
    setSelectedClass(classItem);
    setShowEditForm(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Gestion des Classes</h1>
          <p className="text-gray-600">Organisez et gérez les classes de l'école</p>
        </div>
        
        <button
          onClick={() => setShowAddForm(true)}
          className="inline-flex items-center px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
        >
          <Plus className="w-4 h-4 mr-2" />
          Créer une Classe
        </button>
      </div>

      {/* Filters and Search */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Rechercher une classe..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <select
            value={selectedLevel}
            onChange={(e) => setSelectedLevel(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
          >
            <option value="">Tous les niveaux</option>
            {levels.map(level => (
              <option key={level} value={level}>{level}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Classes Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Classes</p>
              <p className="text-2xl font-bold text-gray-900">{classes.length}</p>
            </div>
            <BookOpen className="w-8 h-8 text-orange-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Élèves Total</p>
              <p className="text-2xl font-bold text-blue-600">{classes.reduce((acc, c) => acc + c.studentCount, 0)}</p>
            </div>
            <Users className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Capacité Totale</p>
              <p className="text-2xl font-bold text-green-600">{classes.reduce((acc, c) => acc + c.maxCapacity, 0)}</p>
            </div>
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              <div className="w-3 h-3 bg-green-600 rounded-full"></div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Niveaux</p>
              <p className="text-2xl font-bold text-purple-600">{levels.length}</p>
            </div>
            <GraduationCap className="w-8 h-8 text-purple-600" />
          </div>
        </div>
      </div>

      {/* Classes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredClasses.map((classItem) => (
          <div key={classItem.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-bold text-gray-900">{classItem.name}</h3>
                <p className="text-sm text-gray-600">{classItem.level}</p>
                <p className="text-xs text-gray-500">{classItem.room}</p>
              </div>
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                classItem.status === 'active' 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-red-100 text-red-800'
              }`}>
                {classItem.status === 'active' ? 'Active' : 'Inactive'}
              </span>
            </div>

            <div className="space-y-3">
              {/* Teacher */}
              <div className="flex items-center space-x-2">
                <GraduationCap className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-600">
                  {classItem.teacher || 'Enseignant non assigné'}
                </span>
              </div>

              {/* Student Count */}
              <div className="flex items-center space-x-2">
                <Users className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-600">
                  {classItem.studentCount}/{classItem.maxCapacity} élèves
                </span>
              </div>

              {/* Capacity Bar */}
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-orange-600 h-2 rounded-full" 
                  style={{ width: `${classItem.maxCapacity > 0 ? (classItem.studentCount / classItem.maxCapacity) * 100 : 0}%` }}
                ></div>
              </div>

              {/* Age Group Indicator */}
              <div className="text-xs text-gray-500">
                {classItem.level === 'Très Petite Section' && '2-3 ans'}
                {classItem.level === 'Petite Section' && '3-4 ans'}
                {classItem.level === 'Moyenne Section' && '4-5 ans'}
                {classItem.level === 'Grande Section' && '5-6 ans'}
                {classItem.level === 'CP' && '6-7 ans'}
                {classItem.level === 'CE1' && '7-8 ans'}
                {classItem.level === 'CE2' && '8-9 ans'}
                {classItem.level === 'CM1' && '9-10 ans'}
                {classItem.level === 'CM2' && '10-11 ans'}
                {(classItem.level === 'Classe Spécialisée' || classItem.level === 'Garderie') && 'Tous âges'}
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between mt-6 pt-4 border-t border-gray-100">
              <div className="flex items-center space-x-2">
                <button 
                  onClick={() => handleViewClass(classItem)}
                  className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                >
                  <Eye className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => handleEditClick(classItem)}
                  className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => handleDeleteClass(classItem.id)}
                  className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              
              <button 
                onClick={() => handleViewClass(classItem)}
                className="text-xs text-orange-600 hover:text-orange-700 font-medium"
              >
                Détails
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Class Modal */}
      <Modal
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        title="Créer une Classe"
        size="lg"
      >
        <ClassForm
          onSubmit={handleAddClass}
          onCancel={() => setShowAddForm(false)}
        />
      </Modal>

      {/* Edit Class Modal */}
      <Modal
        isOpen={showEditForm}
        onClose={() => {
          setShowEditForm(false);
          setSelectedClass(null);
        }}
        title="Modifier la Classe"
        size="lg"
      >
        {selectedClass && (
          <ClassForm
            onSubmit={handleEditClass}
            onCancel={() => {
              setShowEditForm(false);
              setSelectedClass(null);
            }}
            initialData={selectedClass}
          />
        )}
      </Modal>

      {/* View Class Modal */}
      <Modal
        isOpen={showViewModal}
        onClose={() => {
          setShowViewModal(false);
          setSelectedClass(null);
        }}
        title="Détails de la Classe"
        size="lg"
      >
        {selectedClass && (
          <div className="space-y-6">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-400 to-orange-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-xl">
                  {selectedClass.name}
                </span>
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">{selectedClass.name}</h3>
                <p className="text-gray-600">{selectedClass.level}</p>
                <p className="text-sm text-gray-500">{selectedClass.room}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Informations générales</h4>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Niveau:</span> {selectedClass.level}</p>
                  <p><span className="font-medium">Enseignant principal:</span> {selectedClass.teacher || 'Non assigné'}</p>
                  <p><span className="font-medium">Salle:</span> {selectedClass.room}</p>
                  <p><span className="font-medium">Capacité:</span> {selectedClass.studentCount}/{selectedClass.maxCapacity} élèves</p>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Statut et informations</h4>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Statut:</span> 
                    <span className={`ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                      selectedClass.status === 'active' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {selectedClass.status === 'active' ? 'Active' : 'Inactive'}
                    </span>
                  </p>
                  <p><span className="font-medium">Taux d'occupation:</span> {selectedClass.maxCapacity > 0 ? Math.round((selectedClass.studentCount / selectedClass.maxCapacity) * 100) : 0}%</p>
                  <p><span className="font-medium">Places disponibles:</span> {selectedClass.maxCapacity - selectedClass.studentCount}</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}