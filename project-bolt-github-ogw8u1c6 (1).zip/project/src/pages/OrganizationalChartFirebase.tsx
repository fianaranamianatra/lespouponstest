import React, { useState } from 'react';
import { Users, Crown, GraduationCap, Calculator, FileText, Shield, Wrench, Sparkles, Plus, Edit, Trash2, Eye, Phone, Mail, MapPin } from 'lucide-react';
import { Modal } from '../components/Modal';
import { EmployeeForm } from '../components/forms/EmployeeForm';
import { Avatar } from '../components/Avatar';
import { useFirebaseCollection } from '../hooks/useFirebaseCollection';
import { hierarchyService } from '../lib/firebase/firebaseService';

interface Employee {
  id?: string;
  firstName: string;
  lastName: string;
  position: string;
  department: string;
  level: number;
  parentId?: string;
  email: string;
  phone: string;
  salary: number;
  hireDate: string;
  status: 'active' | 'inactive';
  subjects?: string[];
  classes?: string[];
  createdAt?: Date;
  updatedAt?: Date;
}

const departmentColors = {
  'Direction': 'bg-purple-100 text-purple-800 border-purple-200',
  'Administration': 'bg-blue-100 text-blue-800 border-blue-200',
  'Enseignement': 'bg-green-100 text-green-800 border-green-200',
  'Service': 'bg-orange-100 text-orange-800 border-orange-200'
};

const departmentIcons = {
  'Direction': Crown,
  'Administration': FileText,
  'Enseignement': GraduationCap,
  'Service': Wrench
};

export function OrganizationalChartFirebase() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('');
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [viewMode, setViewMode] = useState<'chart' | 'list' | 'departments'>('chart');

  // Hook Firebase avec synchronisation temps réel
  const {
    data: employees,
    loading,
    error,
    creating,
    updating,
    deleting,
    create,
    update,
    remove
  } = useFirebaseCollection<Employee>(hierarchyService, true);

  const filteredEmployees = employees.filter(employee => {
    const matchesSearch = employee.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.position.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDepartment = selectedDepartment === '' || employee.department === selectedDepartment;
    return matchesSearch && matchesDepartment;
  });

  const departments = [...new Set(employees.map(e => e.department))];
  const totalSalary = employees.reduce((acc, e) => acc + e.salary, 0);
  const activeEmployees = employees.filter(e => e.status === 'active').length;

  const getEmployeesByLevel = (level: number) => {
    return filteredEmployees.filter(e => e.level === level);
  };

  const getSubordinates = (supervisorName: string) => {
    return filteredEmployees.filter(e => {
      const supervisorFullName = supervisorName.split(' ');
      return e.parentId === supervisorName || 
             (supervisorFullName.length >= 2 && 
              e.parentId === supervisorName || 
              (e.parentId && e.parentId.includes(supervisorFullName[0]) && e.parentId.includes(supervisorFullName[1])));
    });
  };

  const handleViewEmployee = (employee: Employee) => {
    setSelectedEmployee(employee);
    setShowViewModal(true);
  };

  const handleEditClick = (employee: Employee) => {
    setSelectedEmployee(employee);
    setShowEditForm(true);
  };

  const handleAddEmployee = async (data: any) => {
    try {
      console.log('🚀 Ajout d\'employé - Données reçues:', data);
      
      // Préparer les données pour Firebase
      const employeeData = {
        firstName: data.firstName,
        lastName: data.lastName,
        position: data.position,
        department: data.department,
        level: parseInt(data.level) || 1,
        parentId: data.parentId || null,
        email: data.email,
        phone: data.phone,
        salary: parseFloat(data.salary) || 0,
        hireDate: data.hireDate || new Date().toISOString().split('T')[0],
        status: data.status || 'active'
      };
      
      console.log('📝 Données formatées pour Firebase:', employeeData);
      
      const employeeId = await create(employeeData);
      console.log('✅ Employé créé avec l\'ID:', employeeId);
      
      setShowAddForm(false);
      
      // Message de succès
      alert('✅ Employé ajouté avec succès !');
      
    } catch (error: any) {
      console.error('❌ Erreur lors de l\'ajout de l\'employé:', error);
      alert('❌ Erreur lors de l\'ajout de l\'employé: ' + error.message);
    }
  };

  const handleEditEmployee = async (data: any) => {
    if (selectedEmployee?.id) {
      try {
        console.log('🔄 Modification d\'employé - Données:', data);
        
        const updateData = {
          ...data,
          level: parseInt(data.level) || 1,
          salary: parseFloat(data.salary) || 0
        };
        
        await update(selectedEmployee.id, updateData);
        console.log('✅ Employé modifié avec succès');
        
        setShowEditForm(false);
        setSelectedEmployee(null);
        
        alert('✅ Employé modifié avec succès !');
        
      } catch (error: any) {
        console.error('❌ Erreur lors de la modification:', error);
        alert('❌ Erreur lors de la modification: ' + error.message);
      }
    }
  };

  const handleDeleteEmployee = async (id: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet employé ?')) {
      try {
        console.log('🗑️ Suppression de l\'employé ID:', id);
        await remove(id);
        console.log('✅ Employé supprimé avec succès');
        alert('✅ Employé supprimé avec succès !');
      } catch (error: any) {
        console.error('❌ Erreur lors de la suppression:', error);
        alert('❌ Erreur lors de la suppression: ' + error.message);
      }
    }
  };

  const renderChart = () => (
    <div className="space-y-8">
      {/* Level 1 - Direction Générale */}
      <div className="text-center">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Direction Générale</h3>
        <div className="flex justify-center">
          {getEmployeesByLevel(1).length > 0 ? (
            getEmployeesByLevel(1).map((employee) => (
              <div key={employee.id} className="relative">
                <div 
                  onClick={() => handleViewEmployee(employee)}
                  className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-6 text-white cursor-pointer hover:shadow-lg transition-all max-w-xs"
                >
                  <div className="text-center">
                    <div className="mx-auto mb-3 relative">
                      <Avatar 
                        firstName={employee.firstName} 
                        lastName={employee.lastName} 
                        size="lg" 
                        showPhoto={true}
                        className="border-4 border-white border-opacity-30"
                      />
                      <div className="absolute -top-1 -right-1 w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center">
                        <Crown className="w-3 h-3 text-yellow-800" />
                      </div>
                    </div>
                    <h4 className="font-bold text-lg">{employee.firstName} {employee.lastName}</h4>
                    <p className="text-purple-100 text-sm">{employee.position}</p>
                    <p className="text-purple-100 text-xs mt-1">{employee.email}</p>
                  </div>
                </div>
                {/* Connection line down */}
                <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-px h-8 bg-gray-300"></div>
              </div>
            ))
          ) : (
            <div className="bg-gray-100 rounded-xl p-6 text-center">
              <Crown className="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">Aucun directeur trouvé</p>
            </div>
          )}
        </div>
      </div>

      {/* Level 2 - Direction Pédagogique */}
      <div className="text-center">
        <div className="flex justify-center space-x-8">
          {getEmployeesByLevel(2).length > 0 ? (
            getEmployeesByLevel(2).map((employee) => (
              <div key={employee.id} className="relative">
                <div 
                  onClick={() => handleViewEmployee(employee)}
                  className="bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl p-6 text-white cursor-pointer hover:shadow-lg transition-all max-w-xs"
                >
                  <div className="text-center">
                    <div className="mx-auto mb-3 relative">
                      <Avatar 
                        firstName={employee.firstName} 
                        lastName={employee.lastName} 
                        size="lg" 
                        showPhoto={true}
                        className="border-4 border-white border-opacity-30"
                      />
                      <div className="absolute -top-1 -right-1 w-6 h-6 bg-indigo-200 rounded-full flex items-center justify-center">
                        <GraduationCap className="w-3 h-3 text-indigo-800" />
                      </div>
                    </div>
                    <h4 className="font-bold">{employee.firstName} {employee.lastName}</h4>
                    <p className="text-indigo-100 text-sm">{employee.position}</p>
                    <p className="text-indigo-100 text-xs mt-1">{employee.email}</p>
                  </div>
                </div>
                {/* Connection line down */}
                <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-px h-8 bg-gray-300"></div>
              </div>
            ))
          ) : (
            <div className="bg-gray-100 rounded-xl p-6 text-center">
              <GraduationCap className="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">Aucun sous-directeur trouvé</p>
            </div>
          )}
        </div>
      </div>

      {/* Level 3 - Départements */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Administration */}
        <div className="space-y-4">
          <h4 className="text-center font-bold text-gray-900">Administration</h4>
          <div className="space-y-3">
            {getEmployeesByLevel(3).filter(e => e.department === 'Administration').length > 0 ? (
              getEmployeesByLevel(3).filter(e => e.department === 'Administration').map((employee) => (
                <div key={employee.id} 
                     onClick={() => handleViewEmployee(employee)}
                     className="bg-blue-50 border border-blue-200 rounded-lg p-4 cursor-pointer hover:shadow-md transition-all">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <Avatar 
                        firstName={employee.firstName} 
                        lastName={employee.lastName} 
                        size="md" 
                        showPhoto={true}
                      />
                      <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-blue-100 rounded-full flex items-center justify-center border-2 border-white">
                        {employee.position.includes('Comptable') ? <Calculator className="w-3 h-3 text-blue-600" /> : <FileText className="w-3 h-3 text-blue-600" />}
                      </div>
                    </div>
                    <div className="flex-1">
                      <h5 className="font-medium text-gray-900">{employee.firstName} {employee.lastName}</h5>
                      <p className="text-sm text-gray-600">{employee.position}</p>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-gray-100 rounded-lg p-4 text-center">
                <p className="text-gray-500">Aucun administrateur trouvé</p>
              </div>
            )}
          </div>
        </div>

        {/* Enseignement */}
        <div className="space-y-4">
          <h4 className="text-center font-bold text-gray-900">Corps Enseignant</h4>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {getEmployeesByLevel(3).filter(e => e.department === 'Enseignement').length > 0 ? (
              getEmployeesByLevel(3).filter(e => e.department === 'Enseignement').map((employee) => (
                <div key={employee.id} 
                     onClick={() => handleViewEmployee(employee)}
                     className="bg-green-50 border border-green-200 rounded-lg p-3 cursor-pointer hover:shadow-md transition-all">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <Avatar 
                        firstName={employee.firstName} 
                        lastName={employee.lastName} 
                        size="sm" 
                        showPhoto={true}
                      />
                      <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-green-100 rounded-full flex items-center justify-center border border-white">
                        <GraduationCap className="w-2.5 h-2.5 text-green-600" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h5 className="font-medium text-gray-900 text-sm">{employee.firstName} {employee.lastName}</h5>
                      <p className="text-xs text-gray-600">{employee.position}</p>
                      {employee.classes && (
                        <p className="text-xs text-green-600">{employee.classes.join(', ')}</p>
                      )}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-gray-100 rounded-lg p-4 text-center">
                <p className="text-gray-500">Aucun enseignant trouvé</p>
              </div>
            )}
          </div>
        </div>

        {/* Service */}
        <div className="space-y-4">
          <h4 className="text-center font-bold text-gray-900">Personnel de Service</h4>
          <div className="space-y-3">
            {getEmployeesByLevel(4).length > 0 ? (
              getEmployeesByLevel(4).map((employee) => (
                <div key={employee.id} 
                     onClick={() => handleViewEmployee(employee)}
                     className="bg-orange-50 border border-orange-200 rounded-lg p-4 cursor-pointer hover:shadow-md transition-all">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <Avatar 
                        firstName={employee.firstName} 
                        lastName={employee.lastName} 
                        size="md" 
                        showPhoto={true}
                      />
                      <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-orange-100 rounded-full flex items-center justify-center border-2 border-white">
                        {employee.position.includes('Gardien') ? <Shield className="w-3 h-3 text-orange-600" /> : 
                         employee.position.includes('Ménage') ? <Sparkles className="w-3 h-3 text-orange-600" /> : 
                         <Wrench className="w-3 h-3 text-orange-600" />}
                      </div>
                    </div>
                    <div className="flex-1">
                      <h5 className="font-medium text-gray-900">{employee.firstName} {employee.lastName}</h5>
                      <p className="text-sm text-gray-600">{employee.position}</p>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-gray-100 rounded-lg p-4 text-center">
                <p className="text-gray-500">Aucun personnel de service trouvé</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  const renderList = () => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      {employees.length === 0 ? (
        <div className="text-center py-12">
          <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun employé enregistré</h3>
          <p className="text-gray-500 mb-6">Commencez par ajouter votre premier employé à l'école.</p>
          <button
            onClick={() => {
              const newEmployee = {
                firstName: 'Jean-Claude',
                lastName: 'RAMAROSON',
                position: 'Directeur Général',
                department: 'Direction',
                level: 1,
                email: 'directeur@lespoupons.mg',
                phone: '+261 34 12 345 67',
                salary: 2500000,
                hireDate: new Date().toISOString().split('T')[0],
                status: 'active'
              };
              handleAddEmployee(newEmployee);
            }}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            Ajouter un Employé
          </button>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Employé</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Poste</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Département</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Superviseur</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Contact</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Salaire</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Statut</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredEmployees.map((employee) => {
                const DepartmentIcon = departmentIcons[employee.department as keyof typeof departmentIcons] || Users;
                return (
                  <tr key={employee.id} className="hover:bg-gray-50 transition-colors">
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-3">
                        <Avatar 
                          firstName={employee.firstName} 
                          lastName={employee.lastName} 
                          size="md" 
                          showPhoto={true}
                        />
                        <div>
                          <p className="font-medium text-gray-900">{employee.firstName} {employee.lastName}</p>
                          <p className="text-sm text-gray-500">Embauché le {new Date(employee.hireDate).toLocaleDateString('fr-FR')}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <p className="font-medium text-gray-900">{employee.position}</p>
                      {employee.classes && (
                        <p className="text-sm text-gray-500">Classes: {employee.classes.join(', ')}</p>
                      )}
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-2">
                        <DepartmentIcon className="w-4 h-4 text-gray-400" />
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${departmentColors[employee.department as keyof typeof departmentColors] || 'bg-gray-100 text-gray-800 border-gray-200'}`}>
                          {employee.department}
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <p className="text-sm text-gray-600">{employee.parentId || 'Aucun'}</p>
                    </td>
                    <td className="py-4 px-6">
                      <div className="space-y-1">
                        <div className="flex items-center text-sm text-gray-600">
                          <Phone className="w-3 h-3 mr-1" />
                          {employee.phone}
                        </div>
                        <div className="flex items-center text-sm text-gray-600">
                          <Mail className="w-3 h-3 mr-1" />
                          {employee.email}
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <p className="font-medium text-gray-900">{employee.salary.toLocaleString()} Ar</p>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        employee.status === 'active' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {employee.status === 'active' ? 'Actif' : 'Inactif'}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-2">
                        <button 
                          onClick={() => handleViewEmployee(employee)}
                          className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => handleEditClick(employee)}
                          disabled={updating}
                          className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors disabled:opacity-50"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => employee.id && handleDeleteEmployee(employee.id)}
                          disabled={deleting}
                          className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  const renderDepartments = () => (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {departments.length > 0 ? (
        departments.map((department) => {
          const departmentEmployees = employees.filter(e => e.department === department);
          const DepartmentIcon = departmentIcons[department as keyof typeof departmentIcons] || Users;
          const departmentSalary = departmentEmployees.reduce((acc, e) => acc + e.salary, 0);
          
          return (
            <div key={department} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex items-center space-x-3 mb-6">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${departmentColors[department as keyof typeof departmentColors] || 'bg-gray-100 text-gray-800'}`}>
                  <DepartmentIcon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900">{department}</h3>
                  <p className="text-sm text-gray-600">{departmentEmployees.length} employés</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-sm text-gray-600">Effectif</p>
                    <p className="text-xl font-bold text-gray-900">{departmentEmployees.length}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-sm text-gray-600">Masse Salariale</p>
                    <p className="text-xl font-bold text-gray-900">{departmentSalary.toLocaleString()} Ar</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium text-gray-900">Personnel</h4>
                  <div className="space-y-1 max-h-40 overflow-y-auto">
                    {departmentEmployees.map((employee) => (
                      <div key={employee.id} 
                           onClick={() => handleViewEmployee(employee)}
                           className="flex items-center justify-between p-2 hover:bg-gray-50 rounded cursor-pointer">
                        <div>
                          <div className="flex items-center space-x-2">
                            <Avatar 
                              firstName={employee.firstName} 
                              lastName={employee.lastName} 
                              size="sm" 
                              showPhoto={true}
                            />
                            <p className="text-sm font-medium text-gray-900">{employee.firstName} {employee.lastName}</p>
                          </div>
                          <p className="text-xs text-gray-500">{employee.position}</p>
                        </div>
                        <span className="text-xs text-gray-400">{employee.salary.toLocaleString()} Ar</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          );
        })
      ) : (
        <div className="col-span-full text-center py-12">
          <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun département trouvé</h3>
          <p className="text-gray-500 mb-6">Commencez par ajouter des employés avec des départements.</p>
        </div>
      )}
    </div>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement de l'organigramme...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <p className="text-red-600">Erreur: {error}</p>
        <button 
          onClick={() => window.location.reload()} 
          className="mt-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
        >
          Réessayer
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Plan Hiérarchique</h1>
          <p className="text-gray-600">Organisation et structure du personnel de l'école</p>
        </div>
        
        <button 
          onClick={() => {
            console.log('🔘 Ouverture du formulaire d\'ajout d\'employé');
            setShowAddForm(true);
          }}
          disabled={creating}
          className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
        >
          {creating ? (
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
          ) : (
            <Plus className="w-4 h-4 mr-2" />
          )}
          Ajouter Employé
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Employés</p>
              <p className="text-2xl font-bold text-gray-900">{employees.length}</p>
            </div>
            <Users className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Actifs</p>
              <p className="text-2xl font-bold text-green-600">{activeEmployees}</p>
            </div>
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              <div className="w-3 h-3 bg-green-600 rounded-full"></div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Départements</p>
              <p className="text-2xl font-bold text-purple-600">{departments.length}</p>
            </div>
            <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
              <div className="w-3 h-3 bg-purple-600 rounded-full"></div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Masse Salariale</p>
              <p className="text-2xl font-bold text-orange-600">{(totalSalary / 1000000).toFixed(1)}M Ar</p>
            </div>
            <Calculator className="w-8 h-8 text-orange-600" />
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col lg:flex-row gap-4 items-center">
          <div className="flex-1">
            <div className="relative">
              <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Rechercher un employé..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="flex gap-2 items-center">
            <select
              value={selectedDepartment}
              onChange={(e) => setSelectedDepartment(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Tous les départements</option>
              {departments.map(dept => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>
            
            <div className="flex border border-gray-300 rounded-lg overflow-hidden">
              <button
                onClick={() => setViewMode('chart')}
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  viewMode === 'chart' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                Organigramme
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  viewMode === 'list' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                Liste
              </button>
              <button
                onClick={() => setViewMode('departments')}
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  viewMode === 'departments' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                Départements
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        {viewMode === 'chart' && renderChart()}
        {viewMode === 'list' && renderList()}
        {viewMode === 'departments' && renderDepartments()}
      </div>

      {/* Add Employee Modal */}
      <Modal
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        title="Ajouter un Employé"
        size="lg"
      >
        <EmployeeForm
          onSubmit={handleAddEmployee}
          onCancel={() => setShowAddForm(false)}
        />
      </Modal>

      {/* Edit Employee Modal */}
      <Modal
        isOpen={showEditForm}
        onClose={() => {
          setShowEditForm(false);
          setSelectedEmployee(null);
        }}
        title="Modifier l'Employé"
        size="lg"
      >
        {selectedEmployee && (
          <EmployeeForm
            onSubmit={handleEditEmployee}
            onCancel={() => {
              setShowEditForm(false);
              setSelectedEmployee(null);
            }}
            initialData={selectedEmployee}
          />
        )}
      </Modal>

      {/* View Employee Modal */}
      <Modal
        isOpen={showViewModal}
        onClose={() => {
          setShowViewModal(false);
          setSelectedEmployee(null);
        }}
        title="Détails de l'Employé"
        size="lg"
      >
        {selectedEmployee && (
          <div className="space-y-6">
            <div className="flex items-center space-x-4">
              <Avatar 
                firstName={selectedEmployee.firstName} 
                lastName={selectedEmployee.lastName} 
                size="xl" 
                showPhoto={true}
              />
              <div>
                <h3 className="text-xl font-bold text-gray-900">
                  {selectedEmployee.firstName} {selectedEmployee.lastName}
                </h3>
                <p className="text-gray-600">{selectedEmployee.position}</p>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${departmentColors[selectedEmployee.department as keyof typeof departmentColors] || 'bg-gray-100 text-gray-800 border-gray-200'}`}>
                  {selectedEmployee.department}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Informations personnelles</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center">
                    <Mail className="w-4 h-4 mr-2 text-gray-400" />
                    <span>{selectedEmployee.email}</span>
                  </div>
                  <div className="flex items-center">
                    <Phone className="w-4 h-4 mr-2 text-gray-400" />
                    <span>{selectedEmployee.phone}</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Informations professionnelles</h4>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Superviseur:</span> {selectedEmployee.parentId || 'Aucun'}</p>
                  <p><span className="font-medium">Salaire:</span> {selectedEmployee.salary.toLocaleString()} Ar</p>
                  <p><span className="font-medium">Date d'embauche:</span> {new Date(selectedEmployee.hireDate).toLocaleDateString('fr-FR')}</p>
                  <p><span className="font-medium">Statut:</span> 
                    <span className={`ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                      selectedEmployee.status === 'active' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {selectedEmployee.status === 'active' ? 'Actif' : 'Inactif'}
                    </span>
                  </p>
                  {selectedEmployee.subjects && (
                    <div>
                      <p className="font-medium">Matières enseignées:</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedEmployee.subjects.map((subject, index) => (
                          <span key={index} className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-800">
                            {subject}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  {selectedEmployee.classes && (
                    <div>
                      <p className="font-medium">Classes:</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedEmployee.classes.map((className, index) => (
                          <span key={index} className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-blue-100 text-blue-800">
                            {className}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}