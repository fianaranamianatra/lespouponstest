import React, { useState } from 'react';
import { Users, Crown, GraduationCap, Calculator, FileText, Shield, Wrench, Sparkles, Plus, Edit, Trash2, Eye, Phone, Mail, MapPin } from 'lucide-react';
import { Modal } from '../components/Modal';
import { Avatar } from '../components/Avatar';

interface Employee {
  id: string;
  firstName: string;
  lastName: string;
  position: string;
  department: string;
  level: number;
  supervisor?: string;
  email: string;
  phone: string;
  address: string;
  salary: number;
  hireDate: string;
  status: 'active' | 'inactive';
  subjects?: string[];
  classes?: string[];
  avatar?: string;
}

const mockEmployees: Employee[] = [
  // Direction
  {
    id: '1',
    firstName: 'Jean-Claude',
    lastName: 'RAMAROSON',
    position: 'Directeur Général',
    department: 'Direction',
    level: 1,
    email: 'directeur@lespoupons.mg',
    phone: '+261 34 12 345 67',
    address: 'Antananarivo, Madagascar',
    salary: 2500000,
    hireDate: '2020-01-15',
    status: 'active'
  },
  {
    id: '2',
    firstName: 'Marie-Claire',
    lastName: 'ANDRIANTSOA',
    position: 'Directrice Pédagogique',
    department: 'Direction',
    level: 2,
    supervisor: 'Jean-Claude RAMAROSON',
    email: 'directrice.pedagogique@lespoupons.mg',
    phone: '+261 34 23 456 78',
    address: 'Antananarivo, Madagascar',
    salary: 2000000,
    hireDate: '2020-02-01',
    status: 'active'
  },
  
  // Administration
  {
    id: '3',
    firstName: 'Hery',
    lastName: 'RAKOTONIRINA',
    position: 'Comptable',
    department: 'Administration',
    level: 3,
    supervisor: 'Jean-Claude RAMAROSON',
    email: 'comptable@lespoupons.mg',
    phone: '+261 34 34 567 89',
    address: 'Antananarivo, Madagascar',
    salary: 1200000,
    hireDate: '2020-03-15',
    status: 'active'
  },
  {
    id: '4',
    firstName: 'Nadia',
    lastName: 'RAZAFY',
    position: 'Secrétaire Générale',
    department: 'Administration',
    level: 3,
    supervisor: 'Jean-Claude RAMAROSON',
    email: 'secretaire@lespoupons.mg',
    phone: '+261 34 45 678 90',
    address: 'Antananarivo, Madagascar',
    salary: 800000,
    hireDate: '2020-04-01',
    status: 'active'
  },
  {
    id: '5',
    firstName: 'Lalaina',
    lastName: 'ANDRIAMAMPIANINA',
    position: 'Assistant Administratif',
    department: 'Administration',
    level: 4,
    supervisor: 'Nadia RAZAFY',
    email: 'assistant.admin@lespoupons.mg',
    phone: '+261 34 56 789 01',
    address: 'Antananarivo, Madagascar',
    salary: 600000,
    hireDate: '2021-01-15',
    status: 'active'
  },

  // Corps Enseignant - Maternelle
  {
    id: '6',
    firstName: 'Volatiana',
    lastName: 'RASOLOFO',
    position: 'Institutrice TPSA',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'institutrice.tpsa@lespoupons.mg',
    phone: '+261 34 67 890 12',
    address: 'Antananarivo, Madagascar',
    salary: 900000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Éveil', 'Motricité', 'Langage'],
    classes: ['TPSA']
  },
  {
    id: '7',
    firstName: 'Miora',
    lastName: 'RANDRIAMANANTSOA',
    position: 'Institutrice TPSB',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'institutrice.tpsb@lespoupons.mg',
    phone: '+261 34 78 901 23',
    address: 'Antananarivo, Madagascar',
    salary: 900000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Éveil', 'Motricité', 'Langage'],
    classes: ['TPSB']
  },
  {
    id: '8',
    firstName: 'Fanja',
    lastName: 'RAKOTOMALALA',
    position: 'Institutrice PSA',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'institutrice.psa@lespoupons.mg',
    phone: '+261 34 89 012 34',
    address: 'Antananarivo, Madagascar',
    salary: 950000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Pré-lecture', 'Pré-écriture', 'Mathématiques de base'],
    classes: ['PSA']
  },
  {
    id: '9',
    firstName: 'Hasina',
    lastName: 'ANDRIANJAFY',
    position: 'Institutrice PSB',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'institutrice.psb@lespoupons.mg',
    phone: '+261 34 90 123 45',
    address: 'Antananarivo, Madagascar',
    salary: 950000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Pré-lecture', 'Pré-écriture', 'Mathématiques de base'],
    classes: ['PSB']
  },
  {
    id: '10',
    firstName: 'Nirina',
    lastName: 'RAHARISON',
    position: 'Institutrice PSC',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'institutrice.psc@lespoupons.mg',
    phone: '+261 34 01 234 56',
    address: 'Antananarivo, Madagascar',
    salary: 950000,
    hireDate: '2021-09-01',
    status: 'active',
    subjects: ['Pré-lecture', 'Pré-écriture', 'Mathématiques de base'],
    classes: ['PSC']
  },

  // Moyenne Section
  {
    id: '11',
    firstName: 'Aina',
    lastName: 'RAZANAKOLONA',
    position: 'Institutrice MS_A',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'institutrice.msa@lespoupons.mg',
    phone: '+261 34 12 345 67',
    address: 'Antananarivo, Madagascar',
    salary: 1000000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Lecture', 'Écriture', 'Mathématiques', 'Sciences'],
    classes: ['MS_A']
  },
  {
    id: '12',
    firstName: 'Hanta',
    lastName: 'RAKOTOZAFY',
    position: 'Institutrice MSB',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'institutrice.msb@lespoupons.mg',
    phone: '+261 34 23 456 78',
    address: 'Antananarivo, Madagascar',
    salary: 1000000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Lecture', 'Écriture', 'Mathématiques', 'Sciences'],
    classes: ['MSB']
  },

  // Grande Section
  {
    id: '13',
    firstName: 'Lova',
    lastName: 'ANDRIAMIHAJA',
    position: 'Institutrice GSA',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'institutrice.gsa@lespoupons.mg',
    phone: '+261 34 34 567 89',
    address: 'Antananarivo, Madagascar',
    salary: 1100000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Français', 'Mathématiques', 'Sciences', 'Arts'],
    classes: ['GSA']
  },
  {
    id: '14',
    firstName: 'Mirana',
    lastName: 'RAKOTONDRASOA',
    position: 'Institutrice GSB',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'institutrice.gsb@lespoupons.mg',
    phone: '+261 34 45 678 90',
    address: 'Antananarivo, Madagascar',
    salary: 1100000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Français', 'Mathématiques', 'Sciences', 'Arts'],
    classes: ['GSB']
  },
  {
    id: '15',
    firstName: 'Tahiry',
    lastName: 'RAZAFIMANDIMBY',
    position: 'Institutrice GSC',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'institutrice.gsc@lespoupons.mg',
    phone: '+261 34 56 789 01',
    address: 'Antananarivo, Madagascar',
    salary: 1100000,
    hireDate: '2021-09-01',
    status: 'active',
    subjects: ['Français', 'Mathématiques', 'Sciences', 'Arts'],
    classes: ['GSC']
  },

  // Primaire
  {
    id: '16',
    firstName: 'Rindra',
    lastName: 'ANDRIANAIVO',
    position: 'Instituteur 11_A (CP)',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'instituteur.11a@lespoupons.mg',
    phone: '+261 34 67 890 12',
    address: 'Antananarivo, Madagascar',
    salary: 1200000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Français', 'Mathématiques', 'Sciences', 'Histoire-Géographie'],
    classes: ['11_A']
  },
  {
    id: '17',
    firstName: 'Solofo',
    lastName: 'RABEMANANJARA',
    position: 'Instituteur 11B (CP)',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'instituteur.11b@lespoupons.mg',
    phone: '+261 34 78 901 23',
    address: 'Antananarivo, Madagascar',
    salary: 1200000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Français', 'Mathématiques', 'Sciences', 'Histoire-Géographie'],
    classes: ['11B']
  },
  {
    id: '18',
    firstName: 'Noro',
    lastName: 'RAKOTOMANGA',
    position: 'Institutrice 10_A (CE1)',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'institutrice.10a@lespoupons.mg',
    phone: '+261 34 89 012 34',
    address: 'Antananarivo, Madagascar',
    salary: 1200000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Français', 'Mathématiques', 'Sciences', 'Histoire-Géographie'],
    classes: ['10_A']
  },
  {
    id: '19',
    firstName: 'Vola',
    lastName: 'ANDRIAMBOAVONJY',
    position: 'Institutrice 10_B (CE1)',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'institutrice.10b@lespoupons.mg',
    phone: '+261 34 90 123 45',
    address: 'Antananarivo, Madagascar',
    salary: 1200000,
    hireDate: '2021-09-01',
    status: 'active',
    subjects: ['Français', 'Mathématiques', 'Sciences', 'Histoire-Géographie'],
    classes: ['10_B']
  },
  {
    id: '20',
    firstName: 'Hery',
    lastName: 'RAZAFINDRABE',
    position: 'Instituteur 9A (CE2)',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'instituteur.9a@lespoupons.mg',
    phone: '+261 34 01 234 56',
    address: 'Antananarivo, Madagascar',
    salary: 1300000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Français', 'Mathématiques', 'Sciences', 'Histoire-Géographie'],
    classes: ['9A']
  },
  {
    id: '21',
    firstName: 'Fara',
    lastName: 'RAKOTONINDRINA',
    position: 'Institutrice 9_B (CE2)',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'institutrice.9b@lespoupons.mg',
    phone: '+261 34 12 345 67',
    address: 'Antananarivo, Madagascar',
    salary: 1300000,
    hireDate: '2021-09-01',
    status: 'active',
    subjects: ['Français', 'Mathématiques', 'Sciences', 'Histoire-Géographie'],
    classes: ['9_B']
  },
  {
    id: '22',
    firstName: 'Tiana',
    lastName: 'ANDRIAMAMPIONONA',
    position: 'Instituteur 8 (CM1)',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'instituteur.8@lespoupons.mg',
    phone: '+261 34 23 456 78',
    address: 'Antananarivo, Madagascar',
    salary: 1400000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Français', 'Mathématiques', 'Sciences', 'Histoire-Géographie', 'Anglais'],
    classes: ['8']
  },
  {
    id: '23',
    firstName: 'Mamy',
    lastName: 'RAKOTOZANANY',
    position: 'Institutrice 7 (CM2)',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'institutrice.7@lespoupons.mg',
    phone: '+261 34 34 567 89',
    address: 'Antananarivo, Madagascar',
    salary: 1500000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Français', 'Mathématiques', 'Sciences', 'Histoire-Géographie', 'Anglais'],
    classes: ['7']
  },

  // Classes Spécialisées
  {
    id: '24',
    firstName: 'Soa',
    lastName: 'RAKOTONIAINA',
    position: 'Éducatrice Spécialisée CS',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'educatrice.cs@lespoupons.mg',
    phone: '+261 34 45 678 90',
    address: 'Antananarivo, Madagascar',
    salary: 1100000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Éducation spécialisée', 'Psychomotricité', 'Langage'],
    classes: ['CS']
  },
  {
    id: '25',
    firstName: 'Nomena',
    lastName: 'ANDRIAMIHANTA',
    position: 'Responsable Garderie',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'responsable.garderie@lespoupons.mg',
    phone: '+261 34 56 789 01',
    address: 'Antananarivo, Madagascar',
    salary: 800000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Garde d\'enfants', 'Activités ludiques'],
    classes: ['GARDERIE']
  },

  // Professeurs Spécialisés
  {
    id: '26',
    firstName: 'Andry',
    lastName: 'RAKOTOMAVO',
    position: 'Professeur d\'Anglais',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'prof.anglais@lespoupons.mg',
    phone: '+261 34 67 890 12',
    address: 'Antananarivo, Madagascar',
    salary: 1000000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Anglais'],
    classes: ['8', '7', 'GSA', 'GSB', 'GSC']
  },
  {
    id: '27',
    firstName: 'Malala',
    lastName: 'RAZANAMPARANY',
    position: 'Professeur d\'Éducation Physique',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'prof.eps@lespoupons.mg',
    phone: '+261 34 78 901 23',
    address: 'Antananarivo, Madagascar',
    salary: 900000,
    hireDate: '2020-09-01',
    status: 'active',
    subjects: ['Éducation Physique et Sportive'],
    classes: ['Toutes classes']
  },
  {
    id: '28',
    firstName: 'Haja',
    lastName: 'ANDRIAMAMPIANINA',
    position: 'Professeur d\'Arts Plastiques',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'prof.arts@lespoupons.mg',
    phone: '+261 34 89 012 34',
    address: 'Antananarivo, Madagascar',
    salary: 800000,
    hireDate: '2021-09-01',
    status: 'active',
    subjects: ['Arts Plastiques', 'Dessin'],
    classes: ['Toutes classes']
  },
  {
    id: '29',
    firstName: 'Diary',
    lastName: 'RASOLONJATOVO',
    position: 'Professeur de Musique',
    department: 'Enseignement',
    level: 3,
    supervisor: 'Marie-Claire ANDRIANTSOA',
    email: 'prof.musique@lespoupons.mg',
    phone: '+261 34 90 123 45',
    address: 'Antananarivo, Madagascar',
    salary: 700000,
    hireDate: '2021-09-01',
    status: 'active',
    subjects: ['Musique', 'Chant'],
    classes: ['Toutes classes']
  },

  // Personnel de Service
  {
    id: '30',
    firstName: 'Koto',
    lastName: 'RAZAFY',
    position: 'Gardien Principal',
    department: 'Service',
    level: 4,
    supervisor: 'Nadia RAZAFY',
    email: 'gardien@lespoupons.mg',
    phone: '+261 34 01 234 56',
    address: 'Antananarivo, Madagascar',
    salary: 500000,
    hireDate: '2020-01-15',
    status: 'active'
  },
  {
    id: '31',
    firstName: 'Bema',
    lastName: 'ANDRIAMANANTSOA',
    position: 'Gardien de Nuit',
    department: 'Service',
    level: 4,
    supervisor: 'Koto RAZAFY',
    email: 'gardien.nuit@lespoupons.mg',
    phone: '+261 34 12 345 67',
    address: 'Antananarivo, Madagascar',
    salary: 450000,
    hireDate: '2020-02-01',
    status: 'active'
  },
  {
    id: '32',
    firstName: 'Voahangy',
    lastName: 'RAKOTONIRINA',
    position: 'Femme de Ménage Principal',
    department: 'Service',
    level: 4,
    supervisor: 'Nadia RAZAFY',
    email: 'menage@lespoupons.mg',
    phone: '+261 34 23 456 78',
    address: 'Antananarivo, Madagascar',
    salary: 450000,
    hireDate: '2020-01-15',
    status: 'active'
  },
  {
    id: '33',
    firstName: 'Nirina',
    lastName: 'RASOLOFO',
    position: 'Femme de Ménage',
    department: 'Service',
    level: 4,
    supervisor: 'Voahangy RAKOTONIRINA',
    email: 'menage2@lespoupons.mg',
    phone: '+261 34 34 567 89',
    address: 'Antananarivo, Madagascar',
    salary: 400000,
    hireDate: '2020-03-01',
    status: 'active'
  },
  {
    id: '34',
    firstName: 'Rabe',
    lastName: 'ANDRIAMAMPIONONA',
    position: 'Agent de Maintenance',
    department: 'Service',
    level: 4,
    supervisor: 'Nadia RAZAFY',
    email: 'maintenance@lespoupons.mg',
    phone: '+261 34 45 678 90',
    address: 'Antananarivo, Madagascar',
    salary: 600000,
    hireDate: '2020-04-15',
    status: 'active'
  },
  {
    id: '35',
    firstName: 'Sanda',
    lastName: 'RAKOTONDRAZAKA',
    position: 'Cuisinière',
    department: 'Service',
    level: 4,
    supervisor: 'Nadia RAZAFY',
    email: 'cuisine@lespoupons.mg',
    phone: '+261 34 56 789 01',
    address: 'Antananarivo, Madagascar',
    salary: 550000,
    hireDate: '2020-05-01',
    status: 'active'
  },
  {
    id: '36',
    firstName: 'Hanta',
    lastName: 'RAHARIMANANTSOA',
    position: 'Aide Cuisinière',
    department: 'Service',
    level: 4,
    supervisor: 'Sanda RAKOTONDRAZAKA',
    email: 'aide.cuisine@lespoupons.mg',
    phone: '+261 34 67 890 12',
    address: 'Antananarivo, Madagascar',
    salary: 400000,
    hireDate: '2021-01-15',
    status: 'active'
  }
];

const departmentColors = {
  'Direction': 'bg-purple-100 text-purple-800 border-purple-200',
  'Administration': 'bg-blue-100 text-blue-800 border-blue-200',
  'Enseignement': 'bg-green-100 text-green-800 border-green-200',
  'Service': 'bg-orange-100 text-orange-800 border-orange-200'
};

const departmentIcons = {
  'Direction': Crown,
  'Administration': FileText,
  'Enseignement': GraduationCap,
  'Service': Wrench
};

export function OrganizationalChart() {
  const [employees, setEmployees] = useState<Employee[]>(mockEmployees);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('');
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [showViewModal, setShowViewModal] = useState(false);
  const [viewMode, setViewMode] = useState<'chart' | 'list' | 'departments'>('chart');

  const filteredEmployees = employees.filter(employee => {
    const matchesSearch = employee.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.position.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDepartment = selectedDepartment === '' || employee.department === selectedDepartment;
    return matchesSearch && matchesDepartment;
  });

  const departments = [...new Set(employees.map(e => e.department))];
  const totalSalary = employees.reduce((acc, e) => acc + e.salary, 0);
  const activeEmployees = employees.filter(e => e.status === 'active').length;

  const getEmployeesByLevel = (level: number) => {
    return filteredEmployees.filter(e => e.level === level);
  };

  const getSubordinates = (supervisorName: string) => {
    return filteredEmployees.filter(e => e.supervisor === supervisorName);
  };

  const handleViewEmployee = (employee: Employee) => {
    setSelectedEmployee(employee);
    setShowViewModal(true);
  };

  const renderChart = () => (
    <div className="space-y-8">
      {/* Level 1 - Direction Générale */}
      <div className="text-center">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Direction Générale</h3>
        <div className="flex justify-center">
          {getEmployeesByLevel(1).map((employee) => (
            <div key={employee.id} className="relative">
              <div 
                onClick={() => handleViewEmployee(employee)}
                className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-6 text-white cursor-pointer hover:shadow-lg transition-all max-w-xs"
              >
                <div className="text-center">
                  <div className="mx-auto mb-3 relative">
                    <Avatar 
                      firstName={employee.firstName} 
                      lastName={employee.lastName} 
                      size="lg" 
                      showPhoto={true}
                      className="border-4 border-white border-opacity-30"
                    />
                    <div className="absolute -top-1 -right-1 w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center">
                      <Crown className="w-3 h-3 text-yellow-800" />
                    </div>
                  </div>
                  <h4 className="font-bold text-lg">{employee.firstName} {employee.lastName}</h4>
                  <p className="text-purple-100 text-sm">{employee.position}</p>
                  <p className="text-purple-100 text-xs mt-1">{employee.email}</p>
                </div>
              </div>
              {/* Connection line down */}
              <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-px h-8 bg-gray-300"></div>
            </div>
          ))}
        </div>
      </div>

      {/* Level 2 - Direction Pédagogique */}
      <div className="text-center">
        <div className="flex justify-center space-x-8">
          {getEmployeesByLevel(2).map((employee) => (
            <div key={employee.id} className="relative">
              <div 
                onClick={() => handleViewEmployee(employee)}
                className="bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl p-6 text-white cursor-pointer hover:shadow-lg transition-all max-w-xs"
              >
                <div className="text-center">
                  <div className="mx-auto mb-3 relative">
                    <Avatar 
                      firstName={employee.firstName} 
                      lastName={employee.lastName} 
                      size="lg" 
                      showPhoto={true}
                      className="border-4 border-white border-opacity-30"
                    />
                    <div className="absolute -top-1 -right-1 w-6 h-6 bg-indigo-200 rounded-full flex items-center justify-center">
                      <GraduationCap className="w-3 h-3 text-indigo-800" />
                    </div>
                  </div>
                  <h4 className="font-bold">{employee.firstName} {employee.lastName}</h4>
                  <p className="text-indigo-100 text-sm">{employee.position}</p>
                  <p className="text-indigo-100 text-xs mt-1">{employee.email}</p>
                </div>
              </div>
              {/* Connection line down */}
              <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-px h-8 bg-gray-300"></div>
            </div>
          ))}
        </div>
      </div>

      {/* Level 3 - Départements */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Administration */}
        <div className="space-y-4">
          <h4 className="text-center font-bold text-gray-900">Administration</h4>
          <div className="space-y-3">
            {getEmployeesByLevel(3).filter(e => e.department === 'Administration').map((employee) => (
              <div key={employee.id} 
                   onClick={() => handleViewEmployee(employee)}
                   className="bg-blue-50 border border-blue-200 rounded-lg p-4 cursor-pointer hover:shadow-md transition-all">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Avatar 
                      firstName={employee.firstName} 
                      lastName={employee.lastName} 
                      size="md" 
                      showPhoto={true}
                    />
                    <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-blue-100 rounded-full flex items-center justify-center border-2 border-white">
                      {employee.position.includes('Comptable') ? <Calculator className="w-3 h-3 text-blue-600" /> : <FileText className="w-3 h-3 text-blue-600" />}
                    </div>
                  </div>
                  <div className="flex-1">
                    <h5 className="font-medium text-gray-900">{employee.firstName} {employee.lastName}</h5>
                    <p className="text-sm text-gray-600">{employee.position}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Enseignement */}
        <div className="space-y-4">
          <h4 className="text-center font-bold text-gray-900">Corps Enseignant</h4>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {getEmployeesByLevel(3).filter(e => e.department === 'Enseignement').map((employee) => (
              <div key={employee.id} 
                   onClick={() => handleViewEmployee(employee)}
                   className="bg-green-50 border border-green-200 rounded-lg p-3 cursor-pointer hover:shadow-md transition-all">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Avatar 
                      firstName={employee.firstName} 
                      lastName={employee.lastName} 
                      size="sm" 
                      showPhoto={true}
                    />
                    <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-green-100 rounded-full flex items-center justify-center border border-white">
                      <GraduationCap className="w-2.5 h-2.5 text-green-600" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <h5 className="font-medium text-gray-900 text-sm">{employee.firstName} {employee.lastName}</h5>
                    <p className="text-xs text-gray-600">{employee.position}</p>
                    {employee.classes && (
                      <p className="text-xs text-green-600">{employee.classes.join(', ')}</p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Service */}
        <div className="space-y-4">
          <h4 className="text-center font-bold text-gray-900">Personnel de Service</h4>
          <div className="space-y-3">
            {getEmployeesByLevel(4).map((employee) => (
              <div key={employee.id} 
                   onClick={() => handleViewEmployee(employee)}
                   className="bg-orange-50 border border-orange-200 rounded-lg p-4 cursor-pointer hover:shadow-md transition-all">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Avatar 
                      firstName={employee.firstName} 
                      lastName={employee.lastName} 
                      size="md" 
                      showPhoto={true}
                    />
                    <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-orange-100 rounded-full flex items-center justify-center border-2 border-white">
                      {employee.position.includes('Gardien') ? <Shield className="w-3 h-3 text-orange-600" /> : 
                       employee.position.includes('Ménage') ? <Sparkles className="w-3 h-3 text-orange-600" /> : 
                       <Wrench className="w-3 h-3 text-orange-600" />}
                    </div>
                  </div>
                  <div className="flex-1">
                    <h5 className="font-medium text-gray-900">{employee.firstName} {employee.lastName}</h5>
                    <p className="text-sm text-gray-600">{employee.position}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderList = () => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Employé</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Poste</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Département</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Superviseur</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Contact</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Salaire</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Statut</th>
              <th className="text-left py-3 px-6 font-medium text-gray-900">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredEmployees.map((employee) => {
              const DepartmentIcon = departmentIcons[employee.department as keyof typeof departmentIcons];
              return (
                <tr key={employee.id} className="hover:bg-gray-50 transition-colors">
                  <td className="py-4 px-6">
                    <div className="flex items-center space-x-3">
                      <Avatar 
                        firstName={employee.firstName} 
                        lastName={employee.lastName} 
                        size="md" 
                        showPhoto={true}
                      />
                      <div>
                        <p className="font-medium text-gray-900">{employee.firstName} {employee.lastName}</p>
                        <p className="text-sm text-gray-500">Embauché le {new Date(employee.hireDate).toLocaleDateString('fr-FR')}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <p className="font-medium text-gray-900">{employee.position}</p>
                    {employee.classes && (
                      <p className="text-sm text-gray-500">Classes: {employee.classes.join(', ')}</p>
                    )}
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center space-x-2">
                      <DepartmentIcon className="w-4 h-4 text-gray-400" />
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${departmentColors[employee.department as keyof typeof departmentColors]}`}>
                        {employee.department}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <p className="text-sm text-gray-600">{employee.supervisor || 'Aucun'}</p>
                  </td>
                  <td className="py-4 px-6">
                    <div className="space-y-1">
                      <div className="flex items-center text-sm text-gray-600">
                        <Phone className="w-3 h-3 mr-1" />
                        {employee.phone}
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <Mail className="w-3 h-3 mr-1" />
                        {employee.email}
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <p className="font-medium text-gray-900">{employee.salary.toLocaleString()} Ar</p>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      employee.status === 'active' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {employee.status === 'active' ? 'Actif' : 'Inactif'}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <button 
                      onClick={() => handleViewEmployee(employee)}
                      className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderDepartments = () => (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {departments.map((department) => {
        const departmentEmployees = employees.filter(e => e.department === department);
        const DepartmentIcon = departmentIcons[department as keyof typeof departmentIcons];
        const departmentSalary = departmentEmployees.reduce((acc, e) => acc + e.salary, 0);
        
        return (
          <div key={department} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center space-x-3 mb-6">
              <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${departmentColors[department as keyof typeof departmentColors]}`}>
                <DepartmentIcon className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-gray-900">{department}</h3>
                <p className="text-sm text-gray-600">{departmentEmployees.length} employés</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-sm text-gray-600">Effectif</p>
                  <p className="text-xl font-bold text-gray-900">{departmentEmployees.length}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-sm text-gray-600">Masse Salariale</p>
                  <p className="text-xl font-bold text-gray-900">{departmentSalary.toLocaleString()} Ar</p>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium text-gray-900">Personnel</h4>
                <div className="space-y-1 max-h-40 overflow-y-auto">
                  {departmentEmployees.map((employee) => (
                    <div key={employee.id} 
                         onClick={() => handleViewEmployee(employee)}
                         className="flex items-center justify-between p-2 hover:bg-gray-50 rounded cursor-pointer">
                      <div>
                        <div className="flex items-center space-x-2">
                          <Avatar 
                            firstName={employee.firstName} 
                            lastName={employee.lastName} 
                            size="sm" 
                            showPhoto={true}
                          />
                          <p className="text-sm font-medium text-gray-900">{employee.firstName} {employee.lastName}</p>
                        </div>
                        <p className="text-xs text-gray-500">{employee.position}</p>
                      </div>
                      <span className="text-xs text-gray-400">{employee.salary.toLocaleString()} Ar</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Plan Hiérarchique</h1>
          <p className="text-gray-600">Organisation et structure du personnel de l'école</p>
        </div>
        
        <button className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          <Plus className="w-4 h-4 mr-2" />
          Ajouter Employé
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Employés</p>
              <p className="text-2xl font-bold text-gray-900">{employees.length}</p>
            </div>
            <Users className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Actifs</p>
              <p className="text-2xl font-bold text-green-600">{activeEmployees}</p>
            </div>
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              <div className="w-3 h-3 bg-green-600 rounded-full"></div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Départements</p>
              <p className="text-2xl font-bold text-purple-600">{departments.length}</p>
            </div>
            <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
              <div className="w-3 h-3 bg-purple-600 rounded-full"></div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Masse Salariale</p>
              <p className="text-2xl font-bold text-orange-600">{(totalSalary / 1000000).toFixed(1)}M Ar</p>
            </div>
            <Calculator className="w-8 h-8 text-orange-600" />
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col lg:flex-row gap-4 items-center">
          <div className="flex-1">
            <div className="relative">
              <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Rechercher un employé..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="flex gap-2 items-center">
            <select
              value={selectedDepartment}
              onChange={(e) => setSelectedDepartment(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Tous les départements</option>
              {departments.map(dept => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>
            
            <div className="flex border border-gray-300 rounded-lg overflow-hidden">
              <button
                onClick={() => setViewMode('chart')}
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  viewMode === 'chart' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                Organigramme
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  viewMode === 'list' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                Liste
              </button>
              <button
                onClick={() => setViewMode('departments')}
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  viewMode === 'departments' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                Départements
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        {viewMode === 'chart' && renderChart()}
        {viewMode === 'list' && renderList()}
        {viewMode === 'departments' && renderDepartments()}
      </div>

      {/* View Employee Modal */}
      <Modal
        isOpen={showViewModal}
        onClose={() => {
          setShowViewModal(false);
          setSelectedEmployee(null);
        }}
        title="Détails de l'Employé"
        size="lg"
      >
        {selectedEmployee && (
          <div className="space-y-6">
            <div className="flex items-center space-x-4">
              <Avatar 
                firstName={selectedEmployee.firstName} 
                lastName={selectedEmployee.lastName} 
                size="xl" 
                showPhoto={true}
              />
              <div>
                <h3 className="text-xl font-bold text-gray-900">
                  {selectedEmployee.firstName} {selectedEmployee.lastName}
                </h3>
                <p className="text-gray-600">{selectedEmployee.position}</p>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${departmentColors[selectedEmployee.department as keyof typeof departmentColors]}`}>
                  {selectedEmployee.department}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Informations personnelles</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center">
                    <Mail className="w-4 h-4 mr-2 text-gray-400" />
                    <span>{selectedEmployee.email}</span>
                  </div>
                  <div className="flex items-center">
                    <Phone className="w-4 h-4 mr-2 text-gray-400" />
                    <span>{selectedEmployee.phone}</span>
                  </div>
                  <div className="flex items-center">
                    <MapPin className="w-4 h-4 mr-2 text-gray-400" />
                    <span>{selectedEmployee.address}</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Informations professionnelles</h4>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Superviseur:</span> {selectedEmployee.supervisor || 'Aucun'}</p>
                  <p><span className="font-medium">Salaire:</span> {selectedEmployee.salary.toLocaleString()} Ar</p>
                  <p><span className="font-medium">Date d'embauche:</span> {new Date(selectedEmployee.hireDate).toLocaleDateString('fr-FR')}</p>
                  <p><span className="font-medium">Statut:</span> 
                    <span className={`ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                      selectedEmployee.status === 'active' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {selectedEmployee.status === 'active' ? 'Actif' : 'Inactif'}
                    </span>
                  </p>
                  {selectedEmployee.subjects && (
                    <div>
                      <p className="font-medium">Matières enseignées:</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedEmployee.subjects.map((subject, index) => (
                          <span key={index} className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-800">
                            {subject}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  {selectedEmployee.classes && (
                    <div>
                      <p className="font-medium">Classes:</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedEmployee.classes.map((className, index) => (
                          <span key={index} className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-blue-100 text-blue-800">
                            {className}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}