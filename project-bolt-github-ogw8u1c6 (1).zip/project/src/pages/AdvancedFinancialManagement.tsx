import React, { useState } from 'react';
import { Search, Plus, Filter, DollarSign, Users, Calendar, TrendingUp, Download, Eye, Edit, Trash2 } from 'lucide-react';
import { Modal } from '../components/Modal';
import FinancialItemForm from '../components/forms/FinancialItemForm';
import { Avatar } from '../components/Avatar';
import { useFirebaseCollection } from '../hooks/useFirebaseCollection';
import { advancedFinancesService } from '../lib/firebase/firebaseService';

interface FinancialItem {
  id?: string;
  type: 'salary' | 'registration_fee' | 'extracurricular' | 'canteen' | 'transport' | 'electricity' | 'other';
  category: string;
  employeeName?: string;
  studentName?: string;
  amount: number;
  month: string;
  dueDate: string;
  status: 'pending' | 'paid' | 'overdue';
  description: string;
  reference: string;
  createdAt?: Date;
  updatedAt?: Date;
}

const typeColors = {
  salary: 'bg-blue-100 text-blue-800',
  registration_fee: 'bg-green-100 text-green-800',
  extracurricular: 'bg-purple-100 text-purple-800',
  canteen: 'bg-orange-100 text-orange-800',
  transport: 'bg-yellow-100 text-yellow-800',
  electricity: 'bg-cyan-100 text-cyan-800',
  other: 'bg-gray-100 text-gray-800'
};

const typeLabels = {
  salary: 'Salaire',
  registration_fee: 'Frais d\'inscription',
  extracurricular: 'Activités Parascolaires',
  canteen: 'Cantine',
  transport: 'Transport',
  electricity: 'Électricité',
  other: 'Autre'
};

const statusColors = {
  pending: 'bg-yellow-100 text-yellow-800',
  paid: 'bg-green-100 text-green-800',
  overdue: 'bg-red-100 text-red-800'
};

const statusLabels = {
  pending: 'En attente',
  paid: 'Payé',
  overdue: 'En retard'
};

const monthLabels = {
  janvier: 'Janvier',
  fevrier: 'Février',
  mars: 'Mars',
  avril: 'Avril',
  mai: 'Mai',
  juin: 'Juin',
  juillet: 'Juillet',
  aout: 'Août',
  septembre: 'Septembre',
  octobre: 'Octobre',
  novembre: 'Novembre',
  decembre: 'Décembre'
};

export function AdvancedFinancialManagement() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedType, setSelectedType] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [selectedItem, setSelectedItem] = useState<FinancialItem | null>(null);

  // Hook Firebase avec synchronisation temps réel
  const {
    data: financialItems,
    loading,
    error,
    creating,
    updating,
    deleting,
    create,
    update,
    remove
  } = useFirebaseCollection<FinancialItem>(advancedFinancesService, true);

  const filteredItems = financialItems.filter(item => {
    const matchesSearch = item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (item.employeeName && item.employeeName.toLowerCase().includes(searchTerm.toLowerCase())) ||
                         (item.studentName && item.studentName.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesType = selectedType === '' || item.type === selectedType;
    const matchesStatus = selectedStatus === '' || item.status === selectedStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  // Calculs des statistiques
  const totalAmount = financialItems.reduce((acc, item) => acc + item.amount, 0);
  const paidAmount = financialItems.filter(item => item.status === 'paid').reduce((acc, item) => acc + item.amount, 0);
  const pendingAmount = financialItems.filter(item => item.status === 'pending').reduce((acc, item) => acc + item.amount, 0);
  const overdueAmount = financialItems.filter(item => item.status === 'overdue').reduce((acc, item) => acc + item.amount, 0);

  // Statistiques par type
  const salaryTotal = financialItems.filter(item => item.type === 'salary').reduce((acc, item) => acc + item.amount, 0);
  const registrationTotal = financialItems.filter(item => item.type === 'registration_fee').reduce((acc, item) => acc + item.amount, 0);
  const extracurricularTotal = financialItems.filter(item => item.type === 'extracurricular').reduce((acc, item) => acc + item.amount, 0);
  const canteenTotal = financialItems.filter(item => item.type === 'canteen').reduce((acc, item) => acc + item.amount, 0);
  const transportTotal = financialItems.filter(item => item.type === 'transport').reduce((acc, item) => acc + item.amount, 0);
  const electricityTotal = financialItems.filter(item => item.type === 'electricity').reduce((acc, item) => acc + item.amount, 0);

  const handleAddItem = async (data: any) => {
    try {
      console.log('🚀 Ajout d\'élément financier - Données reçues:', data);
      
      const itemData = {
        type: data.type,
        category: data.category,
        employeeName: data.beneficiaryType === 'employee' ? data.beneficiary : null,
        studentName: data.beneficiaryType === 'student' ? data.beneficiary : null,
        amount: parseFloat(data.amount),
        frequency: data.frequency,
        dueDate: data.dueDate,
        status: data.status || 'pending',
        description: data.description,
        reference: data.reference || `FIN-${Date.now()}`
      };
      
      console.log('📝 Données formatées pour Firebase:', itemData);
      
      const itemId = await create(itemData);
      console.log('✅ Élément créé avec l\'ID:', itemId);
      
      setShowAddForm(false);
      alert('✅ Élément financier ajouté avec succès !');
      
    } catch (error: any) {
      console.error('❌ Erreur lors de l\'ajout:', error);
      alert('❌ Erreur lors de l\'ajout: ' + error.message);
    }
  };

  const handleEditItem = async (data: any) => {
    if (selectedItem?.id) {
      try {
        console.log('🔄 Modification d\'élément financier - Données:', data);
        
        const updateData = {
          ...data,
          amount: parseFloat(data.amount),
          employeeName: data.beneficiaryType === 'employee' ? data.beneficiary : null,
          studentName: data.beneficiaryType === 'student' ? data.beneficiary : null
        };
          month: data.month,
        await update(selectedItem.id, updateData);
        console.log('✅ Élément modifié avec succès');
        
        setShowEditForm(false);
        setSelectedItem(null);
        alert('✅ Élément modifié avec succès !');
        
      } catch (error: any) {
        console.error('❌ Erreur lors de la modification:', error);
        alert('❌ Erreur lors de la modification: ' + error.message);
      }
    }
  };

  const handleDeleteItem = async (id: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet élément ?')) {
      try {
        console.log('🗑️ Suppression de l\'élément ID:', id);
        await remove(id);
        console.log('✅ Élément supprimé avec succès');
        alert('✅ Élément supprimé avec succès !');
      } catch (error: any) {
        console.error('❌ Erreur lors de la suppression:', error);
        alert('❌ Erreur lors de la suppression: ' + error.message);
      }
    }
  };

  const handleViewItem = (item: FinancialItem) => {
    setSelectedItem(item);
    setShowViewModal(true);
  };

  const handleEditClick = (item: FinancialItem) => {
    setSelectedItem(item);
    setShowEditForm(true);
  };

  const handleExport = () => {
    alert('Export des données financières en cours...');
  };

  const handleGeneratePayroll = () => {
    alert('Génération de la fiche de paie en cours...');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement des données financières...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <p className="text-red-600">Erreur: {error}</p>
        <button 
          onClick={() => window.location.reload()} 
          className="mt-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
        >
          Réessayer
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Gestion Financière Avancée</h1>
          <p className="text-gray-600">Salaires, frais d'inscription, activités et services</p>
        </div>
        
        <div className="flex gap-2">
          <button 
            onClick={handleGeneratePayroll}
            className="inline-flex items-center px-4 py-2 border border-blue-300 text-blue-700 rounded-lg hover:bg-blue-50 transition-colors"
          >
            <Users className="w-4 h-4 mr-2" />
            Fiche de Paie
          </button>
          <button 
            onClick={handleExport}
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Download className="w-4 h-4 mr-2" />
            Exporter
          </button>
          <button
            onClick={() => {
              console.log('🔘 Ouverture du formulaire d\'ajout d\'élément financier');
              setShowAddForm(true);
            }}
            disabled={creating}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
          >
            {creating ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
            ) : (
              <Plus className="w-4 h-4 mr-2" />
            )}
            Nouvel Élément
          </button>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Rechercher par description, employé ou étudiant..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="flex gap-2">
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Tous les types</option>
              {Object.entries(typeLabels).map(([key, label]) => (
                <option key={key} value={key}>{label}</option>
              ))}
            </select>
            
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Tous les statuts</option>
              {Object.entries(statusLabels).map(([key, label]) => (
                <option key={key} value={key}>{label}</option>
              ))}
            </select>
            
            <button className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Filter className="w-4 h-4 mr-2" />
              Filtres
            </button>
          </div>
        </div>
      </div>

      {/* Financial Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Général</p>
              <p className="text-2xl font-bold text-gray-900">{totalAmount.toLocaleString()} Ar</p>
            </div>
            <DollarSign className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Payé</p>
              <p className="text-2xl font-bold text-green-600">{paidAmount.toLocaleString()} Ar</p>
            </div>
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              <div className="w-3 h-3 bg-green-600 rounded-full"></div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">En Attente</p>
              <p className="text-2xl font-bold text-yellow-600">{pendingAmount.toLocaleString()} Ar</p>
            </div>
            <Calendar className="w-8 h-8 text-yellow-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">En Retard</p>
              <p className="text-2xl font-bold text-red-600">{overdueAmount.toLocaleString()} Ar</p>
            </div>
            <TrendingUp className="w-8 h-8 text-red-600" />
          </div>
        </div>
      </div>

      {/* Category Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-7 gap-4">
        <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
          <h3 className="font-medium text-blue-800 mb-2">Salaires</h3>
          <p className="text-2xl font-bold text-blue-600">{salaryTotal.toLocaleString()} Ar</p>
          <p className="text-sm text-blue-600">{financialItems.filter(item => item.type === 'salary').length} éléments</p>
        </div>
        
        <div className="bg-green-50 rounded-lg p-4 border border-green-200">
          <h3 className="font-medium text-green-800 mb-2">Inscriptions</h3>
          <p className="text-2xl font-bold text-green-600">{registrationTotal.toLocaleString()} Ar</p>
          <p className="text-sm text-green-600">{financialItems.filter(item => item.type === 'registration_fee').length} éléments</p>
        </div>
        
        <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
          <h3 className="font-medium text-purple-800 mb-2">Parascolaires</h3>
          <p className="text-2xl font-bold text-purple-600">{extracurricularTotal.toLocaleString()} Ar</p>
          <p className="text-sm text-purple-600">{financialItems.filter(item => item.type === 'extracurricular').length} éléments</p>
        </div>
        
        <div className="bg-orange-50 rounded-lg p-4 border border-orange-200">
          <h3 className="font-medium text-orange-800 mb-2">Cantine</h3>
          <p className="text-2xl font-bold text-orange-600">{canteenTotal.toLocaleString()} Ar</p>
          <p className="text-sm text-orange-600">{financialItems.filter(item => item.type === 'canteen').length} éléments</p>
        </div>
        
        <div className="bg-yellow-50 rounded-lg p-4 border border-yellow-200">
          <h3 className="font-medium text-yellow-800 mb-2">Transport</h3>
          <p className="text-2xl font-bold text-yellow-600">{transportTotal.toLocaleString()} Ar</p>
          <p className="text-sm text-yellow-600">{financialItems.filter(item => item.type === 'transport').length} éléments</p>
        </div>
        
        <div className="bg-cyan-50 rounded-lg p-4 border border-cyan-200">
          <h3 className="font-medium text-cyan-800 mb-2">Électricité</h3>
          <p className="text-2xl font-bold text-cyan-600">{electricityTotal.toLocaleString()} Ar</p>
          <p className="text-sm text-cyan-600">{financialItems.filter(item => item.type === 'electricity').length} éléments</p>
        </div>
        
        <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
          <h3 className="font-medium text-gray-800 mb-2">Autres</h3>
          <p className="text-2xl font-bold text-gray-600">
            {financialItems.filter(item => item.type === 'other').reduce((acc, item) => acc + item.amount, 0).toLocaleString()} Ar
          </p>
          <p className="text-sm text-gray-600">{financialItems.filter(item => item.type === 'other').length} éléments</p>
        </div>
      </div>

      {/* Financial Items Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        {financialItems.length === 0 ? (
          <div className="text-center py-12">
            <DollarSign className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun élément financier enregistré</h3>
            <p className="text-gray-500 mb-6">Commencez par ajouter votre premier élément financier.</p>
            <button
              onClick={() => setShowAddForm(true)}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="w-4 h-4 mr-2" />
              Nouvel Élément
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Type</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Description</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Bénéficiaire</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Montant</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Mois</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Échéance</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Statut</th>
                  <th className="text-left py-3 px-6 font-medium text-gray-900">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredItems.map((item) => (
                  <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                    <td className="py-4 px-6">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${typeColors[item.type]}`}>
                        {typeLabels[item.type]}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div>
                        <p className="font-medium text-gray-900">{item.description}</p>
                        <p className="text-sm text-gray-500">{item.category}</p>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      {item.employeeName && (
                        <div className="flex items-center space-x-2">
                          <Avatar 
                            firstName={item.employeeName.split(' ')[0] || ''} 
                            lastName={item.employeeName.split(' ')[1] || ''} 
                            size="sm" 
                            showPhoto={true}
                          />
                          <span className="text-sm text-gray-900">{item.employeeName}</span>
                        </div>
                      )}
                      {item.studentName && (
                        <div className="flex items-center space-x-2">
                          <Avatar 
                            firstName={item.studentName.split(' ')[0] || ''} 
                            lastName={item.studentName.split(' ')[1] || ''} 
                            size="sm" 
                            showPhoto={true}
                          />
                          <span className="text-sm text-gray-900">{item.studentName}</span>
                        </div>
                      )}
                      {!item.employeeName && !item.studentName && (
                        <span className="text-sm text-gray-500">-</span>
                      )}
                    </td>
                    <td className="py-4 px-6">
                      <p className="text-lg font-bold text-gray-900">{item.amount.toLocaleString()} Ar</p>
                    </td>
                    <td className="py-4 px-6">
                      <span className="text-sm text-gray-600">{monthLabels[item.month as keyof typeof monthLabels] || item.month}</span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center text-sm text-gray-600">
                        <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                        {new Date(item.dueDate).toLocaleDateString('fr-FR')}
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusColors[item.status]}`}>
                        {statusLabels[item.status]}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-2">
                        <button 
                          onClick={() => handleViewItem(item)}
                          className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => handleEditClick(item)}
                          disabled={updating}
                          className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors disabled:opacity-50"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => item.id && handleDeleteItem(item.id)}
                          disabled={deleting}
                          className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add Financial Item Modal */}
      <Modal
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        title="Nouvel Élément Financier"
        size="lg"
      >
        <FinancialItemForm
          onSubmit={handleAddItem}
          onCancel={() => setShowAddForm(false)}
        />
      </Modal>

      {/* Edit Financial Item Modal */}
      <Modal
        isOpen={showEditForm}
        onClose={() => {
          setShowEditForm(false);
          setSelectedItem(null);
        }}
        title="Modifier l'Élément Financier"
        size="lg"
      >
        {selectedItem && (
          <FinancialItemForm
            onSubmit={handleEditItem}
            onCancel={() => {
              setShowEditForm(false);
              setSelectedItem(null);
            }}
            initialData={selectedItem}
          />
        )}
      </Modal>

      {/* View Financial Item Modal */}
      <Modal
        isOpen={showViewModal}
        onClose={() => {
          setShowViewModal(false);
          setSelectedItem(null);
        }}
        title="Détails de l'Élément Financier"
        size="lg"
      >
        {selectedItem && (
          <div className="space-y-6">
            <div className="flex items-center space-x-4">
              <div className={`w-16 h-16 rounded-full flex items-center justify-center ${typeColors[selectedItem.type]}`}>
                <DollarSign className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">{selectedItem.description}</h3>
                <p className="text-gray-600">{typeLabels[selectedItem.type]} - {selectedItem.category}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Informations financières</h4>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Montant:</span> {selectedItem.amount.toLocaleString()} Ar</p>
                  <p><span className="font-medium">Mois:</span> {monthLabels[selectedItem.month as keyof typeof monthLabels] || selectedItem.month}</p>
                  <p><span className="font-medium">Échéance:</span> {new Date(selectedItem.dueDate).toLocaleDateString('fr-FR')}</p>
                  <p><span className="font-medium">Référence:</span> {selectedItem.reference}</p>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Statut et bénéficiaire</h4>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Statut:</span> 
                    <span className={`ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${statusColors[selectedItem.status]}`}>
                      {statusLabels[selectedItem.status]}
                    </span>
                  </p>
                  {selectedItem.employeeName && (
                    <p><span className="font-medium">Employé:</span> {selectedItem.employeeName}</p>
                  )}
                  {selectedItem.studentName && (
                    <p><span className="font-medium">Étudiant:</span> {selectedItem.studentName}</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}