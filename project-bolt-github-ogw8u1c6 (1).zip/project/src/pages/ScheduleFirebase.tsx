import React, { useState, useEffect } from 'react';
import { Search, Plus, Filter, Calendar, Clock, BookOpen, Users, MapPin, Edit, Trash2, Eye } from 'lucide-react';
import { Modal } from '../components/Modal';
import { ScheduleForm } from '../components/forms/ScheduleForm';
import { useFirebaseCollection } from '../hooks/useFirebaseCollection';
import { schedulesService, classesService, subjectsService, teachersService } from '../lib/firebase/firebaseService';

interface ScheduleItem {
  id?: string;
  class: string;
  subject: string;
  teacher: string;
  day: string;
  startTime: string;
  endTime: string;
  room: string;
  type: 'course' | 'exam' | 'tp' | 'sport' | 'break';
  createdAt?: Date;
  updatedAt?: Date;
}

const typeColors = {
  course: 'bg-blue-100 text-blue-800',
  exam: 'bg-red-100 text-red-800',
  tp: 'bg-purple-100 text-purple-800',
  sport: 'bg-green-100 text-green-800',
  break: 'bg-gray-100 text-gray-800'
};

const typeLabels = {
  course: 'Cours',
  exam: 'Examen',
  tp: 'TP',
  sport: 'Sport',
  break: 'Pause'
};

const days = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
const timeSlots = [
  '08:00', '09:00', '10:00', '10:15', '11:15', '12:15', '14:00', '15:00', '16:00'
];

export function ScheduleFirebase() {
  const [searchTerm, setSearchTerm] = useState('');
  const [allClasses, setAllClasses] = useState<any[]>([]);
  const [allSubjects, setAllSubjects] = useState<any[]>([]);
  const [allTeachers, setAllTeachers] = useState<any[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedItem, setSelectedItem] = useState<ScheduleItem | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Hook Firebase avec synchronisation temps réel
  const {
    data: schedule,
    loading,
    error,
    creating,
    updating,
    deleting,
    create,
    update,
    remove
  } = useFirebaseCollection<ScheduleItem>(schedulesService, true);

  // Charger les données liées (classes, matières, enseignants)
  useEffect(() => {
    const fetchRelatedData = async () => {
      try {
        console.log('🔄 Chargement des données liées...');
        
        // Récupérer les classes
        const classesData = await classesService.getAll();
        setAllClasses(classesData);
        console.log('✅ Classes chargées:', classesData.length);
        
        // Récupérer les matières
        const subjectsData = await subjectsService.getAll();
        setAllSubjects(subjectsData);
        console.log('✅ Matières chargées:', subjectsData.length);
        
        // Récupérer les enseignants
        const teachersData = await teachersService.getAll();
        setAllTeachers(teachersData);
        console.log('✅ Enseignants chargés:', teachersData.length);
      } catch (error) {
        console.error('❌ Erreur lors du chargement des données liées:', error);
      }
    };
    
    fetchRelatedData();
  }, []);

  const filteredSchedule = schedule.filter(item => {
    const matchesSearch = item.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.teacher.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.room.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClass = selectedClass === '' || item.class === selectedClass;
    return matchesSearch && matchesClass;
  });

  const classes = [...new Set(schedule.map(s => s.class))];

  // Fonction pour obtenir les informations d'une classe
  const getClassInfo = (className: string) => {
    return allClasses.find(c => c.name === className);
  };

  // Fonction pour obtenir les informations d'une matière
  const getSubjectInfo = (subjectName: string) => {
    return allSubjects.find(s => s.name === subjectName);
  };

  // Fonction pour obtenir les informations d'un enseignant
  const getTeacherInfo = (teacherName: string) => {
    return allTeachers.find(t => `${t.firstName} ${t.lastName}` === teacherName);
  };

  const handleAddScheduleItem = async (data: any) => {
    try {
      console.log('🚀 Ajout de créneau - Données reçues:', data);
      
      // Préparer les données pour Firebase
      const scheduleData = {
        class: data.class,
        subject: data.subject,
        teacher: data.teacher,
        day: data.day,
        startTime: data.startTime,
        endTime: data.endTime,
        room: data.room,
        type: data.type || 'course'
      };
      
      console.log('📝 Données formatées pour Firebase:', scheduleData);
      
      const scheduleId = await create(scheduleData);
      console.log('✅ Créneau créé avec l\'ID:', scheduleId);
      
      setShowAddForm(false);
      
      // Message de succès
      alert('✅ Créneau ajouté avec succès !');
      
    } catch (error: any) {
      console.error('❌ Erreur lors de l\'ajout du créneau:', error);
      alert('❌ Erreur lors de l\'ajout du créneau: ' + error.message);
    }
  };

  const handleEditScheduleItem = async (data: any) => {
    if (selectedItem?.id) {
      try {
        console.log('🔄 Modification de créneau - Données:', data);
        
        await update(selectedItem.id, data);
        console.log('✅ Créneau modifié avec succès');
        
        setShowEditForm(false);
        setSelectedItem(null);
        
        alert('✅ Créneau modifié avec succès !');
        
      } catch (error: any) {
        console.error('❌ Erreur lors de la modification:', error);
        alert('❌ Erreur lors de la modification: ' + error.message);
      }
    }
  };

  const handleDeleteScheduleItem = async (id: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce créneau ?')) {
      try {
        console.log('🗑️ Suppression du créneau ID:', id);
        await remove(id);
        console.log('✅ Créneau supprimé avec succès');
        alert('✅ Créneau supprimé avec succès !');
      } catch (error: any) {
        console.error('❌ Erreur lors de la suppression:', error);
        alert('❌ Erreur lors de la suppression: ' + error.message);
      }
    }
  };

  const handleViewItem = (item: ScheduleItem) => {
    setSelectedItem(item);
    setShowViewModal(true);
  };

  const handleEditClick = (item: ScheduleItem) => {
    setSelectedItem(item);
    setShowEditForm(true);
  };

  const getScheduleForTimeSlot = (day: string, time: string) => {
    return filteredSchedule.find(item => 
      item.day === day && item.startTime === time
    );
  };

  const renderGridView = () => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="text-left py-3 px-4 font-medium text-gray-900 w-20">Heure</th>
              {days.map(day => (
                <th key={day} className="text-center py-3 px-4 font-medium text-gray-900 min-w-32">
                  {day}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {timeSlots.map(time => (
              <tr key={time} className="hover:bg-gray-50">
                <td className="py-3 px-4 font-medium text-gray-900 bg-gray-50">
                  {time}
                </td>
                {days.map(day => {
                  const item = getScheduleForTimeSlot(day, time);
                  return (
                    <td key={`${day}-${time}`} className="py-2 px-2">
                      {item ? (
                        <div 
                          className={`p-2 rounded-lg cursor-pointer hover:shadow-md transition-shadow ${typeColors[item.type]} border`}
                          onClick={() => handleViewItem(item)}
                        >
                          <div className="text-xs font-medium truncate">{item.subject}</div>
                          <div className="text-xs text-gray-600 truncate">{item.teacher}</div>
                          <div className="text-xs text-gray-500 truncate">{item.room}</div>
                          <div className="text-xs text-gray-500">{item.startTime}-{item.endTime}</div>
                        </div>
                      ) : (
                        <div className="h-16 border-2 border-dashed border-gray-200 rounded-lg flex items-center justify-center">
                          <button 
                            onClick={() => setShowAddForm(true)}
                            className="text-gray-400 hover:text-gray-600 text-xs"
                          >
                            +
                          </button>
                        </div>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderListView = () => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      {schedule.length === 0 ? (
        <div className="text-center py-12">
          <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun créneau enregistré</h3>
          <p className="text-gray-500 mb-6">Commencez par ajouter votre premier créneau à l'emploi du temps.</p>
          <button
            onClick={() => setShowAddForm(true)}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            Ajouter un Créneau
          </button>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Classe</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Matière</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Enseignant</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Jour</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Horaire</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Salle</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Type</th>
                <th className="text-left py-3 px-6 font-medium text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredSchedule.map((item) => (
                <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                  <td className="py-4 px-6">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {item.class}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center space-x-2">
                      <BookOpen className="w-4 h-4 text-gray-400" />
                      <span className="font-medium text-gray-900">{item.subject}</span>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <p className="text-sm text-gray-600">{item.teacher}</p>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-600">{item.day}</span>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center space-x-2">
                      <Clock className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-600">{item.startTime} - {item.endTime}</span>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center space-x-2">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-600">{item.room}</span>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${typeColors[item.type]}`}>
                      {typeLabels[item.type]}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center space-x-2">
                      <button 
                        onClick={() => handleViewItem(item)}
                        className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleEditClick(item)}
                        disabled={updating}
                        className="p-1.5 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors disabled:opacity-50"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => item.id && handleDeleteScheduleItem(item.id)}
                        disabled={deleting}
                        className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement de l'emploi du temps...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <p className="text-red-600">Erreur: {error}</p>
        <button 
          onClick={() => window.location.reload()} 
          className="mt-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
        >
          Réessayer
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Emploi du Temps</h1>
          <p className="text-gray-600">Gestion des horaires et planification des cours</p>
        </div>
        
        <button
          onClick={() => {
            console.log('🔘 Ouverture du formulaire d\'ajout de créneau');
            setShowAddForm(true);
          }}
          disabled={creating}
          className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
        >
          {creating ? (
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
          ) : (
            <Plus className="w-4 h-4 mr-2" />
          )}
          Ajouter un Créneau
        </button>
      </div>

      {/* Filters and Controls */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col lg:flex-row gap-4 items-center">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Rechercher par matière, enseignant ou salle..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="flex gap-2 items-center">
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Toutes les classes</option>
              {classes.map(className => (
                <option key={className} value={className}>{className}</option>
              ))}
            </select>
            
            <div className="flex border border-gray-300 rounded-lg overflow-hidden">
              <button
                onClick={() => setViewMode('grid')}
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  viewMode === 'grid' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                Grille
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  viewMode === 'list' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                Liste
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Schedule Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Créneaux</p>
              <p className="text-2xl font-bold text-gray-900">{schedule.length}</p>
            </div>
            <Calendar className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Classes Actives</p>
              <p className="text-2xl font-bold text-green-600">{classes.length}</p>
            </div>
            <Users className="w-8 h-8 text-green-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Heures/Semaine</p>
              <p className="text-2xl font-bold text-purple-600">
                {schedule.filter(s => s.type === 'course').length}h
              </p>
            </div>
            <Clock className="w-8 h-8 text-purple-600" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Salles Utilisées</p>
              <p className="text-2xl font-bold text-orange-600">
                {[...new Set(schedule.map(s => s.room))].length}
              </p>
            </div>
            <MapPin className="w-8 h-8 text-orange-600" />
          </div>
        </div>
      </div>

      {/* Schedule Display */}
      {viewMode === 'grid' ? renderGridView() : renderListView()}

      {/* Add Schedule Item Modal */}
      <Modal
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        title="Ajouter un Créneau"
        size="lg"
      >
        <ScheduleForm
          onSubmit={handleAddScheduleItem}
          onCancel={() => setShowAddForm(false)}
          classes={allClasses}
          subjects={allSubjects}
          teachers={allTeachers}
        />
      </Modal>

      {/* Edit Schedule Item Modal */}
      <Modal
        isOpen={showEditForm}
        onClose={() => {
          setShowEditForm(false);
          setSelectedItem(null);
        }}
        title="Modifier le Créneau"
        size="lg"
      >
        {selectedItem && (
          <ScheduleForm
            onSubmit={handleEditScheduleItem}
            onCancel={() => {
              setShowEditForm(false);
              setSelectedItem(null);
            }}
            initialData={selectedItem}
            classes={allClasses}
            subjects={allSubjects}
            teachers={allTeachers}
          />
        )}
      </Modal>

      {/* View Schedule Item Modal */}
      <Modal
        isOpen={showViewModal}
        onClose={() => {
          setShowViewModal(false);
          setSelectedItem(null);
        }}
        title="Détails du Créneau"
        size="lg"
      >
        {selectedItem && (
          <div className="space-y-6">
            <div className="flex items-center space-x-4">
              <div className={`w-16 h-16 rounded-full flex items-center justify-center ${typeColors[selectedItem.type]}`}>
                <BookOpen className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">{selectedItem.subject}</h3>
                <p className="text-gray-600">{selectedItem.class} - {selectedItem.day}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Informations du cours</h4>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Matière:</span> {selectedItem.subject}</p>
                  <p><span className="font-medium">Enseignant:</span> {selectedItem.teacher}</p>
                  <p><span className="font-medium">Classe:</span> {selectedItem.class}</p>
                  <p><span className="font-medium">Type:</span> 
                    <span className={`ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${typeColors[selectedItem.type]}`}>
                      {typeLabels[selectedItem.type]}
                    </span>
                  </p>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Horaires et lieu</h4>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Jour:</span> {selectedItem.day}</p>
                  <p><span className="font-medium">Horaire:</span> {selectedItem.startTime} - {selectedItem.endTime}</p>
                  <p><span className="font-medium">Salle:</span> {selectedItem.room}</p>
                  <p><span className="font-medium">Durée:</span> 
                    {(() => {
                      const start = new Date(`2000-01-01T${selectedItem.startTime}`);
                      const end = new Date(`2000-01-01T${selectedItem.endTime}`);
                      const duration = (end.getTime() - start.getTime()) / (1000 * 60);
                      return ` ${duration} minutes`;
                    })()}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}